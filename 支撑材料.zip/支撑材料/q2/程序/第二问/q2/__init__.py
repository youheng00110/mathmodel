"""Question 2: bounded-bearing active localization, independent of Q3."""
