"""Convex polygon outer/inner approximations. Coordinates are metres."""
import math
from ._shared_geometry import (clip, bearing_clip, contains, distance,
                             enclosing_circle, diameter, disk_polygon, polygon_distance)


def wrap(angle):
    return (angle + 180) % 360 - 180


def disk_clip(poly, center, radius, sides, inner=False):
    r = radius * math.cos(math.pi / sides) if inner else radius
    for i in range(sides):
        a = 2 * math.pi * i / sides
        n = math.cos(a), math.sin(a)
        poly = clip(poly, n, n[0]*center[0] + n[1]*center[1] + r)
    return poly


def hull(points):
    p = sorted(set(points))
    if len(p) < 3:
        return p
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def half(seq):
        out = []
        for x in seq:
            while len(out) > 1 and cross(out[-2], out[-1], x) <= 0:
                out.pop()
            out.append(x)
        return out
    return half(p)[:-1] + half(p[::-1])[:-1]


def edge_circle(a, b, c, r):
    dx, dy = b[0]-a[0], b[1]-a[1]
    x, y = a[0]-c[0], a[1]-c[1]
    aa, bb, cc = dx*dx+dy*dy, 2*(x*dx+y*dy), x*x+y*y-r*r
    det = bb*bb-4*aa*cc
    if aa == 0 or det < 0:
        return []
    return [(a[0]+t*dx, a[1]+t*dy)
            for t in ((-bb-math.sqrt(det))/(2*aa), (-bb+math.sqrt(det))/(2*aa))
            if 0 <= t <= 1]


def outside_hull(poly, center, radius):
    """Hull of closure(P minus disk); circular holes add no convex arc extrema."""
    pts = [p for p in poly if distance(p, center) >= radius-1e-9]
    for a, b in zip(poly, poly[1:]+poly[:1]):
        pts.extend(edge_circle(a, b, center, radius))
    return hull(pts)


def metrics(poly):
    if not poly:
        return None
    c, r = enclosing_circle(poly)
    return {'center': list(c), 'radius': r, 'diameter': diameter(poly)[0]}
