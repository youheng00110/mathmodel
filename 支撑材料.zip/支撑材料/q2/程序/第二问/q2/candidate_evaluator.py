"""Finite feedback values and continuous-feedback outer bounds are separate."""
import math
from .geometry import *


def angle_interval(poly, s):
    if contains(poly, s):
        return -180., 180.
    angles = sorted(math.degrees(math.atan2(g[1]-s[1], g[0]-s[0])) % 360 for g in poly)
    gaps = [(angles[(i+1)%len(angles)] + (360 if i==len(angles)-1 else 0)-a, i)
            for i,a in enumerate(angles)]
    gap,i = max(gaps)
    start = angles[(i+1)%len(angles)]
    return start, start+360-gap


def evaluate(region, s, step=None):
    c = region.cfg
    s = tuple(s)
    result = {'s2': list(s), 'time_s': distance(s,region.s1)/c.speed+c.measure_seconds,
              'safe_receive': region.safe(s), 'global_optimum_certified': False}
    if distance(s, region.s1) < 1e-6:
        return dict(result, admissible=False, reason='same_point_error_is_fixed')
    if not result['safe_receive']:
        return dict(result, admissible=False, reason='not_in_certified_receive_subset')
    lo,hi = angle_interval(region.outer,s)
    lo -= c.delta_deg
    hi += c.delta_deg
    n = max(1, math.ceil((hi-lo)/(step or c.angle_step_deg)))
    width = (hi-lo)/n
    sampled = upper = lower = 0.
    du = 0.
    worst = None
    for i in range(n):
        z = lo+(i+.5)*width
        p = bearing_clip(region.outer,s,z,c.delta_deg)
        if p:
            r = enclosing_circle(p)[1]
            if r > sampled:
                sampled,worst = r,z
        # Every feedback in this bin has its posterior inside this expanded wedge.
        p = bearing_clip(region.outer,s,z,c.delta_deg+width/2)
        if p:
            upper = max(upper,enclosing_circle(p)[1])
            du = max(du,diameter(p)[0])
        # Feasible inner vertices give a rigorous lower witness (distance/2),
        # avoiding a numerical MEC radius being mislabelled a lower bound.
        p = bearing_clip(region.inner,s,z,c.delta_deg-1e-7)
        p = [g for g in p if region.feasible(g) and distance(g,s)>c.near_radius
             and distance(g,s)<=c.range_max]
        if len(p)>1:
            lower = max(lower,diameter(p)[0]/2)
    # Near feedback is always localizable within 5 m, including all continuous errors.
    if polygon_distance(region.outer,s)<=c.near_radius:
        upper = max(upper,c.near_radius)
        du = max(du,2*c.near_radius)
    return dict(result, admissible=True, sampled_outer_mec_m=sampled,
                worst_mec_lower_m=max(0,lower-1e-6), worst_mec_upper_m=upper+1e-6,
                worst_diameter_upper_m=du+1e-6, worst_sample_angle_deg=worst,
                feedback_bins=n, feedback_step_deg=width,
                clear_certified=upper+1e-6<=c.clear_radius)
