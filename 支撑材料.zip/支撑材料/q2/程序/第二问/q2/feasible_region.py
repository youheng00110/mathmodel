import math
from .config import Config
from .geometry import *


class Region:
    def __init__(self, s1=(0., 0.), theta=0., config=None):
        self.s1 = tuple(map(float, s1))
        self.theta = float(theta)
        self.cfg = config or Config()
        c = self.cfg
        self.outer = self._polygon(False)
        self.inner = self._polygon(True)
        if not self.outer:
            raise ValueError('First direction has no feasible target in the arena')
        # Hull after first near exclusion; valid outer set, not an exact posterior.
        self.first_hull = outside_hull(self.outer, self.s1, c.near_radius)
        self.near_vertices = [g for g in self.first_hull
                              if distance(g,self.s1)<=c.range_min]
        for a,b in zip(self.first_hull,self.first_hull[1:]+self.first_hull[:1]):
            self.near_vertices.extend(edge_circle(a,b,self.s1,c.range_min))
        self.far_vertices = outside_hull(self.first_hull, self.s1, c.range_min)

    def _polygon(self, inner):
        c = self.cfg
        p = disk_polygon((0, 0), c.arena_radius, c.circle_sides)
        if inner:
            p = disk_clip(p, (0, 0), c.arena_radius, c.circle_sides, True)
        p = disk_clip(p, self.s1, c.range_max, c.circle_sides, inner)
        return bearing_clip(p, self.s1, self.theta, c.delta_deg-(1e-7 if inner else 0))

    def feasible(self, g):
        c = self.cfg
        d = distance(g, self.s1)
        a = math.degrees(math.atan2(g[1]-self.s1[1], g[0]-self.s1[0]))
        return (math.hypot(*g) <= c.arena_radius+1e-8 and
                c.near_radius < d <= c.range_max+1e-8 and
                abs(wrap(a-self.theta)) <= c.delta_deg+1e-8)

    def safe(self, s, conservative1000=False):
        c = self.cfg
        if conservative1000:
            return all(distance(s,g) <= c.range_min+1e-8 for g in self.first_hull)
        # Near piece: convex squared distance reaches maximum at polygon vertices.
        if any(distance(s,g) > c.range_min+1e-8 for g in self.near_vertices):
            return False
        d = distance(s,self.s1)
        if d>1e-8:
            far_arc = tuple(self.s1[k]+c.range_min*(self.s1[k]-s[k])/d for k in (0,1))
            if contains(self.first_hull,far_arc):
                return False
        # Far piece: squared-distance difference is AFFINE in g.
        return all(distance(s,g)**2-distance(self.s1,g)**2 <= 1e-5
                   for g in self.far_vertices)

    def posterior(self, s, kind, angle=None):
        c = self.cfg
        if kind == 'near':
            p = disk_clip(self.outer, s, c.near_radius, c.circle_sides)
        elif kind == 'direction':
            p = bearing_clip(self.outer, s, angle, c.delta_deg)
            p = disk_clip(p, s, c.range_max, c.circle_sides)
            # Keeping holes is conservative; do not invent convex exactness.
        elif kind == 'no_signal':
            n = (2*(s[0]-self.s1[0]), 2*(s[1]-self.s1[1]))
            b = s[0]**2+s[1]**2-self.s1[0]**2-self.s1[1]**2
            p = outside_hull(clip(self.outer, n, b), s, c.range_min)
        else:
            raise ValueError(kind)
        return p
