from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    delta_deg: float = 1.0
    arena_radius: float = 1800.0
    range_min: float = 1000.0
    range_max: float = 1500.0
    near_radius: float = 5.0
    clear_radius: float = 20.0
    speed: float = 5.0
    measure_seconds: float = 5.0
    circle_sides: int = 128
    angle_step_deg: float = 1.0
    grid_step: float = 50.0
