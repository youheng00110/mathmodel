"""Rational/rounded-outward arithmetic for the centre-case certificate.

No libm result is trusted. Pi is enclosed by Machin's identity and alternating
arctangent sums. Sin/cos use integer intervals and explicit Taylor remainders.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt, factorial

Q = 10**40
S = 10**16


def floor_div(a, b):
    assert b > 0
    return a//b


def ceil_div(a, b):
    return -((-a)//b)


def atan_bounds(n, terms=40):
    partial = sum((F((-1)**k, (2*k+1)*n**(2*k+1)) for k in range(terms)), F(0))
    next_term = F((-1)**terms, (2*terms+1)*n**(2*terms+1))
    return min(partial, partial+next_term), max(partial, partial+next_term)


@lru_cache(None)
def pi_bounds():
    a, b = atan_bounds(5)
    c, d = atan_bounds(239)
    return 16*a-4*d, 16*b-4*c


def add(a, b):
    return a[0]+b[0], a[1]+b[1]


def neg(a):
    return -a[1], -a[0]


def mul(a, b):
    products = [x*y for x in a for y in b]
    return min(products)//Q, ceil_div(max(products), Q)


def divide(a, n):
    assert n > 0
    return a[0]//n, ceil_div(a[1], n)


@lru_cache(maxsize=30000)
def sin_cos(degrees):
    degrees = F(degrees)
    quadrant = (degrees+45)//90
    r = degrees-90*quadrant
    assert -45 <= r <= 45
    pl, ph = pi_bounds()
    ends = (r*pl/180, r*ph/180)
    a, b = min(ends), max(ends)
    x = ((a.numerator*Q)//a.denominator, ceil_div(b.numerator*Q, b.denominator))
    assert max(abs(x[0]), abs(x[1])) < Q
    x2 = mul(x, x)
    st = ss = x
    ct = cs = (Q, Q)
    for k in range(1, 20):
        st = divide(neg(mul(st, x2)), (2*k)*(2*k+1))
        ct = divide(neg(mul(ct, x2)), (2*k-1)*(2*k))
        ss, cs = add(ss, st), add(cs, ct)
    # For |x|<1 the alternating omitted terms are bounded by 1/41!
    # and 1/40!, both smaller than one fixed-point unit.
    assert factorial(40) > Q
    ss, cs = (ss[0]-1, ss[1]+1), (cs[0]-1, cs[1]+1)
    q = quadrant % 4
    return ((ss, cs), (cs, neg(ss)), (neg(ss), neg(cs)), (neg(cs), ss))[q]


@lru_cache(None)
def tangent_bounds(degrees):
    s, c = sin_cos(F(degrees))
    assert s[0] >= 0 and c[0] > 0
    return F(s[0], c[1]), F(s[1], c[0])


def rational_sqrt_bounds(x, scale=10**24):
    x = F(x)
    assert x >= 0
    a = isqrt((x.numerator*scale*scale)//x.denominator)
    lo = F(a, scale)
    hi = lo if lo*lo == x else F(a+1, scale)
    assert lo*lo <= x <= hi*hi
    return lo, hi


def point(p):
    return tuple(F.from_float(float(x)) for x in p)


def norm2(p):
    return sum((x*x for x in p), F(0))


def sub(a, b):
    return a[0]-b[0], a[1]-b[1]


def cross(a, b):
    return a[0]*b[1]-a[1]*b[0]


def dot(a, b):
    return a[0]*b[0]+a[1]*b[1]


def distance_box2(g, box, maximum=False):
    intervals = ((box[0], box[1]), (box[2], box[3]))
    if maximum:
        return sum((max(abs(x-a), abs(x-b))**2 for x, (a, b) in zip(g, intervals)), F(0))
    return sum((max(a-x, x-b, F(0))**2 for x, (a, b) in zip(g, intervals)), F(0))


def clamp(x, a, b):
    return max(a, min(b, x))


@lru_cache(None)
def first_feasible(g):
    # This verifier deliberately covers only S1=(0,0), theta1=0 degrees.
    tl, _ = tangent_bounds(F(1))
    return g[0] > 0 and F(25) < norm2(g) <= F(1500**2) and abs(g[1]) <= tl*g[0]


def pair_certifies(kind, g, h, box, lower):
    if not first_feasible(g) or not first_feasible(h) or norm2(sub(g, h)) < lower*lower:
        return False
    if kind == 0:
        return all(distance_box2(x, box) > max(F(1000**2), norm2(x)) for x in (g, h))
    if kind == 2:
        return all(distance_box2(x, box, True) <= 25 for x in (g, h))
    if kind != 1:
        return False
    if not all(distance_box2(x, box) > 25 and distance_box2(x, box, True) <= 1500**2 for x in (g, h)):
        return False
    t, _ = tangent_bounds(F(2))
    m = ((g[0]+h[0])/2, (g[1]+h[1])/2)
    ell = (g[1]-h[1], h[0]-g[0])
    for sign in (-1, 1):
        p = (clamp(m[0]+sign*ell[0]/(2*t), box[0], box[1]),
             clamp(m[1]+sign*ell[1]/(2*t), box[2], box[3]))
        a, b = sub(g, p), sub(h, p)
        if sign*cross(a, b)-t*dot(a, b) > 0:
            return False
    return True
