import math
import random
import unittest
import numpy as np

from search import Region, WitnessBank, center_radius, distance, wrap, discover
from verify_cover import verify_partition
from diameter_oracle import bounds as diameter_bounds


class BoundsTests(unittest.TestCase):
    def setUp(self):
        self.region = Region()

    def test_no_signal_uses_conditioned_radius(self):
        bank = WitnessBank(self.region)
        bank.add(0, (1200., 0.), (1400., 0.))
        # Both are >1000 away but a compatible source at x=1400 must have
        # R>=1400. Calling it invisible at the origin would be false.
        self.assertEqual(bank.lower((0., 0., 0., 0.))[0], 0.)
        self.assertGreater(bank.lower((-500., -490., -5., 5.))[0], 199.99)

    def test_direction_witness_holds_everywhere_in_box(self):
        bank = WitnessBank(self.region)
        bank.add(1, (800., 0.), (820., 0.))
        box = (400., 401., 600., 601.)
        self.assertGreater(bank.lower(box)[0], 19.99)
        for i in range(11):
            for j in range(11):
                p = (400+i/10, 600+j/10)
                angles = [math.degrees(math.atan2(-p[1], x-p[0])) for x in (800, 820)]
                self.assertLess(abs(wrap(angles[0]-angles[1])), 2.)
                self.assertTrue(all(5 < distance(p, (x, 0)) < 1500 for x in (800, 820)))
        self.assertEqual(bank.lower((0., 1500., 0., 1500.))[0], 0.)

    def test_incompatible_first_observation_is_rejected(self):
        bank = WitnessBank(self.region)
        bank.add(1, (800., 30.), (820., 0.))
        bank.add(1, (0., 0.), (820., 0.))
        self.assertEqual(len(bank.records), 0)

    def test_discovery_retains_near_end_of_initial_region(self):
        bank = WitnessBank(self.region)
        discover(self.region, (-2000., 150.), bank, 98.)
        self.assertGreater(bank.lower((-2100., -1900., 100., 200.))[0], 1400.)

    def test_box_radius_contains_corners(self):
        p, radius = center_radius((-2., 7., 5., 11.))
        self.assertTrue(all(distance(p, q) <= radius+1e-12
                            for q in ((-2, 5), (-2, 11), (7, 5), (7, 11))))

    def test_partition_checker_detects_gap_and_overlap(self):
        root = (0, 2, 0, 2)
        self.assertTrue(verify_partition(root, [(0, 1, 0, 2), (1, 2, 0, 1), (1, 2, 1, 2)]))
        with self.assertRaises(ValueError):
            verify_partition(root, [(0, 1, 0, 2)])
        with self.assertRaises(ValueError):
            verify_partition(root, [(0, 2, 0, 2), (0, 1, 0, 2)])

    def test_analytic_box_angle_bound_against_independent_angles(self):
        rng = random.Random(483)
        accepted = 0
        for _ in range(120):
            bank = WitnessBank(self.region)
            a = (rng.uniform(400, 1000), rng.uniform(-2, 2))
            b = (a[0]+rng.uniform(5, 35), rng.uniform(-2, 2))
            bank.add(1, a, b)
            x, y = rng.uniform(0, 1400), rng.uniform(-900, 900)
            w = rng.uniform(1, 60)
            box = (x-w, x+w, y-w, y+w)
            if bank.lower(box)[0] <= 0:
                continue
            accepted += 1
            for i in range(5):
                for j in range(5):
                    p = (x-w+i*w/2, y-w+j*w/2)
                    angles = [math.degrees(math.atan2(g[1]-p[1], g[0]-p[0])) for g in (a,b)]
                    self.assertLess(abs(wrap(angles[0]-angles[1])), 2.)
                    self.assertTrue(all(5 < distance(g,p) < 1500 for g in (a,b)))
        self.assertGreater(accepted, 10)

    def test_adaptive_feedback_bound_contains_independent_world_pairs(self):
        p = np.array([970.6, 495.5])
        result = diameter_bounds(self.region, tuple(p), tolerance=.01)
        targets = np.array([(r*math.cos(a), r*math.sin(a))
                            for r in np.linspace(5.01, 1499., 50)
                            for a in np.radians(np.linspace(-.999, .999, 7))])
        d1 = np.linalg.norm(targets, axis=1)
        v = targets-p
        d2 = np.linalg.norm(v, axis=1)
        angle = np.arctan2(v[:, 1], v[:, 0])
        adiff = np.abs((angle[:, None]-angle[None, :]+math.pi)%(2*math.pi)-math.pi)
        received = (d2 > 5) & (d2 <= 1500)
        negative = d2 > np.maximum(1000, d1)
        compatible = ((received[:, None] & received[None, :] & (adiff < math.radians(2)))
                      | (negative[:, None] & negative[None, :]))
        separation = np.linalg.norm(targets[:, None]-targets[None, :], axis=2)
        self.assertLessEqual(float(separation[compatible].max()), result['upper_m'])
        self.assertLessEqual(result['lower_m'], result['upper_m'])


if __name__ == '__main__':
    unittest.main()
