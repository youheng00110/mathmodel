"""Continuous Q2 diameter bounds using indistinguishable-target witnesses.

Independent from the delivered Q2 solvers. All feedback branches are allowed.
Box lower bounds cover continuous positions; their derivation does not sample
positions. Witness discovery is numerical and can be incomplete, making bounds
weaker, never stronger. Floating arithmetic uses margins, not validated interval
arithmetic: no exact/formally certified optimum is claimed.
"""
import argparse
import heapq
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '第二问'))
from q2.config import Config
from q2.feasible_region import Region
from q2.geometry import distance, diameter, disk_clip, bearing_clip, clip, outside_hull, wrap
from q2.candidate_evaluator import angle_interval
from diameter_oracle import bounds as diameter_bounds

MARGIN = 1e-6


def center_radius(box):
    x0, x1, y0, y1 = box
    return ((x0+x1)/2, (y0+y1)/2), math.hypot(x1-x0, y1-y0)/2


def first_valid(region, g):
    c = region.cfg
    d = distance(g, region.s1)
    angle = math.degrees(math.atan2(g[1]-region.s1[1], g[0]-region.s1[0]))
    return (math.hypot(*g) <= c.arena_radius-MARGIN and
            c.near_radius+MARGIN < d <= c.range_max-MARGIN and
            abs(wrap(angle-region.theta)) <= c.delta_deg-1e-9)


class WitnessBank:
    def __init__(self, region):
        self.region = region
        self.records = []
        self.keys = set()
        self._array = None

    def add(self, kind, a, b):
        if not first_valid(self.region, a) or not first_valid(self.region, b):
            return
        a, b = sorted((tuple(a), tuple(b)))
        key = (kind, *[round(x, 6) for p in (a, b) for x in p])
        if key in self.keys or distance(a, b) <= MARGIN:
            return
        self.keys.add(key)
        self.records.append((kind, a, b, distance(a, b)-MARGIN))
        self._array = None

    def arrays(self):
        if self._array is None:
            if not self.records:
                return None
            kind = np.array([r[0] for r in self.records])
            points = np.array([[r[1], r[2]] for r in self.records])
            size = np.array([r[3] for r in self.records])
            rmin = np.maximum(self.region.cfg.range_min,
                              np.linalg.norm(points-np.array(self.region.s1), axis=2))
            self._array = kind, points, size, rmin
        return self._array

    def lower(self, box):
        """Each accepted pair is indistinguishable at EVERY position in box.

        For t=tan(2 delta), an acute bearing difference <=2 delta means
        +/-cross(G-P,H-P)-t dot(G-P,H-P)<=0. Each expression is a concave
        quadratic in P; its box maximum is attained at the componentwise
        projection of its unconstrained maximizer. No angular sampling occurs.
        """
        data = self.arrays()
        if data is None:
            return 0., None
        kind, points, size, rmin = data
        low_corner = np.array((box[0], box[2]))
        high_corner = np.array((box[1], box[3]))
        lo = np.linalg.norm(np.maximum(np.maximum(low_corner-points, points-high_corner), 0.), axis=2)
        hi = np.linalg.norm(np.maximum(np.abs(low_corner-points), np.abs(high_corner-points)), axis=2)
        negative = (kind == 0) & np.all(lo > rmin+MARGIN, axis=1)
        near = (kind == 2) & np.all(hi < self.region.cfg.near_radius-MARGIN, axis=1)
        tangent = math.tan(math.radians(2*self.region.cfg.delta_deg))-1e-12
        midpoint = points.mean(axis=1)
        ell = np.column_stack((points[:, 0, 1]-points[:, 1, 1],
                               points[:, 1, 0]-points[:, 0, 0]))
        angular_ok = np.ones(len(points), dtype=bool)
        for sign in (-1., 1.):
            maximizer = np.clip(midpoint+sign*ell/(2*tangent), low_corner, high_corner)
            a, b = points[:, 0]-maximizer, points[:, 1]-maximizer
            cross = a[:, 0]*b[:, 1]-a[:, 1]*b[:, 0]
            dot = np.sum(a*b, axis=1)
            angular_ok &= sign*cross-tangent*dot < -1e-5
        received = ((kind == 1) & np.all(lo > self.region.cfg.near_radius+MARGIN, axis=1)
                    & np.all(hi < self.region.cfg.range_max-MARGIN, axis=1)
                    & angular_ok)
        valid = negative | near | received
        ids = np.flatnonzero(valid)
        if not len(ids):
            return 0., None
        i = int(ids[np.argmax(size[ids])])
        return float(size[i]), i


def discover(region, p, bank, target, step=.7, slack=.05):
    """Find witness pairs; contractions provide angular/interior slack."""
    c = region.cfg
    # Retain intersections with the first near-exclusion boundary. Dropping
    # only the apex would lose the entire near end of a narrow initial wedge
    # and make no-signal witnesses artificially short.
    poly = outside_hull(region.inner, region.s1, c.near_radius+1e-3)
    # Move inner vertices slightly inside to separate numerical boundaries.
    mean = tuple(sum(g[k] for g in poly)/len(poly) for k in (0, 1))
    poly = [tuple(.99999999*g[k]+.00000001*mean[k] for k in (0, 1)) for g in poly]
    options = []

    def collect(kind, pts):
        pts = [g for g in pts if first_valid(region, g)]
        if kind == 0:
            pts = [g for g in pts if distance(g, p) > max(c.range_min, distance(g, region.s1))+MARGIN]
        elif kind == 1:
            pts = [g for g in pts if c.near_radius+MARGIN < distance(g, p) < c.range_max-MARGIN]
        elif kind == 2:
            pts = [g for g in pts if distance(g, p) < c.near_radius-MARGIN]
        if len(pts) > 1:
            length, a, b = diameter(pts)
            options.append((length, kind, a, b))

    normal = tuple(2*(p[k]-region.s1[k]) for k in (0, 1))
    offset = sum(x*x for x in p)-sum(x*x for x in region.s1)
    neg = outside_hull(clip(poly, normal, offset-1e-4*max(1., math.hypot(*normal))),
                       p, c.range_min+1e-4)
    collect(0, neg)
    collect(2, disk_clip(poly, p, c.near_radius-MARGIN, 32, True))
    received = disk_clip(poly, p, c.range_max-MARGIN, 96, True)
    if received:
        lo, hi = angle_interval(received, p)
        lo -= c.delta_deg
        hi += c.delta_deg
        count = max(1, math.ceil((hi-lo)/step))
        for i in range(count):
            z = lo+(i+.5)*(hi-lo)/count
            collect(1, bearing_clip(received, p, z, c.delta_deg-1e-7))
    selected = sorted(options, reverse=True)[:5]
    selected += [r for r in options if r[1] != 1]
    for length, kind, a, b in selected:
        factors = [1., .999, .99, .97, .9, .75, .5]
        if length > target+slack:
            factors.append((target+slack)/length)
        for f in factors:
            x = tuple((a[k]+b[k])/2+f*(a[k]-b[k])/2 for k in (0, 1))
            y = tuple((a[k]+b[k])/2-f*(a[k]-b[k])/2 for k in (0, 1))
            bank.add(kind, x, y)


def point_upper(region, p, step=.02):
    if distance(p, region.s1) < 1e-7:
        return math.inf
    return diameter_bounds(region, p, tolerance=.001)['upper_m']


def run(args):
    started = time.monotonic()
    region = Region(args.s1, args.theta, Config(circle_sides=2048))
    bank = WitnessBank(region)
    s1 = region.s1
    t = math.radians(args.theta)
    u, n = (math.cos(t), math.sin(t)), (-math.sin(t), math.cos(t))
    candidates = [tuple(s1[k]+x*u[k]+sign*y*n[k] for k in (0, 1))
                  for x, y in ((971., 496.), (845., 542.), (666.57, 745.45))
                  for sign in (-1, 1)]
    values = [(point_upper(region, p), p) for p in candidates]
    if args.initial_point is not None:
        values.append((point_upper(region, args.initial_point, .005), tuple(args.initial_point)))
    upper, incumbent = min(values)
    for p in candidates:
        point_low, _ = bank.lower((p[0], p[0], p[1], p[1]))
        if point_low < upper-args.gap+min(.025, args.gap/20):
            discover(region, p, bank, upper-args.gap, slack=min(.05, args.gap/10))
    # Outside B(0,1800+1500) every scenario returns no signal, revealing
    # nothing. Its value is diam(Omega1), >= any feasible candidate's value.
    extent = region.cfg.arena_radius+region.cfg.range_max
    symmetric = s1 == (0., 0.) and args.theta % 360 == 0.
    root = (-extent, extent, 0. if symmetric else -extent, extent)
    root_lower, _ = bank.lower(root)
    heap = [(root_lower, 0, root)]
    serial = expanded = pruned = 0
    closed_floor = math.inf
    last_print = started
    history = []
    closed = []
    inherited_proof = np.empty((0, 6))
    if args.resume_from:
        previous = Path(args.resume_from)
        info = json.loads((previous/'result.json').read_text())
        if list(s1) != info['s1'] or args.theta != info['theta_deg'] or list(root) != info['full_position_domain']:
            raise ValueError('Resume geometry differs from saved run')
        upper, incumbent = min((upper, incumbent),
                               (info['upper_bound_m'], tuple(info['best_point'])))
        bank = WitnessBank(region)
        # Search may discard weak witnesses; the proof archive must retain
        # ancestors because a child's stored bound can come from its parent.
        archive = previous/'witnesses_complete.npz'
        if not archive.exists():
            archive = previous/'witnesses.npz'
        inherited_proof = np.load(archive)['records']
        for kind, ax, ay, bx, by, size in np.load(previous/'witnesses.npz')['records']:
            # Removed witnesses cannot invalidate already established bounds.
            if size > upper-args.gap:
                bank.add(int(kind), (ax, ay), (bx, by))
        saved = json.loads((previous/'remaining_boxes.json').read_text())
        old_closed = json.loads((previous/'closed_boxes.json').read_text())
        # Reopen old leaves when requesting a tighter gap.
        saved.extend((low, box) for box, low in old_closed)
        heap = [(low, i, tuple(box)) for i, (low, box) in enumerate(saved)]
        heapq.heapify(heap)
        serial = len(heap)
    while heap and time.monotonic()-started < args.seconds:
        low, _, box = heapq.heappop(heap)
        fresh, _ = bank.lower(box)
        low = max(low, fresh)
        if low >= upper-args.gap:
            pruned += 1
            closed_floor = min(closed_floor, low)
            closed.append((box, low))
            continue
        if heap and low > heap[0][0]+1e-9:
            serial += 1
            heapq.heappush(heap, (low, serial, box))
            continue
        p, radius = center_radius(box)
        point_low, _ = bank.lower((p[0], p[0], p[1], p[1]))
        if point_low < upper-args.gap+min(.025, args.gap/20):
            discover(region, p, bank, upper-args.gap,
                     step=.05 if radius < 20 else .7, slack=min(.05, args.gap/10))
            point_low, _ = bank.lower((p[0], p[0], p[1], p[1]))
            if radius < 20 and point_low < upper-args.gap:
                target, slack = upper-args.gap, min(.05, args.gap/10)
                def remember(kind, a, b):
                    length = distance(a, b)
                    if length <= target+slack:
                        return
                    bank.add(kind, a, b)
                    f = (target+slack)/length
                    x = tuple((a[k]+b[k])/2+f*(a[k]-b[k])/2 for k in (0, 1))
                    y = tuple((a[k]+b[k])/2-f*(a[k]-b[k])/2 for k in (0, 1))
                    bank.add(kind, x, y)
                tight = diameter_bounds(region, p, tolerance=args.gap/10,
                                        witness_callback=remember)
                if tight['upper_m'] < upper:
                    upper, incumbent = tight['upper_m'], p
        fresh, _ = bank.lower(box)
        low = max(low, fresh)
        if low >= upper-args.gap:
            pruned += 1
            closed_floor = min(closed_floor, low)
            closed.append((box, low))
            continue
        # Never confuse a point witness with a lower bound on its whole box.
        point_low, _ = bank.lower((p[0], p[0], p[1], p[1]))
        if radius < 20 and point_low < upper-args.gap/4 and expanded % 40 == 0:
            trial = point_upper(region, p, .005)
            if trial < upper:
                upper, incumbent = trial, p
        x0, x1, y0, y1 = box
        if x1-x0 >= y1-y0:
            m = (x0+x1)/2
            children = ((x0, m, y0, y1), (m, x1, y0, y1))
        else:
            m = (y0+y1)/2
            children = ((x0, x1, y0, m), (x0, x1, m, y1))
        for child in children:
            child_low, _ = bank.lower(child)
            serial += 1
            heapq.heappush(heap, (max(low, child_low), serial, child))
        expanded += 1
        if time.monotonic()-last_print > 10:
            lb = min(upper, closed_floor, heap[0][0] if heap else math.inf)
            item = dict(elapsed_s=time.monotonic()-started, lower_m=lb,
                        upper_m=upper, gap_m=upper-lb, boxes=len(heap), witnesses=len(bank.records))
            print(json.dumps(item), flush=True)
            history.append(item)
            last_print = time.monotonic()
    # Stored lower bounds remain valid; do not perform an unbudgeted full
    # refresh after a timeout. Saving all leaves permits continued refinement.
    active = [(low, box) for low, _, box in heap]
    lower = min(upper, closed_floor, min((r[0] for r in active), default=math.inf))
    result = dict(objective='worst posterior diameter, all feedback branches',
                  s1=s1, theta_deg=args.theta, best_point=incumbent,
                  lower_bound_m=lower, upper_bound_m=upper, gap_m=upper-lower,
                  requested_gap_m=args.gap, numerical_gap_closed=upper-lower <= args.gap+1e-8,
                  exact_global_optimum_proved=False, interval_arithmetic_verified=False,
                  arithmetic='Double precision plus safety margins; no formal interval certificate',
                  elapsed_s=time.monotonic()-started, expanded_boxes=expanded,
                  pending_boxes=len(active), pruned_boxes=pruned, witnesses=len(bank.records),
                  full_position_domain=root, reflection_symmetry_used=symmetric,
                  outside_domain='Outside radius 3300 all outcomes are no_signal and reveal nothing',
                  target_model='Continuous题面 ±1 degree, fixed unknown range; not simulator noise prior',
                  circle_sides=region.cfg.circle_sides,
                  resume_from=args.resume_from,
                  history=history)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    (out/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
    active_records = np.array([[r[0], *r[1], *r[2], r[3]] for r in bank.records]).reshape((-1, 6))
    np.savez_compressed(out/'witnesses.npz', records=active_records)
    np.savez_compressed(out/'witnesses_complete.npz',
                        records=np.concatenate((inherited_proof, active_records), axis=0))
    (out/'remaining_boxes.json').write_text(json.dumps(active))
    (out/'closed_boxes.json').write_text(json.dumps(closed))
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--s1', nargs=2, type=float, default=[0., 0.])
    parser.add_argument('--theta', type=float, default=0.)
    parser.add_argument('--seconds', type=float, default=60.)
    parser.add_argument('--gap', type=float, default=1.)
    parser.add_argument('--initial-point', nargs=2, type=float)
    parser.add_argument('--resume-from')
    parser.add_argument('--output', required=True)
    run(parser.parse_args())
