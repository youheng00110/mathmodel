"""Check the new exact domain reduction and rejection logic independently."""
import math
import random
import unittest

from exact_arithmetic import F, point
from reception_optimum import (CENTRES, ROOT, feasible_exact, excluded_exact,
                               ThresholdWitnessBank, Region, Config)
from verify_cover import verify_partition


class ReceptionDomainTests(unittest.TestCase):
    def test_known_and_invalid_points(self):
        self.assertTrue(feasible_exact(point((842.18, 546.83))))
        self.assertTrue(feasible_exact(point((750, 500))))
        self.assertFalse(feasible_exact(point((970.108, 496.402))))
        self.assertFalse(feasible_exact(point((-1, 0))))
        self.assertFalse(feasible_exact(point((0, 500))))

    def test_domain_matches_direct_polar_extrema(self):
        # Independent dense physical constraint audit; the analytic proof,
        # rather than this finite grid, is what establishes all-target coverage.
        rng = random.Random(21983)
        angles = [math.radians(-1+2*k/40) for k in range(41)]
        radii = [5+1495*k/200 for k in range(201)]+[1000]
        for _ in range(80):
            p = (rng.uniform(0, 1005), rng.uniform(0, 1000))
            worst = max(math.hypot(p[0]-r*math.cos(a), p[1]-r*math.sin(a))
                        -max(1000, r) for r in radii for a in angles)
            self.assertEqual(feasible_exact(point(p)), worst <= 0)

    def test_all_near_far_radii_satisfied_at_candidate(self):
        p = (843.3652127578218, 545.0205008607356)
        self.assertTrue(feasible_exact(point(p)))
        for r in (5.000001, 6, 300, 999.999, 1000, 1000.001, 1200, 1500):
            for a in (-1, -.8, 0, .5, 1):
                t = math.radians(a)
                self.assertLessEqual(math.hypot(p[0]-r*math.cos(t), p[1]-r*math.sin(t)), max(1000,r))

    def test_exclusion_cannot_remove_box_containing_feasible_point(self):
        p = (F(842), F(546))
        self.assertTrue(feasible_exact(p))
        for width in (F(1,1000), F(1), F(100), F(1000)):
            self.assertFalse(excluded_exact((p[0]-width,p[0]+width,p[1]-width,p[1]+width)))
        self.assertTrue(excluded_exact(tuple(map(F, (990,1005,990,1000)))))

    def test_disk_centres_are_outward_enclosures(self):
        # Known direction, quadrant, and squared-radius identity.
        for r, c in zip((5,1000), CENTRES):
            self.assertGreater(c[0][0], 0)
            self.assertLess(c[1][1], 0)
            low = c[0][0]**2+c[1][1]**2
            high = c[0][1]**2+c[1][0]**2
            self.assertLessEqual(low, r*r)
            self.assertGreaterEqual(high, r*r)

    def test_missing_search_region_is_rejected(self):
        with self.assertRaises(ValueError):
            verify_partition(ROOT, [(0,500,0,1000)])

    def test_threshold_filter_keeps_useful_direction_proof(self):
        bank = ThresholdWitnessBank(Region(config=Config(circle_sides=64)), 100)
        bank.add(1, (100,0), (150,0))
        bank.add(0, (100,0), (400,0))
        self.assertEqual(len(bank.records), 0)
        bank.add(1, (100,0), (400,0))
        self.assertEqual(len(bank.records), 1)
        self.assertEqual(bank.lower((1000,1001,100,101))[0], 0.)
        lower, index = bank.lower((1000,1001,10,11))
        self.assertGreater(lower, 100)
        self.assertEqual(index, 0)


if __name__ == '__main__':
    unittest.main()
