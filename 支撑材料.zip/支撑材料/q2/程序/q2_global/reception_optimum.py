"""Centre-case constrained minimax diameter search and rational verification.

S1=(0,0), theta1=0, 5<r<=1500, |theta|<=1 degree. Reflect s to y>=0.
Reception for g=(1000,0) implies x>=0. For x,y>=0 the minimum of
x*cos(theta)+y*sin(theta) over [-delta,delta] is at -delta. For r in
[5,1000] squared distance is convex in r, so only endpoints matter.
For r>=1000 the reception constraint is |s|^2 <= 2*r*s.dot(v); its
strongest endpoint is r=1000, since the endpoint constraint implies
s.dot(v)>=0. Consequently the EXACT upper-half reception domain is
the intersection of two closed radius-1000 disks centred at 5*v and
1000*v, where v=(cos(delta),-sin(delta)), restricted to y>=0.
The excluded r=5 limit still gives a necessary closed inequality.
The target (5+,0) gives x<=1005 and y<=1000. Thus ROOT covers the
whole feasible upper half-plane. Reflection gives the lower half.

Search proposals use floating point; certificates recheck every leaf
using rational distances and outward enclosures for the two centres.
No acceptance depends on sampled target or second-station positions.
"""
import argparse
import heapq
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.optimize import minimize_scalar

from search import Region, Config, WitnessBank, discover, center_radius
from diameter_oracle import bounds
from exact_arithmetic import F, Q, sin_cos, point, pair_certifies, norm2, sub
from verify_cover import verify_partition
from certify_upper import run as verify_upper

ROOT = (0., 1005., 0., 1000.)


def centre_intervals(radius):
    sn, co = sin_cos(F(1))
    return ((radius*F(co[0], Q), radius*F(co[1], Q)),
            (-radius*F(sn[1], Q), -radius*F(sn[0], Q)))


CENTRES = [centre_intervals(F(r)) for r in (5, 1000)]


def excluded_exact(box):
    """True only if an entire rectangle violates a necessary disk constraint."""
    for centre in CENTRES:
        lower = sum((max(F(0), box[2*i]-hi, lo-box[2*i+1])**2
                     for i, (lo, hi) in enumerate(centre)), F(0))
        if lower > 1000**2:
            return True
    return False


def feasible_exact(p):
    if p[0] < 0 or p[1] < 0:
        return False
    return all(sum((max(abs(p[i]-lo), abs(p[i]-hi))**2
                    for i, (lo, hi) in enumerate(c)), F(0)) <= 1000**2
               for c in CENTRES)


def candidate(region):
    """A boundary search is only an upper-bound proposal, never a global proof."""
    d = math.radians(1)
    def pos(beta):
        b = math.radians(beta)
        return (5*math.cos(d)+999.99999*math.cos(b),
                -5*math.sin(d)+999.99999*math.sin(b))
    history = []
    def objective(beta):
        p = pos(beta)
        if not feasible_exact(point(p)):
            return 10000.
        value = bounds(region, p, tolerance=.002)['upper_m']
        history.append((value, p, beta))
        return value
    minimize_scalar(objective, bounds=(25, 45), method='bounded',
                    options={'xatol': 1e-5, 'maxiter': 45})
    value, p, beta = min(history)
    assert feasible_exact(point(p))
    return value, p, history


class ThresholdWitnessBank(WitnessBank):
    """Discard pairs too short to establish the requested fixed lower bound."""
    def __init__(self, region, threshold):
        super().__init__(region)
        self.threshold = threshold

    def add(self, kind, a, b):
        if kind == 1 and math.dist(a, b) > self.threshold+1e-6:
            super().add(kind, a, b)


def run(output, seconds=240., gap=.1, warm_start=None):
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    region = Region(config=Config(circle_sides=2048))
    upper, p, trials = candidate(region)
    print(json.dumps(dict(stage='candidate', point=p, upper=upper)), flush=True)
    # Round upwards with slack for the independent rational outer polygon.
    upper_q = F(math.ceil((upper+.002)*1000), 1000)
    target = upper_q-F(str(gap))
    bank = ThresholdWitnessBank(region, float(target))
    if warm_start:
        for k, ax, ay, bx, by, _ in np.load(warm_start/'witnesses.npz')['records']:
            bank.add(int(k), (ax, ay), (bx, by))
    def remember(kind, a, b):
        if kind != 1:
            return
        bank.add(kind, a, b)
        length = math.dist(a, b)
        for slack in (.005, .02, .05):
            if length > float(target)+slack:
                f = (float(target)+slack)/length
                x = tuple((a[k]+b[k])/2+f*(a[k]-b[k])/2 for k in (0, 1))
                y = tuple((a[k]+b[k])/2-f*(a[k]-b[k])/2 for k in (0, 1))
                bank.add(1, x, y)
    bounds(region, p, tolerance=.002, witness_callback=remember)
    heap = [(0., 0, ROOT)]
    closed, excluded = [], []
    serial = expanded = 0
    last = time.monotonic()
    while heap and time.monotonic()-started < seconds:
        _, _, box = heapq.heappop(heap)
        exact_box = tuple(F(x) for x in box)
        if excluded_exact(exact_box):
            excluded.append(box)
            continue
        low, idx = bank.lower(box)
        if low >= float(target)+1e-7:
            closed.append((box, idx))
            continue
        mid, radius = center_radius(box)
        ml, _ = bank.lower((mid[0], mid[0], mid[1], mid[1]))
        if ml < float(target)+.01:
            discover(region, mid, bank, float(target),
                     step=.1 if radius < 30 else .7, slack=.02)
            ml, _ = bank.lower((mid[0], mid[0], mid[1], mid[1]))
            if radius < 10 and ml < float(target)+.005:
                trial = bounds(region, mid, tolerance=.005, witness_callback=remember)
                if feasible_exact(point(mid)) and trial['upper_m'] < float(target):
                    raise RuntimeError('Better feasible candidate found; restart with new incumbent')
        low, idx = bank.lower(box)
        if low >= float(target)+1e-7:
            closed.append((box, idx))
            continue
        x0, x1, y0, y1 = box
        if x1-x0 >= y1-y0:
            m = (x0+x1)/2
            children = ((x0, m, y0, y1), (m, x1, y0, y1))
        else:
            m = (y0+y1)/2
            children = ((x0, x1, y0, m), (x0, x1, m, y1))
        for child in children:
            serial += 1
            heapq.heappush(heap, (low, serial, child))
        expanded += 1
        if time.monotonic()-last > 10:
            print(json.dumps(dict(stage='search', seconds=time.monotonic()-started,
                                  expanded=expanded, pending=len(heap), closed=len(closed),
                                  excluded=len(excluded), witnesses=len(bank.records))), flush=True)
            last = time.monotonic()
    pending = [box for _, _, box in heap]
    info = dict(s1=[0., 0.], theta_deg=0., best_point=p,
                proposed_upper=str(upper_q), proposed_lower=str(target),
                objective='worst posterior diameter under guaranteed second reception',
                full_position_domain=ROOT, expanded=expanded,
                pending=len(pending), search_complete=not pending,
                elapsed_s=time.monotonic()-started, candidate_trials=trials)
    (output/'result.json').write_text(json.dumps(info, indent=2))
    (output/'leaves.json').write_text(json.dumps(dict(closed=closed, excluded=excluded, pending=pending)))
    np.savez_compressed(output/'witnesses.npz', records=np.array(
        [[k, *a, *b, size] for k, a, b, size in bank.records]))
    print(json.dumps({k:v for k,v in info.items() if k!='candidate_trials'}), flush=True)
    return info


def verify(output):
    start = time.monotonic()
    info = json.loads((output/'result.json').read_text())
    leaves = json.loads((output/'leaves.json').read_text())
    if leaves['pending']:
        raise ValueError('Search unfinished; no global bound claimed')
    all_boxes = [b for b, _ in leaves['closed']]+leaves['excluded']
    verify_partition(ROOT, all_boxes)
    for box in leaves['excluded']:
        assert excluded_exact(tuple(F(x) for x in box))
    lower = F(info['proposed_lower'])
    records = np.load(output/'witnesses.npz')['records']
    for j, (box, idx) in enumerate(leaves['closed']):
        k, ax, ay, bx, by, _ = records[idx]
        assert int(k) == 1, 'A no-signal witness cannot certify a feasible receiving position'
        assert pair_certifies(1, point((ax, ay)), point((bx, by)),
                              tuple(F(x) for x in box), lower), (j, box, idx)
    p = point(info['best_point'])
    assert feasible_exact(p)
    upper = F(info['proposed_upper'])
    result_upper = verify_upper(output, output, upper)
    result = dict(status='verified_epsilon_global', scope='centre case, continuous +/-1 degree; guaranteed reception',
                  best_point=info['best_point'], position_exact=[str(x) for x in p],
                  lower_m=float(lower), upper_m=float(upper), gap_m=float(upper-lower),
                  lower_exact=str(lower), upper_exact=str(upper),
                  feasible_exact=True, partition_complete=True,
                  exact_lower_boxes=len(leaves['closed']), exact_excluded_boxes=len(leaves['excluded']),
                  direction_intervals=result_upper['direction_intervals'],
                  exact_zero_gap_optimum_proved=False, windows_called=False,
                  elapsed_s=time.monotonic()-start)
    (output/'verification.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--seconds', type=float, default=240)
    parser.add_argument('--gap', type=float, default=.1)
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--warm-start', type=Path)
    args = parser.parse_args()
    if not args.verify_only:
        result = run(args.output, args.seconds, args.gap, args.warm_start)
        if not result['search_complete']:
            raise SystemExit('Search unfinished; saved progress without a global certificate')
    verify(args.output)
