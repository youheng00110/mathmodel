import random
import unittest

from exact_arithmetic import (F, Q, pi_bounds, sin_cos, rational_sqrt_bounds,
                              norm2, sub, pair_certifies)
from certify_upper import hull, diameter2, clip, outside_disk_hull, bearing_plane


class ExactCertificateTests(unittest.TestCase):
    def test_pi_enclosure_has_expected_precision(self):
        lo, hi = pi_bounds()
        self.assertLess(F('3.1415926535897932384626433832795028841971'), lo)
        self.assertLess(hi, F('3.1415926535897932384626433832795028841972'))
        self.assertLess(hi-lo, F(1, 10**50))

    def test_exact_trig_values_and_quadrants(self):
        for angle, index, value in [(0,0,F(0)), (0,1,F(1)), (30,0,F(1,2)),
                                    (60,1,F(1,2)), (90,0,F(1)), (180,1,F(-1)),
                                    (270,0,F(-1)), (-30,0,F(-1,2)), (390,0,F(1,2))]:
            bounds = sin_cos(F(angle))[index]
            self.assertLessEqual(F(bounds[0], Q), value)
            self.assertGreaterEqual(F(bounds[1], Q), value)

    def test_sqrt_is_exactly_enclosed(self):
        for x in (F(0), F(2), F(4), F(1,10**48), F(123456789,17)):
            lo, hi = rational_sqrt_bounds(x)
            self.assertLessEqual(lo*lo, x)
            self.assertGreaterEqual(hi*hi, x)

    def test_calipers_matches_exhaustive_rational_distances(self):
        rng = random.Random(521)
        for _ in range(100):
            poly = hull([(F(rng.randrange(-100,101)), F(rng.randrange(-100,101))) for _ in range(30)])
            brute = max(norm2(sub(a,b)) for a in poly for b in poly)
            self.assertEqual(diameter2(poly), brute)

    def test_clipping_and_circle_exclusion(self):
        square = [(F(-2),F(-2)),(F(2),F(-2)),(F(2),F(2)),(F(-2),F(2))]
        self.assertEqual(diameter2(outside_disk_hull(square,(F(0),F(0)),F(1))), F(32))
        self.assertEqual(outside_disk_hull(square,(F(0),F(0)),F(3)), [])
        half = clip(square,(F(1),F(0)),F(0))
        self.assertTrue(all(x<=0 for x,y in half))
        self.assertEqual(diameter2(half), F(20))

    def test_exact_pair_rejects_wrong_radius_and_wrong_bearing(self):
        g,h = (F(1200),F(0)),(F(1400),F(0))
        self.assertFalse(pair_certifies(0,g,h,(F(0),F(0),F(0),F(0)),F(199)))
        self.assertTrue(pair_certifies(0,g,h,(F(-500),F(-490),F(-5),F(5)),F(199)))
        self.assertFalse(pair_certifies(1,g,h,(F(1300),F(1300),F(100),F(100)),F(199)))

    def test_rational_bearing_plane_contains_known_boundary(self):
        p = (F(7),F(9))
        # At exactly 0 degrees the lower boundary is the positive horizontal ray.
        n,b = bearing_plane(F(0), True, p, 4000)
        self.assertLessEqual(n[0]*(p[0]+100)+n[1]*p[1], b)
        self.assertLessEqual(n[0]*(p[0]+100)+n[1]*(p[1]+1), b)


if __name__ == '__main__':
    unittest.main()
