"""Check that saved closed and pending rectangles partition the search domain.

This independently checks coverage, not floating-point geometric validity.
"""
import argparse
import bisect
import json
from pathlib import Path


def verify_partition(root, boxes):
    x0, x1, y0, y1 = root
    if not boxes:
        raise ValueError('Empty partition')
    events = {}
    ys = {y0, y1}
    for a, b, c, d in boxes:
        if not (x0 <= a < b <= x1 and y0 <= c < d <= y1):
            raise ValueError('Invalid rectangle')
        ys.update((c, d))
        events.setdefault(a, []).append((c, d, 1))
        events.setdefault(b, []).append((c, d, -1))
    ys = sorted(ys)
    size = len(ys)-1
    low, high, lazy = [0]*(4*size), [0]*(4*size), [0]*(4*size)

    def add(i, a, b, q0, q1, value):
        if q0 <= a and b <= q1:
            low[i] += value
            high[i] += value
            lazy[i] += value
            return
        m = (a+b)//2
        if q0 < m:
            add(2*i, a, m, q0, q1, value)
        if q1 > m:
            add(2*i+1, m, b, q0, q1, value)
        low[i] = lazy[i]+min(low[2*i], low[2*i+1])
        high[i] = lazy[i]+max(high[2*i], high[2*i+1])

    previous = x0
    for x in sorted(events):
        if x > previous and (low[1] != 1 or high[1] != 1):
            raise ValueError(f'Gap or overlap between x={previous} and {x}')
        for c, d, value in events[x]:
            add(1, 0, size, bisect.bisect_left(ys, c), bisect.bisect_left(ys, d), value)
        previous = x
    if previous != x1 or low[1] != 0 or high[1] != 0:
        raise ValueError('Uncovered tail or unbalanced boundaries')
    return True


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('result_dir', type=Path)
    args = parser.parse_args()
    info = json.loads((args.result_dir/'result.json').read_text())
    closed = json.loads((args.result_dir/'closed_boxes.json').read_text())
    active = json.loads((args.result_dir/'remaining_boxes.json').read_text())
    boxes = [box for box, _ in closed]+[box for _, box in active]
    result = dict(partition_complete=verify_partition(info['full_position_domain'], boxes),
                  rectangles=len(boxes), geometry_interval_verified=False)
    (args.result_dir/'partition_check.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result))
