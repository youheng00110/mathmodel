"""Verify the delivered file manifest before regenerating any reports."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'文件校验.json').read_text(encoding='utf-8'))
errors=[]
for name,expected in manifest['sha256'].items():
    path=root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        errors.append(name)
print(json.dumps(dict(files=len(manifest['sha256']),ok=not errors,mismatches=errors),ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
