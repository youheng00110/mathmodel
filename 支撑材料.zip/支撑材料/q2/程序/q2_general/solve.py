"""Finite-budget continuous-domain search plus independent rational audit."""
import argparse
import heapq
import json
import math
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'q2_global'))
sys.path.insert(0,str(HERE.parent/'第二问'))
import numpy as np
from scipy.optimize import minimize
from geometry import classify, radial_samples, radial_interval, transform, STANDARD
from exact import ExactGeometry
from exact_arithmetic import F, point, norm2, sub, rational_sqrt_bounds
from search import WitnessBank, discover, center_radius
from q2.config import Config
from q2.feasible_region import Region
from oracle import bounds
from verify_cover import verify_partition


def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')


def polish(folder):
    """Improve the incumbent only; the saved full-domain lower proof survives."""
    data=json.loads((folder/'search.json').read_text(encoding='utf-8'))
    if data.get('method') in ('rigid_isometry','empty_or_singleton'):
        return verify(folder)
    geo=ExactGeometry(data['s1'],data['theta_deg'],data['circle_sides'])
    region=Region(data['s1'],data['theta_deg'],Config(circle_sides=data['circle_sides']))
    pn=np.array([[float(x) for x in g] for g in geo.near_outer])
    pf=np.array([[float(x) for x in g] for g in geo.far_outer])
    s1=np.array(data['s1'])
    def constraints(p):
        near=(1000.**2-np.sum((pn-p)**2,axis=1))/2000. if len(pn) else np.array([])
        far=(np.sum((pf-s1)**2,axis=1)-np.sum((pf-p)**2,axis=1))/3000. if len(pf) else np.array([])
        return np.concatenate((near,far))
    trials=[]
    def objective(p):
        if np.min(constraints(p))<-.00001:
            return 1e5
        val=bounds(region,tuple(p),tolerance=.003,seconds=1.)['upper_m']
        trials.append((val,list(map(float,p))))
        return val
    minimize(objective,np.array(data['best_point']),method='SLSQP',
             constraints=[dict(type='ineq',fun=constraints)],
             options=dict(maxiter=40,ftol=.001,eps=.01))
    old=data['best_point']
    old_upper,_=geo.upper(point(old),max_splits=data['feedback_splits'])
    new_upper=old_upper
    for _,p in sorted(trials)[:3]:
        if geo.safe(point(p)):
            u,_=geo.upper(point(p),max_splits=data['feedback_splits'])
            if u<new_upper:
                new_upper=u
                data['best_point']=p
    data.setdefault('polish_history',[]).append(dict(old_point=old,
        old_upper_exact=str(old_upper),new_upper_exact=str(new_upper),trials=trials))
    dump(folder/'search.json',data)
    return verify(folder)


def verify(folder):
    data=json.loads((folder/'search.json').read_text(encoding='utf-8'))
    geo=ExactGeometry(data['s1'],data['theta_deg'],data['circle_sides'])
    if data.get('method')=='empty_or_singleton':
        if not geo.outer:
            result=dict(status='incompatible_certified_by_empty_outer',
                        s1=data['s1'],theta_deg=data['theta_deg'],classification=data['classification'])
        else:
            assert len(geo.outer)==1 and geo.valid(geo.outer[0])
            result=dict(status='verified_exact_singleton',s1=data['s1'],theta_deg=data['theta_deg'],
                best_point=[float(x) for x in geo.outer[0]],point_exact=[str(x) for x in geo.outer[0]],
                lower_m=0.,upper_m=0.,gap_m=0.,reception_verified=True,
                exact_zero_gap_optimum_proved=True,simulator_called=False)
        dump(folder/'verification.json',result)
        return result
    if data.get('method')=='rigid_isometry':
        assert geo.full_sector_inside()
        # Re-run the original rational proof, not merely trust its status JSON.
        from reception_optimum import verify as centre_verify
        certificate=centre_verify(HERE.parent.parent/'最终证书')
        assert certificate['gap_m']<=.01
        result=dict(status='verified_epsilon_global_by_isometry',
            s1=data['s1'],theta_deg=data['theta_deg'],classification=data['classification'],
            lower_m=certificate['lower_m'],upper_m=certificate['upper_m'],gap_m=.01,
            point_definition='S1 + x*u +/- y*n; u=(cos(theta),sin(theta)), n=(-sin(theta),cos(theta))',
            local_point_exact=certificate['position_exact'],
            best_points_display_only=[transform(data['s1'],data['theta_deg'],(STANDARD[0],sign*STANDARD[1]))
                                      for sign in (-1,1)],
            exact_symbolic_point_reception_verified=True,
            rounded_display_coordinates_are_not_the_exact_symbolic_point=True,
            full_sector_containment_verified=True,simulator_called=False,
            exact_zero_gap_optimum_proved=False)
        dump(folder/'verification.json',result)
        return result
    p=point(data['best_point'])
    assert geo.safe(p),'Reception certificate failed'
    upper,feedback=geo.upper(p,tolerance=data['feedback_tolerance'],
                             max_splits=data['feedback_splits'])
    targets=[point(g) for g in data['targets']]
    assert targets and all(geo.valid(g) for g in targets)
    root=tuple(F(x) for x in data['root'])
    # One real possible target bounds the entire reception domain.
    g=targets[0]
    radius=rational_sqrt_bounds(max(F(1000**2),norm2(sub(g,geo.s1))))[1]
    assert root[0]<=g[0]-radius and root[1]>=g[0]+radius
    assert root[2]<=g[1]-radius and root[3]>=g[1]+radius
    leaves=data['leaves']
    verify_partition(root,[tuple(F(x) for x in row['box']) for row in leaves])
    records=data['pairs']
    lows=[]
    excluded=weakened=0
    for row in leaves:
        box=tuple(F(x) for x in row['box'])
        if row['kind']=='excluded':
            g=targets[row['target']]
            from exact_arithmetic import distance_box2
            if distance_box2(g,box)>max(F(1000**2),norm2(sub(g,geo.s1))):
                excluded+=1
                continue
        low=F(row.get('lower','0'))
        idx=row.get('pair')
        if idx is None:
            low=F(0)
        else:
            kind,g,h=records[idx]
            if not geo.pair(kind,point(g),point(h),box,low):
                low=F(0)
                weakened+=1
        lows.append(low)
    assert lows,'All boxes excluded despite a certified feasible candidate'
    lower=min(lows)
    assert lower<=upper
    gap=upper-lower
    result=dict(status='verified_epsilon_global' if gap<=F(str(data['requested_gap_m']))
                else 'verified_bounds_gap_open',
        s1=data['s1'],theta_deg=data['theta_deg'],classification=data['classification'],
        best_point=data['best_point'],lower_m=float(lower),upper_m=float(upper),
        gap_m=float(gap),lower_exact=str(lower),upper_exact=str(upper),
        requested_gap_m=data['requested_gap_m'],reception_verified=True,
        position_domain_covered=True,feedback_domain_covered=True,
        leaf_count=len(leaves),excluded_count=excluded,weakened_lower_checks=weakened,
        exact_zero_gap_optimum_proved=False,
        model='continuous bounded +/-1 degree; guaranteed direction OR near; diameter',
        simulator_called=False)
    dump(folder/'feedback_certificate.json',feedback)
    dump(folder/'verification.json',result)
    return result


def run(args):
    start=time.monotonic()
    folder=args.output
    folder.mkdir(parents=True,exist_ok=True)
    classification=classify(args.s1,args.theta)
    geo=ExactGeometry(args.s1,args.theta,args.circle_sides)
    if not geo.outer:
        dump(folder/'search.json',dict(method='empty_or_singleton',s1=list(args.s1),
             theta_deg=args.theta,circle_sides=args.circle_sides,classification=classification))
        return verify(folder)
    if len(geo.outer)==1 and geo.valid(geo.outer[0]):
        dump(folder/'search.json',dict(method='empty_or_singleton',s1=list(args.s1),
             theta_deg=args.theta,circle_sides=args.circle_sides,classification=classification))
        return verify(folder)
    if not args.force_search and geo.full_sector_inside():
        dump(folder/'search.json',dict(method='rigid_isometry',s1=list(args.s1),
            theta_deg=args.theta,circle_sides=args.circle_sides,classification=classification))
        return verify(folder)
    targets=[point(g) for g in radial_samples(args.s1,args.theta,61)]
    targets=list(dict.fromkeys(g for g in targets if geo.valid(g)))
    if not targets:
        result=dict(status='degenerate_or_unresolved_no_inner_witness',
                    classification=classification,global_optimum_claimed=False,
                    explanation='Outer geometry nonempty; not a proof of incompatible input.')
        dump(folder/'verification.json',result)
        return result
    # Select a short-radius target to tighten the certified full search rectangle.
    targets.sort(key=lambda g:max(F(1000**2),norm2(sub(g,geo.s1))))
    targets=targets[:1]+targets[1::max(1,len(targets)//45)]
    region=Region(args.s1,args.theta,Config(circle_sides=args.circle_sides))
    bank=WitnessBank(region)
    pn=np.asarray([[float(x) for x in g] for g in geo.near_outer])
    pf=np.asarray([[float(x) for x in g] for g in geo.far_outer])
    s1=np.array(args.s1,dtype=float)
    def constraints(p):
        values=[]
        if len(pn):
            values.extend((1000.**2-np.sum((pn-p)**2,axis=1))/2000.)
        if len(pf):
            values.extend((np.sum((pf-s1)**2,axis=1)-np.sum((pf-p)**2,axis=1))/3000.)
        return np.asarray(values)
    history=[]
    def evaluate(p,accurate=False):
        if math.dist(p,s1)<1e-7 or np.min(constraints(p)) < -.00001:
            return 1e5+max(0.,-float(np.min(constraints(p))))
        value=bounds(region,tuple(p),tolerance=.025 if accurate else .25,
                     seconds=2. if accurate else .35,
                     witness_callback=lambda k,a,b:bank.add(k,a,b))['upper_m']
        history.append((value,tuple(map(float,p))))
        return value
    seeds=[transform(args.s1,args.theta,(STANDARD[0]*.999,sign*STANDARD[1]*.999))
           for sign in (-1,1)]
    # Geometry-scaled starts are crucial when the first sector is heavily cut.
    local=[]
    for g in targets:
        d=np.array([float(x) for x in g])-s1
        t=math.radians(args.theta)
        local.append(d[0]*math.cos(t)+d[1]*math.sin(t))
    lo,hi=min(local),max(local)
    for sign in (-1,1):
        for y in (.2,.5,.8):
            seeds.append(transform(args.s1,args.theta,((lo+hi)/2,sign*min(650.,max(20.,hi-lo)*y))))
    for p in seeds:
        evaluate(p)
    # Keep both reflection branches in asymmetric cases. SLSQP is a proposal
    # mechanism only; all reported safety and global bounds are rechecked.
    feasible_seeds=sorted(history)[:4]
    for _,p in feasible_seeds:
        if time.monotonic()-start > args.seconds*.45:
            break
        minimize(evaluate,np.array(p),method='SLSQP',
                 constraints=[dict(type='ineq',fun=constraints)],
                 options=dict(maxiter=30,ftol=.02,eps=.2))
    accepted=[]
    for value,p in sorted(history):
        # A small move toward S1 creates margin; S1 satisfies all true reception
        # constraints but outer geometry can slightly overconstrain it.
        for alpha in (1.,.99999,.9999,.999):
            q=tuple(float(s1[i]+alpha*(p[i]-s1[i])) for i in (0,1))
            if geo.safe(point(q)):
                accepted.append((evaluate(q,True),q))
                break
        if len(accepted)>=3:
            break
    if not accepted:
        raise RuntimeError('No certified feasible proposal. Increase --circle-sides; no unsafe output emitted.')
    upper_est,best=min(accepted)
    print(json.dumps(dict(stage='candidate',point=best,upper_estimate=upper_est,
                          elapsed_s=time.monotonic()-start)),flush=True)
    discover(region,best,bank,max(0.,upper_est-args.gap),step=.3,slack=.02)
    # A global bank of real target pairs gives inexpensive lower bounds far
    # from the incumbent; feedback searches are reserved for difficult boxes.
    grid=[]
    for eps in (-.999999,0.,.999999):
        interval=radial_interval(args.s1,args.theta,eps)
        if interval:
            lo,hi=interval
            for r in np.linspace(lo+.00001,hi-.00001,70):
                g=transform(args.s1,args.theta+eps,(float(r),0.))
                if geo.valid(point(g)):
                    grid.append(g)
    for i,g in enumerate(grid):
        for h in grid[i+1:]:
            distance=math.dist(g,h)
            if max(0.,upper_est-args.gap-1.) < distance < max(15.,upper_est*2.5):
                bank.add(1,g,h)
            if distance<10. and distance>max(0.,upper_est-args.gap-1.):
                bank.add(2,g,h)
    # Drop all no-signal pairs: this is a reception-constrained model.
    bank.records=[r for r in bank.records if r[0] in (1,2)]
    bank._array=None
    # Keys may contain removed entries; new no-signal witnesses are never used.
    g=targets[0]
    rr=rational_sqrt_bounds(max(F(1000**2),norm2(sub(g,geo.s1))))[1]
    root=(math.floor(g[0]-rr),math.ceil(g[0]+rr),
          math.floor(g[1]-rr),math.ceil(g[1]+rr))
    heap=[(0.,0,root)]
    leaves=[]
    serial=expanded=0
    def record(box):
        low,idx=bank.lower(box)
        # Save a downward decimal lower bound; independent audit is decisive.
        low=max(0.,math.floor(low*1000)/1000.)
        return dict(box=box,kind='bounded',lower=str(low),pair=idx)
    target_array=np.array([[float(x) for x in g] for g in targets])
    radii=np.array([float(max(F(1000**2),norm2(sub(g,geo.s1)))) for g in targets])
    while heap and time.monotonic()-start < args.seconds:
        _,_,box=heapq.heappop(heap)
        low_corner=np.array([box[0],box[2]])
        high_corner=np.array([box[1],box[3]])
        d=np.maximum(np.maximum(low_corner-target_array,target_array-high_corner),0.)
        ids=np.flatnonzero(np.sum(d*d,axis=1)>radii+1e-5)
        if len(ids):
            leaves.append(dict(box=box,kind='excluded',target=int(ids[0])))
            continue
        row=record(box)
        if float(row['lower'])>=upper_est-args.gap*.7:
            leaves.append(row)
            continue
        mid,radius=center_radius(box)
        if expanded%80==0 or (radius<5 and expanded%3==0):
            discover(region,mid,bank,max(0.,upper_est-args.gap),
                     step=.5 if radius<50 else 2.,slack=.02)
            # No-signal pairs cannot lower-bound U on feasible positions; they
            # can only hold on infeasible boxes, which are separately excluded.
            bank.records=[r for r in bank.records if r[0] in (1,2)]
            bank._array=None
            row=record(box)
        if radius<40 and np.min(constraints(mid))>.001:
            val=evaluate(mid)
            if val<upper_est and geo.safe(point(mid)):
                upper_est,best=val,mid
        if float(row['lower'])>=upper_est-args.gap*.7:
            leaves.append(row)
            continue
        if radius<.0001:
            leaves.append(row)
            continue
        x0,x1,y0,y1=box
        if x1-x0>=y1-y0:
            m=(x0+x1)/2
            children=((x0,m,y0,y1),(m,x1,y0,y1))
        else:
            m=(y0+y1)/2
            children=((x0,x1,y0,m),(x0,x1,m,y1))
        for child in children:
            serial+=1
            heapq.heappush(heap,(float(row['lower']),serial,child))
        expanded+=1
    leaves.extend(record(box) for _,_,box in heap)
    data=dict(s1=list(args.s1),theta_deg=args.theta,classification=classification,
        circle_sides=args.circle_sides,best_point=best,root=root,
        targets=[[float(x) for x in g] for g in targets],
        pairs=[[k,a,b] for k,a,b,_ in bank.records],leaves=leaves,
        requested_gap_m=args.gap,feedback_tolerance=args.feedback_tolerance,
        feedback_splits=args.feedback_splits,expanded=expanded,pending=len(heap),
        search_seconds=time.monotonic()-start,proposal_history=history)
    dump(folder/'search.json',data)
    return verify(folder)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--s1',type=float,nargs=2,default=(0.,0.))
    p.add_argument('--theta',type=float,default=0.)
    p.add_argument('--seconds',type=float,default=120.)
    p.add_argument('--gap',type=float,default=.5)
    p.add_argument('--circle-sides',type=int,default=512)
    p.add_argument('--feedback-tolerance',type=float,default=.1)
    p.add_argument('--feedback-splits',type=int,default=600)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--verify-only',action='store_true')
    p.add_argument('--force-search',action='store_true',help='Do not reuse the standard-case certificate')
    p.add_argument('--polish',action='store_true',help='Improve saved candidate, retaining existing global lower proof')
    args=p.parse_args()
    if not all(math.isfinite(x) for x in (*args.s1,args.theta,args.seconds,args.gap,args.feedback_tolerance)):
        p.error('All numeric inputs must be finite')
    if args.seconds<=0 or args.gap<=0 or args.circle_sides<32 or args.feedback_tolerance<=0 or args.feedback_splits<0:
        p.error('Positive time/gap/tolerance, nonnegative splits and at least 32 circle sides required')
    if args.verify_only and args.polish:
        p.error('--verify-only and --polish are mutually exclusive')
    print(json.dumps(verify(args.output) if args.verify_only else polish(args.output) if args.polish else run(args),
                     ensure_ascii=False,indent=2))
