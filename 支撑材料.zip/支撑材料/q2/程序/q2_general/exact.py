"""General rational enclosure checks. Search proposals are never trusted.

Uses the unchanged centre package's outward Taylor trigonometry and rational
polygon operations. Global positions, first bearing and all saved floats are
interpreted as their exact binary rational values (angles in degrees).
"""
import math
from functools import lru_cache
from exact_arithmetic import (F, Q, S, point, norm2, sub, dot, cross,
    sin_cos, rational_sqrt_bounds, tangent_bounds, distance_box2, clamp)
from certify_upper import clip, hull, diameter2, outside_disk_hull, bearing_plane


def interval_dot(intervals, v):
    ends = [sorted((a*x, b*x)) for (a, b), x in zip(intervals, v)]
    return sum(x[0] for x in ends), sum(x[1] for x in ends)


class ExactGeometry:
    def __init__(self, s1, theta, sides=512):
        self.s1, self.theta = point(s1), F.from_float(float(theta))
        self.sides = sides
        self._valid = {}
        p = [(F(-1800),F(-1800)), (F(1800),F(-1800)),
             (F(1800),F(1800)), (F(-1800),F(1800))]
        p = self.disk(p, (F(0), F(0)), F(1800))
        p = self.disk(p, self.s1, F(1500))
        extent = math.ceil(1801+max(abs(float(x)) for x in self.s1))
        for angle, lower in ((self.theta-1, True), (self.theta+1, False)):
            p = clip(p, *bearing_plane(angle, lower, self.s1, extent))
        # Every target r>5 in the first wedge satisfies u.(g-S1)>5*cos(delta).
        sn, co = sin_cos(self.theta)
        u = (F((co[0]+co[1])//2,Q), F((sn[0]+sn[1])//2,Q))
        err = sum(max(abs(u[i]-F(z,Q)) for z in ends)
                  for i, ends in enumerate((co,sn))) * extent
        coslo = F(sin_cos(F(1))[1][0],Q)
        p = clip(p, (-u[0],-u[1]), -dot(u,self.s1)-5*coslo+err)
        self.outer = hull(p)
        if norm2(self.s1)==3300**2:
            # Equality in the triangle inequality fixes the unique intersection
            # of B(0,1800) and B(S1,1500), beyond finite support polygons.
            g=tuple(F(1800,3300)*x for x in self.s1)
            if self.valid(g):
                self.outer=[g]
        self.near_outer = self.disk(self.outer, self.s1, F(1000))
        self.far_outer = outside_disk_hull(self.outer, self.s1, F(1000))

    def full_sector_inside(self):
        """Sufficient exact end-arc test, also valid for exterior first stations."""
        candidates=[]
        for angle in (self.theta-1,self.theta+1):
            sn,co=sin_cos(angle)
            candidates.append(interval_dot(((F(co[0],Q),F(co[1],Q)),
                                            (F(sn[0],Q),F(sn[1],Q))),self.s1)[1])
        # A maximum in the angular interior occurs only in the S1 direction.
        # Unless exclusion of that direction is certified, include ||S1||.
        outside=False
        for angle,lower in ((self.theta-1,True),(self.theta+1,False)):
            sn,co=sin_cos(angle)
            lo,hi=interval_dot(((F(-sn[1],Q),F(-sn[0],Q)),
                                (F(co[0],Q),F(co[1],Q))),self.s1)
            outside=outside or (hi<0 if lower else lo>0)
        if not outside:
            candidates.append(rational_sqrt_bounds(norm2(self.s1))[1])
        support=max(candidates)
        return all(norm2(self.s1)+r*r+2*r*support<=1800**2 for r in (5,1500))

    def disk(self, poly, center, radius):
        # Exact cardinal support planes also preserve rational tangencies.
        for n in ((F(1),F(0)),(F(-1),F(0)),(F(0),F(1)),(F(0),F(-1))):
            poly=clip(poly,n,dot(n,center)+radius)
        for i in range(self.sides):
            a = 2*math.pi*i/self.sides
            n = (F(round(math.cos(a)*S),S),F(round(math.sin(a)*S),S))
            _, upper = rational_sqrt_bounds(norm2(n), S)
            poly = clip(poly, n, dot(n,center)+radius*upper)
            if not poly:
                break
        return hull(poly)

    def valid(self, g):
        if g in self._valid:
            return self._valid[g]
        d = sub(g,self.s1)
        ok = norm2(g) <= 1800**2 and 25 < norm2(d) <= 1500**2
        for angle, lower in ((self.theta-1,True),(self.theta+1,False)):
            sn, co = sin_cos(angle)
            intervals = ((F(-sn[1],Q),F(-sn[0],Q)),
                         (F(co[0],Q),F(co[1],Q)))
            lo, hi = interval_dot(intervals,d)
            ok = ok and (lo >= 0 if lower else hi <= 0)
        self._valid[g] = bool(ok)
        return bool(ok)

    def safe(self, p):
        if not self.outer or p == self.s1:
            return False
        if any(norm2(sub(p,g)) > 1000**2 for g in self.near_outer):
            return False
        return all(norm2(sub(p,g)) <= norm2(sub(self.s1,g)) for g in self.far_outer)

    def excluded(self, box, targets):
        for i,g in enumerate(targets):
            if self.valid(g) and distance_box2(g,box) > max(F(1000**2),norm2(sub(g,self.s1))):
                return i
        return None

    def pair(self, kind, g, h, box, lower):
        if not self.valid(g) or not self.valid(h) or norm2(sub(g,h)) < lower*lower:
            return False
        if kind == 2:
            return all(distance_box2(x,box,True) <= 25 for x in (g,h))
        if kind != 1 or not all(distance_box2(x,box)>25 and
                               distance_box2(x,box,True)<=1500**2 for x in (g,h)):
            return False
        t = tangent_bounds(F(2))[0]
        mid = ((g[0]+h[0])/2,(g[1]+h[1])/2)
        ell = (g[1]-h[1],h[0]-g[0])
        for sign in (-1,1):
            p = (clamp(mid[0]+sign*ell[0]/(2*t),box[0],box[1]),
                 clamp(mid[1]+sign*ell[1]/(2*t),box[2],box[3]))
            a,b = sub(g,p),sub(h,p)
            if sign*cross(a,b)-t*dot(a,b)>0:
                return False
        return True

    def upper(self, p, tolerance=.1, max_splits=800, halfwidth=F(0)):
        """All 360 degrees covered even if the refinement budget is exhausted."""
        import heapq
        if not self.safe(p):
            raise ValueError('Candidate has no rational reception certificate')
        halfwidth=F(halfwidth)
        if halfwidth<0:
            raise ValueError('Negative box width')
        corners=[(p[0]+i*halfwidth,p[1]+j*halfwidth) for i in (-1,1) for j in (-1,1)]
        if halfwidth and (any(not self.safe(q) for q in corners) or
                          all(abs(p[i]-self.s1[i])<=halfwidth for i in (0,1))):
            raise ValueError('Entire candidate rectangle is not certified feasible')
        if not self.outer:
            raise ValueError('Empty enclosing geometry')
        nr=F(5)+rational_sqrt_bounds(2*halfwidth*halfwidth)[1]
        near = self.disk(self.outer,p,nr)
        # Keeping the >5 holes filled is conservative for direction upper bounds.
        base = self.outer
        extent = math.ceil(max(abs(float(g[i]-p[i])) for g in base for i in (0,1))+float(halfwidth))+1
        constant = min(F(100),diameter2(near))
        def bound(a,b):
            poly = base
            for angle,lower in ((a-1,True),(b+1,False)):
                n,boundary=bearing_plane(angle,lower,p,extent)
                boundary+=halfwidth*(abs(n[0])+abs(n[1]))
                poly = clip(poly,n,boundary)
            return diameter2(poly)
        heap = []
        sampled_lower = F(0)
        for i in range(16):
            a,b=F(45*i,2),F(45*(i+1),2)
            heapq.heappush(heap,(-bound(a,b),a,b))
        # Refinement targets the upper-envelope geometry. The midpoint bound is
        # NOT a true lower bound on the real target set; used only to prioritize.
        for _ in range(max_splits):
            neg,a,b=heapq.heappop(heap)
            if b-a <= F(str(tolerance/100.)):
                heapq.heappush(heap,(neg,a,b))
                break
            m=(a+b)/2
            heapq.heappush(heap,(-bound(a,m),a,m))
            heapq.heappush(heap,(-bound(m,b),m,b))
        value=max(constant,-heap[0][0])
        upper=rational_sqrt_bounds(value)[1]
        return upper,dict(near_squared=str(constant),
            intervals=[[str(a),str(b),str(-d)] for d,a,b in sorted(heap,key=lambda r:r[1])],
            upper_m_exact=str(upper),reception_verified=True,
            all_feedback_covered=True,outer_vertices=len(base),
            station_rectangle_halfwidth_exact=str(halfwidth))
