"""Reproduce standalone scientific figures; plots do not replace certificates."""
import json
import math
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'q2_global'))
from exact import ExactGeometry
from geometry import radial_interval,transform


def run(root):
    figures=root/'一般情形图';figures.mkdir(exist_ok=True)
    selection=[('边界朝外','Outward'),('边界切向精修','Tangential'),
               ('圆外朝内','Exterior inward'),('边界斜向','Oblique')]
    for name,label in selection:
        folder=root/'一般案例'/name
        if not (folder/'search.json').exists():continue
        data=json.loads((folder/'search.json').read_text(encoding='utf-8'))
        v=json.loads((folder/'verification.json').read_text(encoding='utf-8'))
        geo=ExactGeometry(data['s1'],data['theta_deg'],data['circle_sides'])
        s1=np.array(data['s1']);p=np.array(data['best_point'])
        eps=np.linspace(-1,1,501)
        low=[];high=[]
        for e in eps:
            iv=radial_interval(s1,data['theta_deg'],float(e))
            if iv:
                low.append(transform(s1,data['theta_deg']+e,(iv[0],0.)))
                high.append(transform(s1,data['theta_deg']+e,(iv[1],0.)))
        source=np.array(low+high[::-1])
        fig,axes=plt.subplots(1,2,figsize=(12,5.4),layout='constrained')
        ax=axes[0]
        ax.add_patch(Circle((0,0),1800,facecolor='#f4f5f7',edgecolor='#68788b',lw=1.2))
        if len(source):ax.fill(source[:,0],source[:,1],color='#ef9a35',label='First feasible source set')
        ax.scatter(*s1,color='#245bb2',s=48,label='First station')
        ax.scatter(*p,color='#b52c39',s=85,marker='*',label='Certified second station')
        ax.plot([s1[0],p[0]],[s1[1],p[1]],'--',color='#7d8793',lw=.8)
        limit=max(1950,float(np.max(np.abs(s1)))+120,float(np.max(np.abs(p)))+120)
        ax.set_xlim(-limit,limit);ax.set_ylim(-limit,limit)
        ax.set_title(label+' / target disk 1800 m')
        ax.legend(fontsize=8,loc='lower left')
        ax=axes[1]
        x0,x1,y0,y1=data['root']
        xx,yy=np.meshgrid(np.linspace(x0,x1,181),np.linspace(y0,y1,181))
        points=np.column_stack((xx.ravel(),yy.ravel()))
        safe=np.ones(len(points),dtype=bool)
        for g in geo.near_outer:
            g=np.array(list(map(float,g)))
            safe &=np.sum((points-g)**2,axis=1)<=1000.**2
        for g in geo.far_outer:
            g=np.array(list(map(float,g)))
            safe &=np.sum((points-g)**2,axis=1)<=np.sum((s1-g)**2)
        ax.contourf(xx,yy,safe.reshape(xx.shape).astype(float),levels=[.5,1.5],colors=['#d5e8f3'])
        if len(source):ax.fill(source[:,0],source[:,1],color='#ef9a35',zorder=3)
        ax.scatter(*s1,color='#245bb2',s=40,zorder=4)
        ax.scatter(*p,color='#b52c39',s=100,marker='*',zorder=5)
        ax.set_title('Reception domain (plot only)\n'+
                     f"{math.floor(v['lower_m']*1000)/1000:.3f} <= V* <= {math.ceil(v['upper_m']*1000)/1000:.3f} m")
        for ax in axes:
            ax.set_aspect('equal');ax.set_xlabel('x / m');ax.set_ylabel('y / m')
            ax.grid(alpha=.15)
        fig.savefig(figures/(name+'.png'),dpi=180)
        fig.savefig(figures/(name+'.svg'))
        plt.close(fig)


if __name__=='__main__':
    run(HERE.parent.parent)
