import math
from pathlib import Path
import sys
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parent/'q2_global'))
sys.path.insert(0,str(HERE.parent/'第二问'))
from geometry import classify,radial_interval,transform,STANDARD
from exact import ExactGeometry
from exact_arithmetic import F,point,norm2,sub
from verify_cover import verify_partition


class GeneralGeometryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.centre=ExactGeometry((0,0),0,128)
        cls.outward=ExactGeometry((1700,0),0,128)

    def test_center_class(self):
        self.assertEqual(classify((0,0),0)['case'],'unclipped')

    def test_inward_unclipped(self):
        self.assertEqual(classify((1700,0),180)['case'],'unclipped')

    def test_outward_symmetric(self):
        self.assertEqual(classify((1700,0),0)['case'],'clipped_symmetric')

    def test_tangent_asymmetric(self):
        self.assertEqual(classify((1700,0),90)['case'],'clipped_asymmetric')

    def test_exterior_not_unclipped(self):
        self.assertNotEqual(classify((1900,0),180)['case'],'unclipped')
        lo,hi=radial_interval((1900,0),180,0)
        self.assertAlmostEqual(lo,100.)
        self.assertAlmostEqual(hi,1500.)

    def test_no_intersection(self):
        self.assertIsNone(radial_interval((4000,0),0,0))
        self.assertEqual(classify((4000,0),0)['case'],'incompatible_numerical')

    def test_direction_excludes_five(self):
        self.assertFalse(self.centre.valid(point((5.,0.))))
        self.assertTrue(self.centre.valid(point((5.0001,0.))))

    def test_arena_and_wedge(self):
        self.assertTrue(self.outward.valid(point((1750.,0.))))
        self.assertFalse(self.outward.valid(point((1801.,0.))))
        self.assertFalse(self.outward.valid(point((1750.,20.))))

    def test_full_sector_exact(self):
        self.assertTrue(self.centre.full_sector_inside())
        self.assertFalse(self.outward.full_sector_inside())
        self.assertFalse(ExactGeometry((1900,0),180,64).full_sector_inside())

    def test_isometry_rotation(self):
        g=ExactGeometry((0,100),90,128)
        self.assertTrue(g.full_sector_inside())
        self.assertTrue(g.valid(point((0.,600.))))

    def test_inward_rotation(self):
        g=ExactGeometry((1700,0),180,64)
        self.assertTrue(g.full_sector_inside())

    def test_safe_conservative_standard(self):
        p=point((STANDARD[0]*.999,STANDARD[1]*.999))
        self.assertTrue(self.centre.safe(p))

    def test_cut_subset_fallback_safe(self):
        p=point(transform((1700,0),0,(STANDARD[0]*.999,STANDARD[1]*.999)))
        self.assertTrue(self.outward.safe(p))

    def test_same_station_excluded(self):
        self.assertFalse(self.centre.safe(point((0.,0.))))

    def test_three_radial_constraints(self):
        # Piecewise endpoint reduction checked against an independently dense
        # radial sweep, including intervals crossing Rmin and far-only intervals.
        for lo,hi in ((5,1500),(100,600),(1100,1500)):
            for p in ((750,600),(0,0),(1600,300),(-100,0)):
                for eps in (-1,0,1):
                    v=(math.cos(math.radians(eps)),math.sin(math.radians(eps)))
                    fun=lambda r:sum((p[i]-r*v[i])**2 for i in (0,1))-max(1000,r)**2
                    knots=[lo,hi]+([1000] if lo<1000<hi else [])
                    exactmax=max(map(fun,knots))
                    densemax=max(fun(lo+(hi-lo)*i/1000) for i in range(1001))
                    self.assertLessEqual(densemax,exactmax+1e-7)

    def test_pair_rejects_no_signal(self):
        self.assertFalse(self.centre.pair(0,point((500,0)),point((700,0)),
                                         (F(800),F(801),F(500),F(501)),F(10)))

    def test_pair_direction_and_near(self):
        g,h=point((500,0)),point((505,0))
        self.assertTrue(self.centre.pair(1,g,h,(F(0),F(1),F(0),F(1)),F(5)))
        self.assertTrue(self.centre.pair(2,g,h,(F(502),F(503),F(0),F(1)),F(5)))
        self.assertFalse(self.centre.pair(1,g,h,(F(502),F(503),F(0),F(1)),F(5)))

    def test_partition_detects_missing_region(self):
        self.assertTrue(verify_partition((0,2,0,2),[(0,1,0,2),(1,2,0,2)]))
        with self.assertRaises(ValueError):
            verify_partition((0,2,0,2),[(0,1,0,2)])

    def test_degenerate_input_not_misreported(self):
        # The inward tangent to the first-near exclusion can leave no direction
        # target; a floating equality is explicitly flagged, not called ordinary.
        self.assertEqual(classify((1805,0),0)['case'],'incompatible_numerical')

    def test_upper_covers_all_feedback_even_when_budget_ends(self):
        p=point((1750.,70.))
        upper,certificate=self.outward.upper(p,max_splits=4)
        rows=certificate['intervals']
        self.assertEqual(F(rows[0][0]),0)
        self.assertEqual(F(rows[-1][1]),360)
        self.assertTrue(all(F(a[1])==F(b[0]) for a,b in zip(rows,rows[1:])))
        self.assertTrue(all(F(row[2])<=upper*upper for row in rows))

    def test_uniform_rectangle_rejects_unsafe_corner(self):
        with self.assertRaises(ValueError):
            self.outward.upper(point((1750.,70.)),max_splits=1,halfwidth=F(1500))

    def test_exclusion_witness_is_real_target(self):
        g=point((1750.,0.))
        self.assertEqual(self.outward.excluded((F(-2000),F(-1900),F(0),F(10)),[g]),0)
        self.assertIsNone(self.outward.excluded((F(-2000),F(-1900),F(0),F(10)),[point((0.,0.))]))

    def test_exact_tangent_singleton(self):
        g=ExactGeometry((3300,0),180,64)
        self.assertEqual(g.outer,[point((1800.,0.))])
        self.assertTrue(g.valid(g.outer[0]))


if __name__=='__main__':
    unittest.main(verbosity=2)
