"""Certify inner rectangles of a near-optimal candidate region, never a grid boundary."""
import argparse
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'q2_global'))
from exact import ExactGeometry
from exact_arithmetic import F,point


def run(folder,etas=(.02,.05,.1),halfwidth=.1,splits=400):
    from solve import verify
    verification=verify(folder)
    data=json.loads((folder/'search.json').read_text(encoding='utf-8'))
    if data.get('method')=='rigid_isometry':
        return dict(status='use_symbolic_transformed_point',
            explanation='Certified standard point lies in all requested near-optimal sets; no rectangle claimed.')
    if data.get('method')=='empty_or_singleton':
        return dict(status='empty_or_singleton_exact_special_case',
                    verification=verification)
    lower=F(verification['lower_exact'])
    if lower<=0:
        return dict(status='lower_bound_too_weak',rectangles=[],
                    explanation='No positive threshold certificate; feasible domain is still a candidate region.')
    geo=ExactGeometry(data['s1'],data['theta_deg'],data['circle_sides'])
    p=point(data['best_point'])
    point_upper,_=geo.upper(p,max_splits=splits)
    result=[]
    for eta in etas:
        if point_upper>(1+F(str(eta)))*lower:
            continue  # The available centre upper bound cannot certify this eta.
        width=F(str(halfwidth))
        for _ in range(8):
            try:
                upper,certificate=geo.upper(p,max_splits=splits,halfwidth=width)
            except ValueError:
                width/=2
                continue
            if upper<=(1+F(str(eta)))*lower:
                result.append(dict(eta=eta,center=data['best_point'],
                    halfwidth_exact=str(width),uniform_upper_exact=str(upper),
                    global_lower_exact=str(lower),certificate=certificate))
                break
            width/=2
    report=dict(status='certified_inner_rectangles' if result else 'no_rectangle_certified',
                rectangles=result,entire_near_optimal_boundary_certified=False)
    (folder/'candidate_rectangles.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('folder',type=Path)
    p.add_argument('--halfwidth',type=float,default=.1)
    p.add_argument('--splits',type=int,default=400)
    a=p.parse_args()
    print(json.dumps(run(a.folder,halfwidth=a.halfwidth,splits=a.splits),ensure_ascii=False,indent=2))
