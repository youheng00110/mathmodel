"""General first-bearing geometry; no simulator or random-error-field model."""
import math

STANDARD = (843.3652127578218, 545.0205008607356)


def wrap(a):
    return (a + 180.) % 360. - 180.


def radial_interval(s1, theta, epsilon):
    a = math.radians(theta + epsilon)
    v = (math.cos(a), math.sin(a))
    b = sum(x*y for x, y in zip(s1, v))
    disc = b*b + 1800.**2 - sum(x*x for x in s1)
    if disc < 0:
        return None
    lo, hi = max(5., -b-math.sqrt(disc)), min(1500., -b+math.sqrt(disc))
    if hi < lo or hi <= 5.:
        return None
    return lo, hi  # lo=5 is a limiting endpoint, NOT an allowed target.


def classify(s1, theta):
    r1 = math.hypot(*s1)
    psi = wrap(theta-math.degrees(math.atan2(s1[1], s1[0]))) if r1 else 0.
    cmax = math.cos(math.radians(max(abs(psi)-1., 0.)))
    cmin = math.cos(math.radians(min(abs(psi)+1., 180.)))
    h = lambda r, c: r1*r1+r*r+2*r1*r*c
    end_max = max(h(5., cmax), h(1500., cmax))
    rmin = min(1500., max(5., -r1*cmin))
    minimum = h(rmin, cmin)
    symmetric = r1 == 0 or abs(math.sin(math.radians(psi))) < 1e-12
    if minimum > 1800.**2+1e-6:
        kind = 'incompatible_numerical'
    elif end_max < 1800.**2-1e-6:
        kind = 'unclipped'
    elif abs(end_max-1800.**2) <= 1e-6 or abs(minimum-1800.**2) <= 1e-6:
        kind = 'boundary_equality_requires_exact_check'
    else:
        kind = 'clipped_symmetric' if symmetric else 'clipped_asymmetric'
    return dict(case=kind, radius_m=r1, relative_bearing_deg=psi,
                end_max_squared=end_max, minimum_squared=minimum,
                classification_arithmetic='floating; certification is separate')


def transform(s1, theta, xy):
    t = math.radians(theta)
    return (s1[0]+xy[0]*math.cos(t)-xy[1]*math.sin(t),
            s1[1]+xy[0]*math.sin(t)+xy[1]*math.cos(t))


def radial_samples(s1, theta, n=81):
    points = []
    for i in range(n):
        eps = -1.+2.*(i+.1)/(n-.8)
        interval = radial_interval(s1, theta, eps)
        if interval is None:
            continue
        lo, hi = interval
        if hi <= lo:
            continue
        for r in (lo+.0001*(hi-lo), (lo+hi)/2, hi-.0001*(hi-lo), 1000.):
            if max(5., lo) < r < hi:
                points.append(transform(s1, theta+eps, (r, 0.)))
    return points
