"""Adaptive continuous-feedback upper/lower bounds at one second position.

The maximization over feedback angles uses a heap of enclosing angle intervals.
Only intervals whose upper bound can beat the incumbent lower bound are split.
This remains a floating-point enclosure calculation, not interval arithmetic.
"""
import heapq
import math
import time

from q2.geometry import distance, diameter, disk_clip, bearing_clip, clip, outside_hull, wrap
from q2.candidate_evaluator import angle_interval


def bounds(region, p, tolerance=.001, seconds=5., witness_callback=None):
    started = time.monotonic()
    c = region.cfg
    margin = 1e-6
    n = tuple(2*(p[k]-region.s1[k]) for k in (0, 1))
    offset = sum(v*v for v in p)-sum(v*v for v in region.s1)

    def valid(g, kind, z=None):
        d1, d2 = distance(g, region.s1), distance(g, p)
        angle1 = math.degrees(math.atan2(g[1]-region.s1[1], g[0]-region.s1[0]))
        if not (math.hypot(*g) <= c.arena_radius and c.near_radius < d1 <= c.range_max
                and abs(wrap(angle1-region.theta)) <= c.delta_deg-1e-9):
            return False
        if kind == 0:
            return d2 > max(c.range_min, d1)+margin
        angle2 = math.degrees(math.atan2(g[1]-p[1], g[0]-p[0]))
        return c.near_radius < d2 <= c.range_max and abs(wrap(angle2-z)) < c.delta_deg-1e-9

    near_poly = disk_clip(region.first_hull, p, c.near_radius, c.circle_sides)
    constant = min(2*c.near_radius, diameter(near_poly)[0]+margin) if near_poly else 0.
    lower = 0.
    outer = disk_clip(region.first_hull, p, c.range_max, c.circle_sides)
    inner = disk_clip(region.inner, p, c.range_max, c.circle_sides, True)
    if not outer:
        return dict(lower_m=lower, upper_m=constant, bins=0, gap_m=constant-lower)
    lo, hi = angle_interval(outer, p)
    lo -= c.delta_deg
    hi += c.delta_deg
    heap = []
    count = 0

    def interval(a, b):
        nonlocal lower, count
        z = (a+b)/2
        post = bearing_clip(outer, p, z, c.delta_deg+(b-a)/2)
        upper = diameter(post)[0]+margin if post else 0.
        if upper > lower:
            inside = bearing_clip(inner, p, z, c.delta_deg-1e-7)
            pts = [g for g in inside if valid(g, 1, z)]
            if len(pts) > 1:
                d, x, y = diameter(pts)
                lower = max(lower, d-margin)
                if witness_callback:
                    witness_callback(1, x, y)
        count += 1
        return (-upper, a, b)

    # Initial intervals narrower than 180 degrees keep wedge clipping valid.
    initial = max(32, math.ceil((hi-lo)/20))
    for i in range(initial):
        heapq.heappush(heap, interval(lo+(hi-lo)*i/initial, lo+(hi-lo)*(i+1)/initial))
    while heap and -heap[0][0] > max(constant, lower+tolerance):
        if time.monotonic()-started > seconds:
            break
        _, a, b = heapq.heappop(heap)
        m = (a+b)/2
        heapq.heappush(heap, interval(a, m))
        heapq.heappush(heap, interval(m, b))
    upper = max(constant, -heap[0][0] if heap else 0.)
    return dict(lower_m=lower, upper_m=upper, bins=count, gap_m=upper-lower,
                elapsed_s=time.monotonic()-started)
