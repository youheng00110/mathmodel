"""Anytime bounds for frozen task order, finite measure sites and clear regions.

This is NOT a bound on the full feedback problem. A frozen measurement is
charged once, without assuming that it completes localization. Inexact convex
leaf bounds remain in the global lower bound even after that leaf is visited.
"""

from dataclasses import replace
from functools import lru_cache
import heapq
import math

from .active_sensing import needs_fallback
from .convex_clearance import optimize_clearance_points
from .geometry import distance
from .posterior import PlanningTimeout, check_deadline
from .route_sensing import service, route_cost
from .saa_rollout import measurement_points


def optimize_joint_route(initial, beliefs, start, receiver, *, forced_scan=False,
                         measurement_limit=3, node_limit=2000, tolerance_s=.01,
                         convex_iterations=80, deadline=None):
    """Best-bound branching on next task AND its finite measurement site.

    Reliable clears vary continuously in the 19.7 m vertex-disk intersection.
    Other sites are fixed. Each task must appear exactly once. Service includes
    receiver transitions; exploratory clears use the frozen 5 s convention.
    """
    if measurement_limit < 1 or node_limit < 0 or tolerance_s < 0:
        raise ValueError('Invalid joint route budget')
    initial = list(initial)
    if forced_scan and initial and initial[0].kind != 'scan':
        raise ValueError('Initial incumbent violates forced first scan')
    initial, initial_convex = optimize_clearance_points(
        initial, beliefs, start, iterations=convex_iterations,
        tolerance_m=max(1e-6,tolerance_s*5/2), deadline=deadline)
    best_route = initial
    upper = initial_upper = route_cost(initial,start,receiver)
    options, groups, regions = [], [], []
    for job in initial:
        check_deadline(deadline)
        sites = [tuple(job.point)]
        if job.kind == 'measure' and not needs_fallback(beliefs[job.channel]):
            belief = beliefs[job.channel]
            proposals = sorted(measurement_points(belief),key=lambda p:distance(start,p))
            for point in proposals:
                if (len(sites) < measurement_limit and tuple(point) not in sites
                        and all(distance(point,old) > .1 for old,_,_ in belief.observations)):
                    sites.append(tuple(point))
        group = []
        for point in sites:
            group.append(len(options))
            options.append(replace(job,point=point))
            vertices = (tuple(point),)
            radius = 0.0
            if job.kind == 'clear' and job.guaranteed:
                vertices = tuple(tuple(v) for v in beliefs[job.channel].polygon)
                radius = 19.7
            regions.append((vertices,radius))
        groups.append(tuple(group))
    n = len(groups)
    # A point is a radius-zero region. For disk intersections A,B, every pair
    # of defining disks gives dist(A,B) >= |v-w|-ra-rb. Take the maximum.
    regions.append(((tuple(start),),0.0))
    origin = len(options)

    @lru_cache(None)
    def edge(a,b):
        check_deadline(deadline)
        av,ar = regions[a]
        bv,br = regions[b]
        return max(0.0,max(distance(v,w)-ar-br for v in av for w in bv)-1e-8)

    @lru_cache(None)
    def group_edge(a,b):
        return min(edge(i,j) for i in groups[a] for j in groups[b])

    fees = [min(service(options[group[0]],c)[0] for c in range(1,21))
            for group in groups]

    @lru_cache(None)
    def remaining(mask):
        todo = tuple(i for i in range(n) if not mask & (1<<i))
        tree = 0.0
        if todo:
            weights = {i:math.inf for i in todo}
            weights[todo[0]] = 0.0
            while weights:
                check_deadline(deadline)
                i = min(weights,key=weights.get)
                tree += weights.pop(i)
                for j in weights:
                    weights[j] = min(weights[j],group_edge(i,j))
        return todo,tree/5+sum(fees[i] for i in todo)

    def bound(mask,last,prefix_cost):
        todo,tail = remaining(mask)
        connect = min((edge(last,j) for i in todo for j in groups[i]),default=0.0)
        return max(0.0,prefix_cost+connect/5+tail-1e-7)

    lower = bound(0,origin,0.0)
    # Entries: (LB, serial, mask, last option, receiver, relaxed prefix cost,
    #           exact prefix service cost, selected option indices).
    queue = [(lower,0,0,origin,receiver,0.0,0.0,())] if n else []
    serial,expanded,leaves = 0,0,0
    unresolved_leaf_lower = math.inf
    timed_out = False
    while queue and expanded < node_limit:
        lower = min(upper,queue[0][0],unresolved_leaf_lower)
        if upper-lower <= tolerance_s:
            break
        node = heapq.heappop(queue)
        lb,_,mask,last,channel,prefix_cost,prefix_fees,indices = node
        if lb >= upper:
            continue
        try:
            check_deadline(deadline)
            expanded += 1
            if len(indices) == n:
                route,certificate = optimize_clearance_points(
                    [options[i] for i in indices],beliefs,start,
                    iterations=convex_iterations,
                    tolerance_m=max(1e-6,tolerance_s*5/2),deadline=deadline)
                value = route_cost(route,start,receiver)
                if value < upper:
                    best_route,upper = route,value
                # Never discard a numerical leaf's remaining uncertainty.
                leaf_lower = max(lb,prefix_fees+certificate['length_lower_bound_m']/5-1e-7)
                unresolved_leaf_lower = min(unresolved_leaf_lower,leaf_lower)
                leaves += 1
                continue
            for i,group in enumerate(groups):
                if mask & (1<<i):
                    continue
                if not indices and forced_scan and options[group[0]].kind != 'scan':
                    continue
                for option in group:
                    check_deadline(deadline)
                    fee,after = service(options[option],channel)
                    cost = prefix_cost+edge(last,option)/5+fee
                    new_mask = mask | (1<<i)
                    child_lower = max(lb,bound(new_mask,option,cost))
                    if child_lower < upper:
                        serial += 1
                        heapq.heappush(queue,(child_lower,serial,new_mask,option,after,
                                              cost,prefix_fees+fee,indices+(option,)))
        except PlanningTimeout:
            # Some siblings may not yet exist. Restoring the parent covers
            # all of them in the final lower bound, including partial leaves.
            heapq.heappush(queue,node)
            timed_out = True
            break
    lower = min(upper,queue[0][0] if queue else math.inf,unresolved_leaf_lower)
    if lower > upper+1e-6:
        raise ValueError('Joint route lower bound exceeds incumbent')
    gap = max(0.0,upper-lower)
    return best_route,dict(method='best_bound_task_site_branching_with_convex_clearance_leaves',
        bound_scope='frozen_tasks_finite_measure_sites_continuous_reliable_clear_regions',
        lower_bound_s=lower,upper_bound_s=upper,optimality_gap_s=gap,
        joint_subproblem_gap_target_met=gap<=tolerance_s,tolerance_s=tolerance_s,
        initial_upper_s=initial_upper,task_count=n,option_count=len(options),
        expanded_nodes=expanded,convex_leaves=leaves,queued_nodes=len(queue),
        unresolved_leaf_lower_s=(unresolved_leaf_lower if math.isfinite(unresolved_leaf_lower) else None),
        node_limit_reached=bool(queue) and expanded>=node_limit,timed_out=timed_out,
        measurement_sites_continuous=False,full_feedback_completion_bound=False,
        global_optimality_certified=False,initial_convex_position_optimization=initial_convex)
