"""Post-run open-route reference metrics. Never used by online decisions.

An exact tour through estimated centers is a reference, not a physical lower
bound: clearance is allowed within 20 m and centers may be uncertain.
"""

from array import array
import math
import time


def shortest_open_path(start_cost, edges):
    """Held-Karp subset DP: fixed start, visit every target, free final target.

Accepts nonmetric edge weights as well, for disk-distance relaxations.
Returns exact finite-graph optimum and a target-index order.
"""
    n = len(start_cost)
    if not n:
        return 0.0, []
    if n > 16:
        raise ValueError("Oracle evaluator supports at most 16 targets")
    size = (1 << n)*n
    costs = array("d", [math.inf])*size
    parents = array("b", [-1])*size
    for j in range(n):
        costs[(1 << j)*n+j] = start_cost[j]
    for mask in range(1, 1 << n):
        remaining_last = mask
        while remaining_last:
            bit = remaining_last & -remaining_last
            j = bit.bit_length()-1
            remaining_last -= bit
            previous_mask = mask ^ bit
            if not previous_mask:
                continue
            base = previous_mask*n
            best, predecessor = math.inf, -1
            previous = previous_mask
            while previous:
                prior_bit = previous & -previous
                i = prior_bit.bit_length()-1
                previous -= prior_bit
                candidate = costs[base+i]+edges[i][j]
                if candidate < best:
                    best, predecessor = candidate, i
            index = mask*n+j
            costs[index], parents[index] = best, predecessor
    mask = (1 << n)-1
    last = min(range(n), key=lambda j: costs[mask*n+j])
    length = costs[mask*n+last]
    order = []
    while last >= 0:
        order.append(last)
        prior = parents[mask*n+last]
        mask ^= 1 << last
        last = prior
    return length, list(reversed(order))


def oracle_metrics(summary):
    began = time.monotonic()
    truth = summary.get("source_truth")
    if truth is not None:
        targets = [(s["channel"], (s["x"], s["y"]), 0.0) for s in truth]
        source = "offline_truth_after_run"
        complete = bool(summary.get("actual_all_cleared"))
    else:
        targets = [(c["channel"], tuple(c["region_center"]), c["region_radius_m"])
                   for c in summary.get("channels", []) if c["state"] == "cleared"]
        source = "final_estimated_centers"
        channels = summary.get("channels", [])
        complete = (len(channels) == 20 and all(c["state"] in ("cleared", "absent") for c in channels)
                    or summary.get("clear_success") == 16)
    complete = bool(complete and summary.get("completion_certified") and summary.get("exit_confirmed")
                    and summary.get("error") is None and len(targets) == summary.get("clear_success"))
    result = dict(oracle_reference_time_s=None, normalized_excess_time=None,
                  extra_time_per_target_s=None, oracle_efficiency=None,
                  oracle_metrics_eligible=False)
    # Partial target sets must not produce misleading normalized performance.
    if not complete or not targets:
        result["oracle"] = dict(status="unavailable_incomplete_or_missing_targets", source=source)
        return result
    targets.sort(key=lambda item: item[0])
    if not all(math.isfinite(v) for _, p, r in targets for v in (*p, r)) or any(r < 0 for _, _, r in targets):
        raise ValueError("Invalid oracle target geometry")
    n = len(targets)
    points = [t[1] for t in targets]
    radii = [t[2] for t in targets]
    edges = [[math.dist(a, b) for b in points] for a in points]
    start = [math.hypot(*p) for p in points]
    length, order = shortest_open_path(start, edges)
    reference = length/5 + 5*n
    # Every successful clearance point lies within radius 20+r_i of the
    # estimated center. Edge minima relax consistency of entry/exit points.
    disk_start = [max(0.0, start[i]-20-radii[i]) for i in range(n)]
    disk_edges = [[max(0.0, edges[i][j]-40-radii[i]-radii[j]) for j in range(n)] for i in range(n)]
    lower_length, lower_order = shortest_open_path(disk_start, disk_edges)
    lower = lower_length/5 + 5*n
    actual = summary["virtual_time_s"]
    if not math.isfinite(actual) or actual <= 0:
        raise ValueError("Invalid completed-run virtual time")
    # Triangle inequality: any fixed center tour changes by at most 2 sum r_i.
    center_time_error = 2*sum(radii)/5
    result.update(oracle_reference_time_s=reference,
                  normalized_excess_time=(actual-reference)/reference,
                  extra_time_per_target_s=(actual-reference)/n,
                  oracle_efficiency=reference/actual, oracle_metrics_eligible=True)
    result["oracle"] = dict(
        status="computed", source=source, target_count=n, graph_method="exact_open_subset_dp",
        center_path_length_m=length, center_visit_channels=[targets[i][0] for i in order],
        reference_is_physical_lower_bound=False,
        center_reference_uncertainty_interval_s=[max(5*n, reference-center_time_error), reference+center_time_error],
        disk_relaxation_lower_bound_s=lower,
        disk_relaxation_visit_channels=[targets[i][0] for i in lower_order],
        disk_relaxation_efficiency=lower/actual,
        disk_relaxation_normalized_excess_time=(actual-lower)/lower,
        disk_relaxation_extra_time_per_target_s=(actual-lower)/n,
        lower_bound_assumptions="All targets accounted for; true positions within recorded enclosing disks; 20 m clear radius; specified time model.",
        computed_after_run=True, postprocess_elapsed_s=time.monotonic()-began)
    return result
