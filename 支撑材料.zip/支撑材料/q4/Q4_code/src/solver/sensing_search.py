"""Adaptive measurement proposals and one additional feedback decision.

No function accepts the actual simulator, its source list, or the outer
rollout's hidden truth. The nested search resamples from observable history.
"""
import math

from .geometry import distance
from .planner import Job
from .posterior import SpatialPosterior, PosteriorUnavailable, check_deadline
from .saa_rollout import RolloutWorld, RolloutLimit, measurement_points, tail_job


def sensing_candidates(state,limit=8,deadline=None):
    """Moveable sensing sites with found-only and found+unknown channel sets.

    The ranking only proposes a finite set. Full virtual-time rollouts decide
    between retained actions. Arbitrary sites never receive coverage credit.
    """
    found = [b for b in state.beliefs.values() if b.state=='found' and b.radius>19.7]
    found.sort(key=lambda b:(distance(state.position,b.center),b.channel))
    sites = [tuple(state.position)]
    for b in found[:4]:
        check_deadline(deadline)
        sites.extend(measurement_points(b))
        sites.append(tuple((a+c)/2 for a,c in zip(state.position,b.center)))
    for i,a in enumerate(found[:4]):
        for b in found[:i]:
            sites.append(tuple((x+y)/2 for x,y in zip(a.center,b.center)))
    # Off-anchor search is a real channel batch, not a fictitious coverage
    # certificate. Retain certified anchor scans as the completion fallback.
    remaining = [p for i,p in enumerate(state.anchors) if i not in state.visited]
    for p in sorted(remaining,key=lambda p:distance(state.position,p))[:2]:
        sites.append(tuple((a+b)/2 for a,b in zip(state.position,p)))
    proposals = {}
    for p in dict.fromkeys(tuple(p) for p in sites):
        check_deadline(deadline)
        visible = [b.channel for b in found if distance(p,b.center)<=1400
                   and all(distance(p,q)>.1 for q,_,_ in b.observations)]
        unknown = [c for c,b in state.beliefs.items() if b.state=='unknown'
                   and all(distance(p,q)>.1 for q,_,_ in b.observations)]
        channel_sets = [tuple(visible),tuple(visible+unknown)]
        for channels in channel_sets:
            if not channels:
                continue
            if len(channels)==1:
                job = Job('measure',p,channels[0])
            else:
                job = Job('batch',p,scan_channels=channels)
            # Divide by the number of paid observations for proposal ranking.
            # This is not a bound or the optimization objective.
            key=(job.kind,p,job.channel,job.scan_channels)
            score=(distance(state.position,p)/5+job.service(state.receiver)[0])/len(channels)
            proposals[key]=(score,job)
    return [job for _,job in sorted(proposals.values(),key=lambda item:item[0])[:limit]]


class TwoStageSensingTail:
    """Factory: each candidate/sample evaluation gets its own stage counter."""
    def __init__(self,error_model='hash',particles=32,scenarios=2,candidates=3,max_actions=600):
        self.error_model=error_model
        self.particles,self.scenarios,self.candidates=particles,scenarios,candidates
        self.max_actions=max_actions
        # Diagnostic counters only; never consulted by action selection.
        self.statistics=dict(lookahead_calls=0,posterior_fallbacks=0,
            complete_candidate_evaluations=0,no_complete_candidate_fallbacks=0,
            changed_second_actions_in_rollouts=0)

    def for_episode(self,deadline=None):
        parent=self
        first=True
        def choose(state,coverage_gap=12):
            nonlocal first
            if not first:
                return tail_job(state,coverage_gap)
            first=False
            parent.statistics['lookahead_calls']+=1
            base=tail_job(state,coverage_gap)
            if (any(b.state=='unknown' for b in state.beliefs.values())
                    and (not state.visited or state.since_scan>=coverage_gap)):
                return base
            check_deadline(deadline)
            posterior=SpatialPosterior(parent.particles,20260911,error_model=parent.error_model)
            try:
                samples,_,_=posterior.scenarios(state.beliefs,parent.scenarios,0,deadline)
                candidates=[base]+[j for j in sensing_candidates(state,parent.candidates-1,deadline) if j!=base]
            except PosteriorUnavailable:
                # History-dependent numerical fallback, never a change to a
                # different unannounced error model or a truth-based decision.
                parent.statistics['posterior_fallbacks']+=1
                return base
            chosen,best=base,math.inf
            for job in candidates:
                total,valid=0.0,True
                for sample in samples:
                    check_deadline(deadline)
                    world=RolloutWorld(state,sample,parent.max_actions,deadline=deadline)
                    try:
                        world.execute(job)
                        total+=world.finish(coverage_gap,tail_job)
                    except (RolloutLimit,PosteriorUnavailable,ValueError):
                        valid=False
                        break
                if valid:
                    parent.statistics['complete_candidate_evaluations']+=1
                    if total<best:
                        chosen,best=job,total
            if not math.isfinite(best):
                parent.statistics['no_complete_candidate_fallbacks']+=1
            parent.statistics['changed_second_actions_in_rollouts']+=int(chosen!=base)
            return chosen
        return choose
