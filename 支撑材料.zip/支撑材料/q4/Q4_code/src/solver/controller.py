"""Discovery/localization/clearance closed loop with explicit completion proof."""

from dataclasses import dataclass
import math
import time

from .belief import Belief
from .geometry import coverage_nodes, distance
from .planner import Job, coverage_next, select_job
from .protocol import BudgetExpired, ProtocolError, scan_channel_order
from .sensing import choose_local_action
from .active_sensing import ActiveEvaluator
from .joint_planner import select_joint_job


@dataclass
class Config:
    problem: int = 3
    horizon: int | None = None
    policy: str = "optimized"
    coverage_gap: int = 12
    max_actions: int = 12000
    shared_observations: bool = True
    route_tail: bool = True
    route_insertion: bool = True
    bounded_sensing: bool = True
    saa_particles: int = 256
    saa_scenarios: int = 8
    saa_candidates: int = 12
    saa_seconds: float = 3.0
    saa_gap: float = .03
    saa_seed: int = 20260911
    saa_rollout_actions: int = 600
    saa_error_model: str = "hash"

    coverage_radius_m: float | None = None
    triangle_map_only: bool = False
    decision_model: dict | None = None
    saa_objective: str = 'total'

    def __post_init__(self):
        if self.saa_objective not in ('total','per_target'):
            raise ValueError('Unknown SAA objective')
        if self.decision_model is not None:
            if self.policy not in ('saa', 'continuous_saa'):
                raise ValueError('Decision model tuning requires saa or continuous_saa')
            from .decision_model import DecisionParameters
            DecisionParameters(**self.decision_model)
        if self.saa_error_model not in ("hash","smooth","official"):
            raise ValueError("Unsupported predictive error model")
        if self.saa_error_model == 'official' and (self.problem != 3 or self.policy != 'saa'):
            raise ValueError('Official joint prediction requires Q3 policy saa')
        if self.coverage_radius_m is not None:
            a = self.coverage_radius_m
            if (self.problem != 3 or not math.isfinite(a) or a <= 0
                    or a/math.sqrt(3) > 1000
                    or 1800**2+a*a-1800*math.sqrt(3)*a > 1000**2):
                raise ValueError("Coverage radius must certify the Q3 disk coverage")
        if self.triangle_map_only and self.policy != 'triangle_saa':
            raise ValueError("triangle-map-only requires triangle_saa")
        if self.horizon is None:
            self.horizon = 3 if self.problem == 3 else 6
        if self.policy in ("saa", "route_saa", "math_saa", "sense_saa", "hybrid_pomdp", "triangle_saa", "continuous_saa"):
            if self.problem != 3:
                raise ValueError("saa currently models Q3 omnidirectional sources only")
            if (self.saa_particles < 32 or self.saa_scenarios < 1 or self.saa_candidates < 1
                    or self.saa_rollout_actions < 1 or not math.isfinite(self.saa_seconds)
                    or self.saa_seconds <= 0 or not math.isfinite(self.saa_gap)
                    or not 0 <= self.saa_gap < 1):
                raise ValueError("Invalid SAA particle/scenario/candidate/time/gap budgets")


class Controller:
    def __init__(self, client, config=None, progress=None):
        self.client = client
        self.config = config or Config()
        self.beliefs = {c: Belief(c) for c in range(1, 21)}
        if self.config.policy == 'triangle_saa':
            from .triangle_map import TriangleBelief
            self.beliefs = {c: TriangleBelief(c) for c in range(1, 21)}
        self.anchors = coverage_nodes(self.config.problem)
        radius = self.config.coverage_radius_m
        if radius is None and self.config.policy == 'triangle_saa':
            radius = 1150.0
        if radius is not None:
            self.anchors = [(0.0, 0.0)]+[(radius*math.cos(k*math.pi/3),
                                         radius*math.sin(k*math.pi/3)) for k in range(6)]
        self.visited = set()
        self.since_scan = 0
        self.actions = 0
        self.progress = progress or (lambda message: None)
        self.planning_calls = 0
        self.dp_savings = 0.0
        self.active_evaluator = ActiveEvaluator(self.config.problem)
        self.clear_times = []
        self.batch_jobs = 0
        self.batch_measurements = 0
        self.stochastic_planner = None
        if self.config.policy in ("saa", "route_saa", "math_saa", "sense_saa", "hybrid_pomdp", "triangle_saa", "continuous_saa"):
            from .stochastic_planner import StochasticPlanner
            self.stochastic_planner = StochasticPlanner(
                self.config.saa_particles, self.config.saa_scenarios,
                self.config.saa_candidates, self.config.saa_seconds,
                self.config.saa_gap, self.config.saa_seed,
                self.config.saa_rollout_actions, self.config.coverage_gap,
                route_aware=self.config.policy == "route_saa",
                mathematical=self.config.policy == "math_saa",
                sensory=self.config.policy == "sense_saa",error_model=self.config.saa_error_model,
                hybrid=self.config.policy == "hybrid_pomdp",
                triangular=self.config.policy == "triangle_saa" and not self.config.triangle_map_only,
                decision_model=self.config.decision_model,
                continuous=self.config.policy == "continuous_saa",
                objective=self.config.saa_objective)

    def completed(self):
        return (sum(b.state == "cleared" for b in self.beliefs.values()) == 16
                or all(b.state in ("cleared", "absent") for b in self.beliefs.values()))

    def measure(self, channel, position, anchor=None):
        if self.actions >= self.config.max_actions:
            raise BudgetExpired("action_cap")
        response = self.client.act("/measure", position, channel)
        self.actions += 1
        b = self.beliefs[channel]
        kind = b.observe(position, response, anchor)
        if kind == "near":
            self.clear(channel, position, guaranteed=True)
        elif b.state == "unknown" and len(b.covered) == len(self.anchors):
            b.state = "absent"
        return response

    def clear(self, channel, position, guaranteed):
        if self.actions >= self.config.max_actions:
            raise BudgetExpired("action_cap")
        response = self.client.act("/clear", position, channel)
        self.actions += 1
        self.beliefs[channel].clear_feedback(position, response, guaranteed)
        if response["clear_result"] == "success":
            self.clear_times.append(self.client.virtual_s)
            self.progress(f"cleared channel {channel}; total={self.client.stats['clear_success']}; virtual={self.client.virtual_s:.1f}s")

    def scan(self, job):
        unknown = [c for c, b in self.beliefs.items() if b.state == "unknown"]
        for channel in scan_channel_order(unknown, self.client.channel):
            if self.completed():
                break
            self.measure(channel, job.point, job.anchor)
        self.visited.add(job.anchor)
        self.since_scan = 0
        if self.config.policy in ("saa", "route_saa", "math_saa", "sense_saa", "hybrid_pomdp", "triangle_saa", "continuous_saa"):
            # The numerical rollout executes this same explicit scan macro.
            # Extra opportunistic bearings must be separately proposed jobs.
            self.progress(f"coverage {len(self.visited)}/{len(self.anchors)}; unknown={sum(b.state=='unknown' for b in self.beliefs.values())}")
            return
        # Opportunistic bearings at a place already paid for. At most two,
        # and never repeat an observation at the same position.
        possible = [b for b in self.beliefs.values() if b.state == "found" and b.radius > 19.7
                    and distance(b.center, job.point) < 1350
                    and all(distance(p, job.point) > .1 for p, _, _ in b.observations)]
        if self.config.policy == "literature" and self.config.bounded_sensing:
            scored = [(b, self.active_evaluator.evaluate(b, job.point)) for b in possible]
            scored = [(b, score) for b, score in scored if score
                      and score["information_gain"] >= .10 and score["visibility_score"] >= .5]
            scored.sort(key=lambda row: -row[1]["information_gain"])
            possible = [b for b, _ in scored]
        else:
            possible.sort(key=lambda b: distance(b.center, job.point))
        for b in possible[:2]:
            self.measure(b.channel, job.point)
        self.progress(f"coverage {len(self.visited)}/{len(self.anchors)}; unknown={sum(b.state=='unknown' for b in self.beliefs.values())}")

    def next_job(self):
        current = self.client.position
        if self.stochastic_planner is not None:
            from .saa_rollout import ObservationState
            state = ObservationState(self.beliefs, self.anchors, self.visited,
                                     current, self.client.channel, self.since_scan)
            deadline = self.client.deadline
            if deadline is not None:
                deadline -= self.client.exit_margin
            job, info = self.stochastic_planner.select(
                state, deadline, self.client.max_virtual_s-self.client.virtual_s)
            self.planning_calls += 1
            self.client.record("planning", job=job.__dict__, **info)
            return job
        unknown = tuple(c for c, b in self.beliefs.items() if b.state == "unknown")
        scan_job = None
        if unknown:
            remaining = [i for i in range(len(self.anchors)) if i not in self.visited]
            if not remaining:
                raise ValueError("Unknown channels remain after purported complete coverage")
            i = (0 if not self.visited else coverage_next(remaining, self.anchors, current,
                                                         self.config.policy != "greedy"))
            scan_job = Job("scan", self.anchors[i], anchor=i, scan_channels=unknown)
        if scan_job and (not self.visited or self.since_scan >= self.config.coverage_gap):
            return scan_job
        jobs = []
        route_points = ([scan_job.point] if scan_job else [])
        if self.config.policy == "literature":
            route_points += [b.center for b in self.beliefs.values()
                             if b.state == "found" and b.radius <= 19.7]
        for channel, b in self.beliefs.items():
            if b.state == "found":
                if self.config.policy == "literature" and self.config.bounded_sensing:
                    kind, point, guaranteed, future_cost = self.active_evaluator.choose(
                        b, current, self.client.channel, route_points)
                else:
                    kind, point, guaranteed, future_cost = choose_local_action(b, current, self.config.problem)
                jobs.append(Job(kind, point, channel, guaranteed, future_cost=future_cost))
        if scan_job:
            jobs.append(scan_job)
        if self.config.policy == "literature":
            remaining_points = [self.anchors[i] for i in range(len(self.anchors))
                                if unknown and i not in self.visited]
            job, info = select_joint_job(
                jobs, current, self.client.channel, self.config.horizon, self.beliefs,
                self.active_evaluator, remaining_points,
                shared=self.config.shared_observations and self.config.bounded_sensing,
                route_tail=self.config.route_tail, insertion=self.config.route_insertion)
        else:
            job, info = select_job(jobs, current, self.client.channel, self.config.horizon, self.config.policy)
        self.planning_calls += 1
        self.dp_savings += info["greedy_same_jobs_cost_s"]-info["selected_route_cost_s"]
        self.client.record("planning", job=job.__dict__, **info)
        return job

    def batch_measure(self, job):
        """Several distinct channels, one paid-for location; no speculative feedback."""
        self.batch_jobs += 1
        before = self.actions
        for channel in scan_channel_order(job.scan_channels, self.client.channel):
            if self.completed():
                break
            belief = self.beliefs[channel]
            if belief.state not in ("found","unknown") or any(distance(p, job.point) <= .1 for p, _, _ in belief.observations):
                continue
            self.measure(channel, job.point)
            self.batch_measurements += 1
        self.since_scan += self.actions-before

    def clear_search(self, job):
        before = self.actions
        for point in job.search_points:
            if self.beliefs[job.channel].state == 'cleared':
                break
            self.clear(job.channel, point, guaranteed=False)
        self.since_scan += self.actions-before
        if job.cover_certified and self.beliefs[job.channel].state != 'cleared':
            raise ValueError('Certified clearance cover exhausted without success')

    def run(self):
        began = time.monotonic()
        reason, error = "not_started", None
        try:
            self.client.enter()
            reason = "running"
            while not self.completed():
                if self.actions >= self.config.max_actions:
                    raise BudgetExpired("action_cap")
                if not self.client.time_available():
                    raise BudgetExpired("real_time_reserve")
                job = self.next_job()
                if job.kind == "scan":
                    self.scan(job)
                elif job.kind == "measure":
                    before = self.actions
                    self.measure(job.channel, job.point)
                    self.since_scan += self.actions-before if self.stochastic_planner is not None else 1
                elif job.kind == "clear_search":
                    self.clear_search(job)
                elif job.kind == "batch":
                    self.batch_measure(job)
                else:
                    self.clear(job.channel, job.point, job.guaranteed)
                    self.since_scan += 1
            reason = "all_cleared_certified"
        except BudgetExpired as exc:
            reason = str(exc)
        except KeyboardInterrupt:
            reason = "interrupted"
        except (ProtocolError, ValueError, KeyError, TypeError) as exc:
            reason, error = "error", str(exc)
            self.client.record("error", error=error)
        finally:
            if self.client.entered:
                try:
                    self.client.exit()
                except (ProtocolError, BudgetExpired, OSError, KeyError, ValueError) as exc:
                    self.client.record("exit_error", error=str(exc))
                    error = (error + "; " if error else "") + "exit: " + str(exc)
        clear_count = self.client.stats["clear_success"]
        summary = {"problem": self.config.problem, "policy": self.config.policy,
                   "strategy_version": ("triangle-saa-v2" if self.config.policy == "triangle_saa" else
                                        "hybrid-pomdp-v1" if self.config.policy == "hybrid_pomdp" else
                                        "sense-saa-v2" if self.config.policy == "sense_saa" else
                                        "math-saa-v2" if self.config.policy == "math_saa" else
                                        "route-saa-v1" if self.config.policy == "route_saa" else
                                        "saa-v1" if self.config.policy == "saa" else
                                        "literature-v1" if self.config.policy == "literature" else "baseline-v1"),
                   "coverage_radius_m": distance((0,0),self.anchors[1]),
                   "triangle_map_only": self.config.triangle_map_only,
                   "completion_certified": self.completed(), "reason": reason,
                   "error": error, "exit_confirmed": self.client.exited,
                   "virtual_time_s": self.client.virtual_s,
                   "average_clear_time_s": self.client.virtual_s/clear_count if clear_count else None,
                   "mean_clear_completion_time_s": sum(self.clear_times)/len(self.clear_times) if self.clear_times else None,
                   "clear_completion_times_s": self.clear_times,
                   "batch_jobs": self.batch_jobs, "batch_measurements": self.batch_measurements,
                   "program_elapsed_s": time.monotonic()-began,
                   "actions": self.actions, "coverage_nodes_visited": len(self.visited),
                   "coverage_nodes_total": len(self.anchors),
                   "planning_calls": self.planning_calls,
                   "sum_frozen_horizon_savings_s": self.dp_savings,
                   **self.client.stats,
                   "channels": [b.certificate() for b in self.beliefs.values()]}
        if self.stochastic_planner is not None:
            summary["stochastic_planning"] = self.stochastic_planner.summary()
        self.client.record("summary", summary=summary)
        return summary
