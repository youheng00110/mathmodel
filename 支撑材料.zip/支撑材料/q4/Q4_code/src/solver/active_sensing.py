"""Literature-informed bounded-set sensing; scoring is heuristic, never a certificate.

Uses Tokekar & Isler's wedge model and the perpendicular-placement motivation
of Vander Hook et al. It is NOT an implementation of their EKF beta-cautious
algorithm and inherits none of its approximation factors.
"""

import math

from .geometry import (EPS_DEG, bearing_clip, clear_position, clip_disk_outer,
                       diameter, distance, enclosing_circle)
from .sensing import candidate_points, choose_local_action, expected_visibility, representatives

CLEAR_RADIUS = 19.7


def area(poly):
    return abs(sum(a[0]*b[1]-a[1]*b[0]
                   for a, b in zip(poly, poly[1:]+poly[:1])))/2


def needs_fallback(belief):
    return (bool(belief.failed_clears) or belief.misses >= 3
            or belief.stagnant >= 3 or belief.local_measurements >= 9)


class ActiveEvaluator:
    """Cache scenario scores per observation history, including negative feedback."""

    def __init__(self, problem):
        self.problem = problem
        self.cache = {}

    def evaluate(self, belief, point):
        point = tuple(point)
        if (belief.state != "found" or needs_fallback(belief)
                or belief.radius <= CLEAR_RADIUS
                or any(distance(point, p) <= .1 for p, _, _ in belief.observations)):
            return None
        version = (len(belief.observations), len(belief.failed_clears))
        entry = self.cache.get(belief.channel)
        if entry is None or entry[0] != version:
            entry = self.cache[belief.channel] = (version, {})
        if point in entry[1]:
            return entry[1][point]
        prior_r = max(CLEAR_RADIUS, belief.radius)
        prior_a = max(math.pi*CLEAR_RADIUS**2, area(belief.polygon))
        gains, radii, continuation, visible = [], [], [], []
        samples = representatives(belief.polygon, belief.failed_clears)
        for target in samples:
            visibility = expected_visibility(belief, point, target, self.problem)
            # This visibility value ranks scenarios; it is not a calibrated probability.
            angle = math.degrees(math.atan2(target[1]-point[1], target[0]-point[0]))
            for error in (-EPS_DEG, 0.0, EPS_DEG):
                if distance(target, point) <= 5:
                    posterior = clip_disk_outer(belief.polygon, point, 5)
                else:
                    posterior = bearing_clip(belief.polygon, point, angle+error)
                    posterior = clip_disk_outer(posterior, point, 1500)
                if not posterior:
                    continue
                center, radius = enclosing_circle(posterior)
                radius_gain = max(0.0, math.log2(prior_r/max(CLEAR_RADIUS, radius)))
                area_gain = max(0.0, .5*math.log2(prior_a/max(math.pi*CLEAR_RADIUS**2, area(posterior))))
                gains.append(visibility*(.8*radius_gain+.2*area_gain))
                radii.append(radius)
                visible.append(visibility)
                continuation.append(max(0.0, distance(point, center)-CLEAR_RADIUS)/5+5)
        if not gains:
            result = None
        else:
            gain = .5*min(gains)+.5*sum(gains)/len(gains)
            reception = sum(visible)/len(visible)
            stages = min(20.0, math.log2(prior_r/CLEAR_RADIUS)/max(.15, gain))
            future = (sum(continuation)/len(continuation)
                      + 6*max(0.0, stages-1)
                      + max(0.0, max(radii)-CLEAR_RADIUS)/5
                      + (1-reception)*(6+2*prior_r/5))
            result = dict(point=point, future_cost_s=future, information_gain=gain,
                          visibility_score=reception, sampled_worst_radius_m=max(radii),
                          sampled_mean_radius_m=sum(radii)/len(radii),
                          scenarios=len(gains), continuous_minimax_certified=False)
        # Bound memory when routing contributes many different points.
        if len(entry[1]) >= 512:
            entry[1].clear()
        entry[1][point] = result
        return result

    def choose(self, belief, current, receiver, route_points=()):
        clear = clear_position(belief.polygon, current)
        if clear is not None:
            return "clear", clear, True, 0.0
        if needs_fallback(belief):
            return choose_local_action(belief, current, self.problem)
        candidates = [tuple(current), *candidate_points(belief), *route_points]
        # Longer perpendicular baselines complement the original near-center points.
        length, a, b = diameter(belief.polygon)
        if length > 1e-6:
            perpendicular = (-(b[1]-a[1])/length, (b[0]-a[0])/length)
            for factor in (1.5, 2.0):
                offset = min(900.0, max(25.0, factor*belief.radius))
                for sign in (-1, 1):
                    candidates.append(tuple(belief.center[k]+sign*offset*perpendicular[k] for k in (0, 1)))
        scores = []
        for point in dict.fromkeys(tuple(p) for p in candidates):
            score = self.evaluate(belief, point)
            if score is not None:
                cost = (distance(current, point)/5 + 5 + int(receiver != belief.channel)
                        + score["future_cost_s"])
                scores.append((cost, point, score))
        if not scores:
            return choose_local_action(belief, current, self.problem)
        _, point, score = min(scores, key=lambda row: row[0])
        return "measure", point, False, score["future_cost_s"]
