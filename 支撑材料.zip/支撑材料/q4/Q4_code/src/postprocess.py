import copy
import json
from solver.oracle import oracle_metrics


def append_route_reference(summary, log_path):
    reference = copy.deepcopy(summary)
    requests, success = {}, {}
    for line in log_path.read_text(encoding='utf-8').splitlines():
        event = json.loads(line)
        if event['event'] == 'request':
            requests[event['payload']['request_id']] = event['payload']
        if (event['event'] == 'response' and event['path'] == '/clear'
                and event['response'].get('accepted')
                and event['response'].get('clear_result') == 'success'):
            body = requests[event['request_id']]
            success[body['channel']] = [body['position']['x'], body['position']['y']]
    for belief in reference['channels']:
        if belief['channel'] in success:
            belief['region_center'] = success[belief['channel']]
            belief['region_radius_m'] = 20.0
    metrics = oracle_metrics(reference)
    if metrics.get('oracle'):
        metrics['oracle']['source'] = 'successful_clear_positions_with_20m_truth_disks'
    summary.update(metrics)
    return summary
