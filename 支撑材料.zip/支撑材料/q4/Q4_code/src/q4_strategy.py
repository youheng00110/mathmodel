from q4.coupled_policy import CoupledPathController as Q4Controller
from q4.planning_budget import configure


def effective_parameters():
    return dict(
        policy='q4_coupled_path', strategy_version='q4-coupled-path-v3',
        source_domain_m=1800, minimum_receive_radius_m=1000,
        coverage_sites=21, inner_ring_radius_m=995, outer_ring_apothem_m=1801,
        covering_path_budget_s=0.5, covering_path_relative_gap=0.005,
        joint_mode_route_budget_s=2.0, fallback_grid_m=25,
        objective='E[T/N]', official_random_generator_replicated=False,
        global_expectation_optimality_certified=False,
    )


def build_controller(client, progress=None):
    controller = Q4Controller(client, progress)
    configure(controller, None, None)
    assert controller.routing_budget == 0.5
    assert controller.routing_gap == 0.005
    assert controller.mode_budget == 2.0
    assert len(controller.anchors) == 21
    assert controller.routing_primal_improvement is True
    return controller
