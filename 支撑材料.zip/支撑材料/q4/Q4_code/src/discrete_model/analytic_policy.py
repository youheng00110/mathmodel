"""Closed-form sensing proposals and exact finite clearance Bellman tails.

The cautious range uses a Gaussian local surrogate (ICRA 2012, equation 3),
not the official joint seed posterior. Exactness applies only to the finite
clearance action set when there are at most eight centres, with no further
measurements inside that tail. Global routing and beliefs remain approximate.
"""
import math
from functools import lru_cache
from statistics import NormalDist

import numpy as np

from solver.geometry import distance
from solver.official_physics import movement_us
from .numerical import LocalBellman, snap
from .joint_policy import JointController


def cautious_points(cloud, beta=.05):
    """Both closed-form sides before snapping; radians throughout the formula."""
    mean=np.asarray(cloud.mean)
    centered=cloud.points-mean
    covariance=(centered.T*cloud.weights)@centered/cloud.weights.sum()
    values,vectors=np.linalg.eigh(covariance)
    sigma_beta=math.pi/(2*NormalDist().inv_cdf(1-beta/2))
    sigma_sensor=math.radians(1)/math.sqrt(3)
    radius=math.sqrt(max(0,float(values[-1]))/(sigma_beta**2-sigma_sensor**2))
    return [tuple(mean+sign*radius*vectors[:,0]) for sign in (-1,1)]


class AnalyticBellman(LocalBellman):
    def __init__(self, exact_tail=False):
        super().__init__()
        self.exact_tail=exact_tail
        self.stats=dict(analytic_evaluations=0,analytic_selected=0,exact_cover_calls=0,
                        greedy_cover_calls=0,bellman_states=0,retained_cover_checks=0,
                        retained_cover_improvements=0)

    def cover(self, points, weights, start, end=None):
        """V(mask,last): clear outcome branches; no hidden-point action choice."""
        mass=float(weights.sum())
        if mass<=1e-12:return 0.,None
        centres=np.unique(np.round(points/5)*5,axis=0)
        if not self.exact_tail:
            self.stats['greedy_cover_calls']+=1
            return LocalBellman.cover(points,weights,start,end)
        covered=np.linalg.norm(centres[:,None,:]-points[None,:,:],axis=2)<=20
        incumbent=None
        if len(centres)>8:
            # Retain a COMPLETE feasible greedy cover, then optimise its order.
            # Do not discard posterior points or claim exactness for all centres.
            live=weights.copy();position=np.asarray(start);selected=[];incumbent=0.
            while float(live.sum())>=1e-12:
                hit=covered@live
                rank=hit/(np.linalg.norm(centres-position,axis=1)/5+3)
                i=int(np.argmax(rank));selected.append(i)
                if hit[i]<=0:raise ValueError('Incomplete finite clearance cover')
                if len(selected)>8:
                    self.stats['greedy_cover_calls']+=1
                    return LocalBellman.cover(points,weights,start,end)
                incumbent+=float(live.sum())*(movement_us(tuple(position),tuple(centres[i]))/1e6+3)+2*float(hit[i])
                if end is not None:incumbent+=float(hit[i])*movement_us(tuple(centres[i]),end)/1e6
                live[covered[i]]=0;position=centres[i]
            centres=centres[selected];covered=covered[selected]
        self.stats['exact_cover_calls']+=1
        masks=[sum(1<<int(j) for j in np.flatnonzero(row)) for row in covered]
        full=(1<<len(points))-1
        moves=np.array([[movement_us(tuple(a),tuple(b))/1e6 for b in centres]
                        for a in list(centres)+[start]])
        exits=[movement_us(tuple(p),end)/1e6 if end is not None else 0. for p in centres]

        @lru_cache(None)
        def weight(mask):
            return sum(float(w) for j,w in enumerate(weights) if mask>>j&1)

        @lru_cache(None)
        def value(mask,last):
            if not mask:return 0.,None
            remaining=weight(mask);best=(math.inf,None)
            for i,cover in enumerate(masks):
                success=mask&cover
                if not success:continue
                left=mask&~cover;hit=weight(success)
                # Unnormalised value: all remaining mass pays move+3;
                # successful mass pays 2 extra seconds and the outgoing leg.
                score=remaining*(moves[last,i]+3)+hit*(2+exits[i])+value(left,i)[0]
                if score<best[0]:best=(score,i)
            return best

        cost,first=value(full,len(centres))
        if incumbent is not None:
            assert cost<=incumbent+1e-7,'Retained greedy policy lost in Bellman minimisation'
            self.stats['retained_cover_checks']+=1
            self.stats['retained_cover_improvements']+=int(cost<incumbent-1e-7)
        self.stats['bellman_states']+=value.cache_info().currsize
        return cost/mass,tuple(centres[first])

    def choose(self,b,cloud,start,receiver,end=None,measure_enabled=True):
        # Existing candidates retain the same value definition and remain eligible.
        best=super().choose(b,cloud,start,receiver,end,measure_enabled)
        if not measure_enabled:return best
        original=best
        for p in dict.fromkeys(snap(p) for p in cautious_points(cloud)):
            if math.hypot(*p)>1790 or any(distance(p,q)<.1 for q,_,_ in b.observations):continue
            value=self.measurement(cloud,p,start,receiver,b.channel,end)
            self.evaluations+=1;self.stats['analytic_evaluations']+=1
            if value<best[0]:best=(value,'measure',p)
        self.stats['analytic_selected']+=best!=original
        return best


class AnalyticController(JointController):
    def __init__(self,*args,exact_tail=False,**kwargs):
        super().__init__(*args,**kwargs)
        self.config.policy='analytic_bellman' if exact_tail else 'analytic_grid'
        self.bellman=AnalyticBellman(exact_tail)

    def run(self):
        result=super().run()
        result['strategy_version']='analytic-bellman-v2' if self.bellman.exact_tail else 'analytic-grid-v1'
        result['analytic_planning']=dict(self.bellman.stats,exact_tail=self.bellman.exact_tail,
            exact_tail_max_centres=8,global_optimality_certified=False,
            scope='Gaussian cautious proposals; Bellman optimisation of complete retained clearance covers up to 8 centres; original approximate global routing')
        self.client.record('analytic_summary',summary=result)
        return result
