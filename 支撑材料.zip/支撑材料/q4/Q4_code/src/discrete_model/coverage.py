"""Conservative triangle information map for the still-unknown channels.

Every scan measures ALL currently unknown channels. Consequently those that
remain unknown share the same no-signal history. A triangle is removed only
when all vertices lie strictly inside a measured 1000 m disk. No quadrature or
probabilistic absence test is involved.
"""
import itertools
import numpy as np
from solver.geometry import disk_polygon, distance
from solver.triangle_map import split


def bits(mask):
    return int.from_bytes(np.packbits(mask,bitorder='little').tobytes(),'little')


class Coverage:
    def __init__(self,anchors):
        poly=disk_polygon(radius=1770,sides=64)
        pending=[((0.,0.),a,b) for a,b in zip(poly,poly[1:]+poly[:1])]
        cells=[]
        while pending:
            cell=pending.pop()
            span=max(distance(a,b) for a in cell for b in cell)
            covered=any(all(distance(v,p)<999.9999 for v in cell) for p in anchors)
            if span>100 or not covered:
                pending.extend(split(cell))
            else: cells.append(cell)
        self.vertices=np.array(cells)
        self.remaining=(1<<len(cells))-1
        self.anchor_masks=[self.mask(p) for p in anchors]
        assert self.remaining==self.union(range(len(anchors)))
        self.scanned=[]

    def mask(self,p):
        inside=np.all(np.sum((self.vertices-np.array(p))**2,axis=2)<999.9999**2,axis=1)
        return bits(inside)

    def union(self,indices):
        out=0
        for i in indices: out|=self.anchor_masks[i]
        return out

    def observe_scan(self,p):
        self.remaining &= ~self.mask(p)
        self.scanned.append(tuple(p))

    def subsets(self,indices,remaining=None):
        required=self.remaining if remaining is None else remaining
        for count in range(len(indices)+1):
            found=[subset for subset in itertools.combinations(indices,count)
                   if required & ~self.union(subset)==0]
            if found:return found
        raise ValueError('Coverage fallback lost a required triangle')
