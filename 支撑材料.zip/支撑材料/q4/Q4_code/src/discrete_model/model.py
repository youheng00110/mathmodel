"""Official deterministic seed model, integer grid and exact feedback partitions.

None as the information-set member list means all 2**256 seeds, not a sample.
Enumeration may be interrupted but partial counts NEVER become probabilities.
"""
from dataclasses import dataclass, replace
from fractions import Fraction
from functools import lru_cache
import math

from solver.official_joint import scene_from_seed, physical_response
from solver.official_physics import movement_us


@dataclass(frozen=True, order=True)
class Action:
    kind: str
    ix: int
    iy: int
    channel: int


@dataclass(frozen=True)
class State:
    position: tuple = (0, 0)  # integer grid indices
    receiver: int = 1
    cleared: int = 0         # channel bitmask
    members: tuple | None = None  # exact seed IDs; None is the complete root prior
    remaining_us: int = 360000000000


@dataclass(frozen=True)
class Branch:
    observation: tuple
    probability: Fraction
    cost_us_per_target: Fraction
    state: State


class Model:
    def __init__(self, step_um=5000000, actions=None, scene_lookup=None):
        if type(step_um) is not int or step_um <= 0:
            raise ValueError('Grid spacing must be a positive integer in micrometers')
        self.step_um = step_um
        self.restricted_actions = None if actions is None else tuple(actions)
        self.scene_lookup = scene_lookup or self.official_scene
        self.custom_scene_lookup = scene_lookup is not None
        self.seed_evaluations = 0
        self.complete_partitions = 0
        if self.restricted_actions is not None:
            for action in self.restricted_actions:
                self.validate_action(action)

    @staticmethod
    @lru_cache(maxsize=128)
    def official_scene(seed):
        if type(seed) is not int or not 0 <= seed < 2**256:
            raise ValueError('Seed must be a uint256')
        return scene_from_seed(seed.to_bytes(32, 'big'))

    def point(self, indices):
        return tuple(i*self.step_um/1000000 for i in indices)

    def validate_action(self, a):
        if (a.kind not in ('measure','clear') or type(a.ix) is not int
                or type(a.iy) is not int or type(a.channel) is not int
                or not 1 <= a.channel <= 20):
            raise ValueError('Invalid action')
        radius_um = (3270 if a.kind=='measure' else 1790)*1000000
        if (a.ix*a.ix+a.iy*a.iy)*self.step_um**2 > radius_um**2:
            raise ValueError('Action outside its useful domain')

    def actions(self, state, check=lambda:None):
        if self.restricted_actions is not None:
            yield from self.restricted_actions
            return
        for c in range(1,21):
            yield Action('measure',0,0,c)
        # Lazy, complete enumeration of the declared grids; no top-k proposals.
        for kind,radius in (('measure',3270),('clear',1790)):
            r_um=radius*1000000
            n=r_um//self.step_um
            for ix in range(-n,n+1):
                check()
                ymax=math.isqrt(r_um*r_um-(ix*self.step_um)**2)//self.step_um
                for iy in range(-ymax,ymax+1):
                    check()
                    if kind=='measure' and ix==0 and iy==0:
                        continue
                    for c in range(1,21):
                        yield Action(kind,ix,iy,c)

    def seed_ids(self, state):
        if state.members is None:
            return iter(range(2**256))
        if not state.members or len(set(state.members)) != len(state.members):
            raise ValueError('Information set must be nonempty and contain distinct seeds')
        return iter(state.members)

    @staticmethod
    def channel_mask(scene):
        return sum(1 << (s.channel-1) for s in scene.sources)

    def terminal(self, state, check=lambda:None):
        if state.members is None and state.cleared == 0:
            return False  # N >= 10 for every official generated scene.
        for seed in self.seed_ids(state):
            check()
            scene=self.scene_lookup(seed)
            mask=self.channel_mask(scene)
            if state.cleared & ~mask:
                raise ValueError('Information set conflicts with successful clears')
            if mask & ~state.cleared:
                return False
        return True

    def feedback(self, seed, state, action):
        self.validate_action(action)
        scene=self.scene_lookup(seed)
        source=next((s for s in scene.sources if s.channel==action.channel),None)
        result,angle=physical_response(source,
            bool(state.cleared & (1 << (action.channel-1))),scene.noise_seed,
            action.kind,self.point((action.ix,action.iy)))
        # Integer hundredths remove formatting differences from observation keys.
        observation=(result,None if angle is None else int(round(angle*100)))
        service=(5000000+1000000*(action.channel!=state.receiver)
                 if action.kind=='measure' else 5000000 if result=='success' else 3000000)
        cost=movement_us(self.point(state.position),self.point((action.ix,action.iy)))+service
        return observation,cost,scene.total_count

    def partition(self, state, action, check=lambda:None):
        """Exhaust the exact information set BEFORE returning any branch weight."""
        groups={}
        count=0
        for seed in self.seed_ids(state):
            check()
            observation,cost,n=self.feedback(seed,state,action)
            self.seed_evaluations+=1
            if cost > state.remaining_us:
                return None  # One possible scene violates the hard budget.
            group=groups.setdefault(observation,dict(members=[],cost=cost,normalized=Fraction()))
            if cost!=group['cost']:
                raise AssertionError('Physical outcome must determine this action cost')
            group['members'].append(seed)
            group['normalized']+=Fraction(cost,n)
            count+=1
        if not count:
            raise ValueError('Empty information set')
        branches=[]
        for obs,g in groups.items():
            cleared=state.cleared
            if action.kind=='clear' and obs[0]=='success':
                cleared |= 1 << (action.channel-1)
            child=State((action.ix,action.iy),
                action.channel if action.kind=='measure' else state.receiver,
                cleared,tuple(g['members']),state.remaining_us-g['cost'])
            branches.append(Branch(obs,Fraction(len(g['members']),count),
                g['normalized']/len(g['members']),child))
        self.complete_partitions+=1
        return tuple(branches)

    def mandatory_clear_lower(self, state):
        # Valid for every compatible official scene, even before enumeration.
        cleared=state.cleared.bit_count()
        return Fraction(5000000*max(0,10-cleared),10)

    def scope(self, initial):
        return dict(grid_step_um=self.step_um,
            seed_scope='all_uint256' if initial.members is None else 'explicit_seed_subset',
            seed_count=str(2**256 if initial.members is None else len(initial.members)),
            action_scope='complete_useful_grids' if self.restricted_actions is None else 'explicit_action_subset',
            custom_scenes=self.custom_scene_lookup,
            objective='E[total_virtual_time/total_source_count]',
            formal_full_model=(initial.members is None and self.restricted_actions is None
                               and not self.custom_scene_lookup))
