"""Joint service-mode/open-route MILP with a receiver-cost relaxation.

One incoming edge per service group and mode flow conservation select exactly
one mode per group. Group order variables eliminate disconnected subtours.
The first service uses the actual receiver. Later services use their minimum
receiver cost, a valid lower relaxation. A returned path is rescored with the
actual receiver sequence. Thus the solver dual bound and a rescored path bound
the finite frozen catalogue optimum (up to solver floating-point tolerances).
They do NOT bound full online expected completion time.
"""
import math
import time
import numpy as np
from scipy.optimize import Bounds, LinearConstraint
from .mip_runtime import milp
from scipy.sparse import coo_matrix


def path_cost(problem,path):
    last=-1;q=problem.receiver;cost=0.
    for i in path:
        cost+=float((problem.first if last<0 else problem.move[last])[i]+problem.service[i,q-1])
        q=int(problem.receiver_out[i,q-1]);last=i
    return cost


def solve(problem,reference_first,reference_order,seconds=2.,incumbent_path=None):
    started=time.monotonic();n=problem.n;m=len(problem.modes)
    allowed_first=set(getattr(problem,'allowed_first',range(m)))
    if reference_first not in allowed_first:raise ValueError('Incumbent first action must remain allowed')
    original=problem.fixed_order(reference_order,reference_first)
    free=problem.fixed_order(reference_order)
    best=min(original,free,key=lambda x:x[0]) if free[1][0] in allowed_first else original
    if incumbent_path is not None:
        if len(incumbent_path)!=n or len({problem.modes[i].group for i in incumbent_path})!=n:
            raise ValueError('Retained incumbent must cover every group exactly once')
        if incumbent_path[0] not in allowed_first:raise ValueError('Retained first action is not allowed')
        incumbent=(path_cost(problem,incumbent_path),tuple(incumbent_path))
        best=min(best,incumbent,key=lambda x:x[0])
    if n<2 and len(allowed_first)==m:
        return problem.solve(reference_first,reference_order)
    group=[mode.group for mode in problem.modes]
    # -1 is source, -2 is sink. No source->sink edge when work remains.
    edges=[(-1,j) for j in range(m)]+[(i,-2) for i in range(m)]
    edges += [(i,j) for i in range(m) for j in range(m) if group[i]!=group[j]]
    e=len(edges);cost=np.zeros(e+n)
    rows=[];cols=[];vals=[];lower=[];upper=[]
    def row(items,lo,hi):
        r=len(lower);lower.append(lo);upper.append(hi)
        for j,v in items:rows.append(r);cols.append(j);vals.append(v)
    incoming=[[] for _ in range(m)];outgoing=[[] for _ in range(m)]
    start=[];end=[];arcs=[]
    for k,(i,j) in enumerate(edges):
        if i<0:
            start.append(k);incoming[j].append(k)
            cost[k]=problem.first[j]+problem.service[j,problem.receiver-1]
        elif j<0:
            outgoing[i].append(k);end.append(k)
        else:
            outgoing[i].append(k);incoming[j].append(k);arcs.append((k,i,j))
            cost[k]=problem.move[i,j]+problem.service[j].min()
    row([(k,1.) for k in start],1.,1.);row([(k,1.) for k in end],1.,1.)
    for g in range(n):row([(k,1.) for i in problem.indices[g] for k in incoming[i]],1.,1.)
    for i in range(m):row([(k,1.) for k in incoming[i]]+[(k,-1.) for k in outgoing[i]],0.,0.)
    for k,i,j in arcs:row([(k,float(n)),(e+group[i],1.),(e+group[j],-1.)],-np.inf,float(n-1))
    matrix=coo_matrix((vals,(rows,cols)),shape=(len(lower),e+n)).tocsc()
    variable_upper=np.r_[np.ones(e),np.full(n,n-1)]
    for k,(i,j) in enumerate(edges):
        if i==-1 and j not in allowed_first:variable_upper[k]=0.
    result=milp(cost,integrality=np.r_[np.ones(e),np.zeros(n)],
        bounds=Bounds(np.zeros(e+n),variable_upper),
        constraints=LinearConstraint(matrix,np.asarray(lower),np.asarray(upper)),
        options={'time_limit':max(.001,float(seconds)),'mip_rel_gap':.0001})
    candidate_valid=False;relaxed_primal=None
    if result.x is not None:
        selected=[edges[k] for k in range(e) if result.x[k]>.5]
        successor=dict(selected);path=[];current=-1
        for _ in range(n+1):
            current=successor.get(current,-3)
            if current<0:break
            path.append(current)
        candidate_valid=(current==-2 and len(path)==n and len({group[i] for i in path})==n
                         and len(selected)==n+1 and path[0] in allowed_first)
        if candidate_valid:
            candidate=(path_cost(problem,path),tuple(path))
            if candidate[0]<best[0]:best=candidate
            relaxed_primal=float(result.fun)
    lower_bound=problem.lower((1<<n)-1,-1)
    dual=getattr(result,'mip_dual_bound',None)
    bound_valid=dual is None or not math.isfinite(float(dual)) or float(dual)<=best[0]+1e-6
    if dual is not None and math.isfinite(float(dual)) and bound_valid:
        lower_bound=max(lower_bound,min(float(dual),best[0]))
    if lower_bound>best[0]+1e-6:raise ValueError('Catalogue lower bound exceeds retained feasible plan')
    assert best[0]<=original[0]+1e-6
    return best[1],dict(reference_s=float(original[0]),selected_s=float(best[0]),lower_s=float(lower_bound),
        gap_s=float(max(0.,best[0]-lower_bound)),exact_catalog=bool(best[0]-lower_bound<=1e-6),
        expanded=int(getattr(result,'mip_node_count',0) or 0),groups=n,modes=m,
        solver='joint_service_mode_open_route_MILP',solver_status=int(result.status),
        solver_message=result.message,receiver_relaxed=True,relaxed_primal_s=relaxed_primal,
        candidate_valid=bool(candidate_valid),bound_valid=bool(bound_valid),elapsed_s=time.monotonic()-started,
        allowed_first_actions=len(allowed_first),
        numerical_tolerance_only=True,scope='finite frozen service modes; not complete online time bound')


def solve_nested(problem,reference_first,reference_order,seconds=2.):
    """Spend extra computation only for a loose catalogue bound, retaining U."""
    first_budget=min(2.,seconds)
    path,proof=solve(problem,reference_first,reference_order,seconds=first_budget)
    first=dict(proof)
    extra=max(0.,seconds-first_budget)
    proof.update(refinement_rounds=1,first_pass_selected_s=first['selected_s'],
                 first_pass_lower_s=first['lower_s'],extra_computation_savings_s=0.)
    if extra>.001 and proof['gap_s']>max(5.,.005*proof['selected_s']):
        path,proof=solve(problem,reference_first,reference_order,seconds=extra,incumbent_path=path)
        assert proof['selected_s']<=first['selected_s']+1e-6
        proof['lower_s']=min(proof['selected_s'],max(first['lower_s'],proof['lower_s']))
        proof['gap_s']=max(0.,proof['selected_s']-proof['lower_s'])
        proof['exact_catalog']=proof['gap_s']<=1e-6
        proof['expanded']+=first['expanded'];proof['elapsed_s']+=first['elapsed_s']
        proof.update(refinement_rounds=2,first_pass_selected_s=first['selected_s'],
                     first_pass_lower_s=first['lower_s'],
                     extra_computation_savings_s=first['selected_s']-proof['selected_s'])
    return path,proof
