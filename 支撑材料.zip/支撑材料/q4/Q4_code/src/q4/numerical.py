"""Approximate local time model; bounded support certificates live in model.py.

Spatial quadrature, uniform range/heading/equal type design prior, Gaussian
closure of the official fixed field covariance. Neither exact official seed
posterior nor a globally optimal POMDP policy.
"""
import math
import random
import numpy as np
from discrete_model.numerical import Quadrature,field_weights,field_covariance,LocalBellman
from solver.posterior import polygon_sampler,PosteriorUnavailable
from solver.geometry import distance,diameter
from solver.official_physics import movement_us
from .model import components,semicircle,interval_overlap

def snap(p):return tuple(round(float(v),6) for v in p)

class Cloud(Quadrature):
    def visibility(self,p):
        d=np.linalg.norm(self.points-p,axis=1)
        radial=np.clip((self.high-d)/np.maximum(1e-9,self.high-self.low),0,1)
        fractions=[]
        for g,lo,hi,omni in zip(self.points,self.heading_lo,self.heading_hi,self.omni):
            if omni or distance(g,p)<1e-9:fractions.append(1.);continue
            angles=semicircle(math.atan2(p[1]-g[1],p[0]-g[0]))
            fractions.append(interval_overlap(lo,hi,angles)/(hi-lo))
        return radial*np.array(fractions)

class Posterior:
    def __init__(self,size=64):self.size=size;self.cache={};self.depletions=0

    def cloud(self,b):
        key=(tuple(b.observations),tuple(b.failed_clears))
        if b.channel in self.cache and self.cache[b.channel][0]==key:return self.cache[b.channel][1]
        directions=list(dict.fromkeys((p,a) for p,k,a in b.observations if k=='direction'))
        fw=[field_weights(p) for p,a in directions]
        covariance=np.array([[field_covariance(a,c) for c in fw] for a in fw]).reshape((len(fw),len(fw)))
        inverse=np.linalg.pinv(covariance+np.eye(len(fw))*(.01**2/12+1e-8))
        draw=polygon_sampler(b.polygon);rng=random.Random(f'q4-quadrature:{b.channel}:{key}')
        points=[];rows=[];logs=[];residuals=[]
        for _ in range(384):
            p=draw(rng)
            if math.hypot(*p)>1800:continue
            residual=np.array([(a-math.degrees(math.atan2(p[1]-q[1],p[0]-q[0]))+180)%360-180 for q,a in directions])
            if np.any(np.abs(residual)>1.0051):continue
            likelihood=-.5*float(residual@inverse@residual)
            for component in components(b,p):
                points.append(p);rows.append(component);logs.append(likelihood+math.log(component[5]));residuals.append(residual)
        if not rows:
            self.depletions+=1;raise PosteriorUnavailable('Q4 quadrature empty; retain geometric support')
        weights=np.exp(np.array(logs)-max(logs));weights/=weights.sum()
        indices=np.searchsorted(np.cumsum(weights),(np.arange(self.size)+.5)/self.size)
        indices,counts=np.unique(indices,return_counts=True);data=np.array(rows)[indices]
        cloud=Cloud(np.array(points)[indices],counts/self.size,data[:,2],data[:,3],fw,inverse,np.array(residuals)[indices])
        cloud.heading_lo=data[:,0];cloud.heading_hi=data[:,1];cloud.omni=data[:,4].astype(bool)
        self.cache[b.channel]=(key,cloud);return cloud

class LocalTime(LocalBellman):
    def measurement(self,cloud,p,start,receiver,channel,end):
        d=np.linalg.norm(cloud.points-p,axis=1);visible=cloud.visibility(p)
        angle=np.degrees(np.arctan2(cloud.points[:,1]-p[1],cloud.points[:,0]-p[0]))
        mean,sigma=cloud.prediction(p);branches={}
        for offset,weight in ((-math.sqrt(3),1/6),(0,2/3),(math.sqrt(3),1/6)):
            observed=np.round((angle+np.clip(mean+offset*sigma,-1,1))*100)/100%360
            bins=np.floor(observed/self.bin_deg).astype(int);bins[d<=5]=-2
            for bucket in np.unique(bins):
                branch=branches.setdefault(int(bucket),np.zeros(len(d)))
                branch+=cloud.weights*visible*weight*(bins==bucket)
        branches[-1]=cloud.weights*(1-visible)
        value=movement_us(start,p)/1e6+5+int(channel!=receiver)
        for weights in branches.values():
            chosen=weights>1e-12
            if np.any(chosen):
                cost,_=self.cover(cloud.points[chosen],weights[chosen],p,end)
                value+=float(weights.sum())*cost
        return value

    def choose(self,b,cloud,start,receiver,end=None,extra=()):
        cost,p=self.cover(cloud.points,cloud.weights,start,end);best=(cost,'clear',snap(p))
        length,a,z=diameter(b.polygon)
        axis=np.array([-(z[1]-a[1]),z[0]-a[0]])/max(length,1e-9)
        center=np.array(cloud.mean)
        candidates=[snap(center),snap(start),*map(snap,extra)]
        # Broad lateral baselines target the long geometric axis, not just the
        # often narrower Gaussian cloud. Lost-signal outcomes are costed above.
        for scale in (.35,.8,1.4):
            offset=max(25,min(700,b.radius*scale))
            candidates.extend(snap(center+side*offset*axis) for side in (-1,1))
        positive=[p for p,k,_ in b.observations if k in ('direction','near')]
        for q in positive[-1:]:
            candidates.extend(snap(np.array(q)*(1-t)+center*t) for t in (.5,.8))
        for p in dict.fromkeys(candidates):
            if math.hypot(*p)>3300 or any(distance(p,q)<.01 for q,_,_ in b.observations):continue
            value=self.measurement(cloud,p,start,receiver,b.channel,end);self.evaluations+=1
            if value<best[0]:best=(value,'measure',p)
        return best
