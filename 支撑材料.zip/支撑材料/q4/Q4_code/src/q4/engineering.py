"""Receding-horizon robust covering-path optimization; v3 remains available."""
import time
import numpy as np
from .controller import Q4Controller
from .cover_route import covering_path
from .model import remaining_lower_bound
from .numerical import snap
from solver.geometry import clear_position,distance
from solver.planner import Job
from solver.posterior import PosteriorUnavailable

def on_route_candidates(start,end,mean,previous=None):
    """Zero-detour sensing candidates on the next route segment.

    Include the nearest projection and the point giving perpendicular bearing
    intersection, when either lies on the segment. Angular geometry only
    proposes candidates: the feedback-conditioned time model selects them.
    """
    if end is None:return []
    a=np.asarray(start,dtype=float);v=np.asarray(end,dtype=float)-a;g=np.asarray(mean,dtype=float)
    length2=float(v@v)
    if length2<1:return []
    parameters={.25,.5,.75,max(0.,min(1.,float((g-a)@v/length2)))}
    if previous is not None:
        bearing=g-np.asarray(previous);den=float(bearing@v)
        if abs(den)>1e-8:
            t=float(bearing@(g-a)/den)
            if 0<=t<=1:parameters.add(t)
    return [snap(a+t*v) for t in sorted(parameters)]

class EngineeringController(Q4Controller):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress)
        self.routing_budget=budget
        self.routing_gap=.005
        self.statistics.update(mip_calls=0,mip_improvements=0,mip_proxy_savings_s=0.,mip_bound_errors=0)

    def refine_order(self,planned,current,unknown):
        return planned,None

    def next_job(self):
        self.update_absence()
        if self.completed():raise ValueError('No pending task')
        current=self.client.position
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if unknown and not self.map.scanned:return Job('scan',(0.,0.),anchor=0)
        found=[b for b in self.beliefs.values() if b.state=='found']
        proxy=[]
        for b in found:
            reliable=clear_position(b.polygon,current)
            proxy.append((b.channel,snap(reliable if reliable is not None else b.center)))
        # Candidate additions are derived only from observations/current state.
        # They are optional: their service and travel must fit the same model.
        optional=[current]+[p for _,p in sorted(proxy,key=lambda cp:distance(current,cp[1]))[:3]] if unknown else []
        available=self.routing_budget
        deadline=getattr(self.client,'deadline',None)
        if deadline is not None:
            available=min(available,max(0.,deadline-time.monotonic()-self.client.exit_margin-2.))
        planned,stats=covering_path(self.map,current,proxy,len(unknown),budget=available,
            optional=optional,relative_gap=self.routing_gap,
            primal_improvement=getattr(self,'routing_primal_improvement',False))
        if not planned:raise ValueError('Covering-path planner lost pending work')
        reference=list(planned)
        planned,service_decision=self.refine_order(planned,current,unknown)
        first=planned[0]
        # Execute the first optimized task. Every found channel retains the
        # finite geometric fallback; it cannot postpone unknown scans forever.
        rest=[s.point for s in planned if s is not first];end=rest[0] if rest else None
        if first.kind=='scan':job=Job('scan',first.point,anchor=first.anchor)
        else:
            b=self.beliefs[first.channel];reliable=clear_position(b.polygon,current)
            if reliable is not None:job=Job('clear',snap(reliable),b.channel,True)
            elif b.local_measurements>=self.local_budget or len(b.failed_clears)>=4:job=self.fallback(b,current)
            else:
                try:
                    cloud=self.posterior.cloud(b)
                    extras=[s.point for s in planned if s.kind=='scan' and distance(s.point,b.center)<1000][:2]
                    positive=[p for p,k,_ in b.observations if k in ('direction','near')]
                    extras+=on_route_candidates(current,end,cloud.mean,positive[-1] if positive else None)
                    _,kind,p=self.local.choose(b,cloud,current,self.client.channel,end,extras)
                    job=Job(kind,p,b.channel,False)
                except PosteriorUnavailable:job=self.fallback(b,current)
        self.planning_calls+=1;self.statistics['planning_calls']+=1
        self.statistics['mip_calls']+=1
        self.statistics['mip_improvements']+=int(stats['accepted'])
        self.statistics['mip_bound_errors']+=int(not stats['bound_valid'])
        self.statistics['mip_proxy_savings_s']+=max(0,stats['baseline_cost_s']-stats['upper_bound_s'])
        self.client.record('q4_covering_path',job=job.__dict__,route=[s.__dict__ for s in planned],
            milp_reference_route=[s.__dict__ for s in reference],service_decision=service_decision,optimization=stats,
            lower_bound=remaining_lower_bound(self.beliefs,current,self.client.virtual_s),full_time_optimality_certified=False)
        return job

    def run(self):
        result=super().run()
        result.update(policy='q4_engineering',strategy_version='q4-engineering-v2')
        result['q4_model'].update(routing='robust covering-path MILP with connectivity cuts',
            routing_time_limit_s=self.routing_budget,routing_relative_gap=self.routing_gap,
            full_expectation_optimality_certified=False)
        self.client.record('q4_engineering_summary',summary=result)
        return result
