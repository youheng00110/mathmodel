"""Q4 bounded geometry and approximate time planning; no global optimum claim."""
