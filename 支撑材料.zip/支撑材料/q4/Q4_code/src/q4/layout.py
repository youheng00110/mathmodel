"""Layout-independent certificates for directional search over a full disk.

A source g is visible for every heading if it is in the convex hull of scan
sites within reception range. For a whole triangle we require every vertex
inside that hull and every selected scanner within range of every vertex.
Convexity extends both conditions to every point, with no heading sampling.
An outer polygon contains the source disk. Adaptive subdivision partitions
that polygon; an unresolved leaf is never silently discarded.
"""
import math
import json
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull, Delaunay
from .model import DirectionMap
from solver.geometry import distance, clip_disk_outer


def rings(n, inner, outer):
    return [(0., 0.)] + [
        (round(r*math.cos((2*k+phase)*math.pi/n), 6),
         round(r*math.sin((2*k+phase)*math.pi/n), 6))
        for r, phase in ((inner, 1), (outer, 0)) for k in range(n)]


def certify_layout(points, radius=1800., receive=1000., sides=96,
                   minimum_cell=.1, maximum_cells=500000):
    """Sufficient continuous certificate; failure means unverified, not infeasible.

    All range checks reserve 1 cm. Convex-hull halfspaces reserve 1 micrometre.
    Certificate leaves store the subset of scanner IDs proving that leaf.
    Returned coordinates are the actual rounded API coordinates.
    """
    points=np.asarray(points, dtype=float)
    a=np.arange(sides)*2*math.pi/sides
    boundary=np.stack((np.cos(a),np.sin(a)),axis=1)*(radius+.001)/math.cos(math.pi/sides)
    todo=np.array([[np.zeros(2),boundary[k],boundary[(k+1)%sides]] for k in range(sides)])
    leaves=[]; witnesses=[]; unresolved=[]; rounds=0; hulls={}
    while len(todo):
        rounds+=1
        safe=np.all(np.linalg.norm(todo[:,None,:,:]-points[None,:,None,:],axis=3)<receive-.01,axis=2)
        groups={}
        for i,row in enumerate(safe):groups.setdefault(tuple(np.flatnonzero(row)),[]).append(i)
        passed=np.zeros(len(todo),dtype=bool)
        for selected,ids in groups.items():
            if len(selected)<3:continue
            if selected not in hulls:
                p=points[list(selected)]
                if np.linalg.matrix_rank(p-p[0])<2:hulls[selected]=None
                else:
                    hull=ConvexHull(p)
                    hulls[selected]=(hull.equations,tuple(int(selected[i]) for i in hull.vertices))
            entry=hulls[selected]
            if entry is None:continue
            eq, witness=entry
            values=todo[ids]@eq[:,:2].T+eq[:,2]
            ok=np.all(values < -1e-6,axis=(1,2))
            for i in np.asarray(ids)[ok]:
                passed[i]=True;leaves.append(todo[i]);witnesses.append(witness)
        failed=todo[~passed]
        if not len(failed):break
        edge2=np.sum((failed-np.roll(failed,-1,axis=1))**2,axis=2)
        longest=np.argmax(edge2,axis=1)
        small=np.max(edge2,axis=1)<=minimum_cell**2
        unresolved.extend(failed[small])
        failed=failed[~small];longest=longest[~small]
        if len(leaves)+len(failed)*2>maximum_cells:
            unresolved.extend(failed);break
        children=[]
        for tri,k in zip(failed,longest):
            u,v,w=tri[k],tri[(k+1)%3],tri[(k+2)%3];mid=(u+v)/2
            children.extend(((u,mid,w),(mid,v,w)))
        todo=np.asarray(children)
    return dict(certified=not unresolved,points=points.tolist(),
        vertices=np.asarray(leaves).tolist(),witnesses=[list(x) for x in witnesses],
        unresolved=np.asarray(unresolved).tolist(),rounds=rounds,
        source_domain_radius_m=radius,minimum_receive_radius_m=receive,
        range_margin_m=.01,hull_margin_m=1e-6,outer_polygon_sides=sides,
        anchor_count=len(points),method='adaptive triangle / in-range convex hull')


class LayoutMap(DirectionMap):
    """Independently check the deployed mesh, then track channel absence.

    A triangulation of the scan-site convex hull covers the entire source disk.
    Edges below the minimum reception range certify every parent triangle.
    No numerical optimizer status or sampled visibility test is trusted here.
    """
    def __init__(self, points=None, bins=72):
        if points is None:
            points=json.loads(Path(__file__).with_name('layout_parameters.json').read_text())['points']
        a=np.asarray(points,dtype=float)
        if a.ndim!=2 or a.shape[1]!=2 or not np.isfinite(a).all():raise ValueError('Invalid layout')
        hull=ConvexHull(a)
        apothem=float(np.min(-hull.equations[:,2]))
        if apothem<=1800.01:raise ValueError('Layout hull does not enclose source disk with margin')
        self.parents=[tuple(map(int,t)) for t in Delaunay(a).simplices]
        edge=max(float(np.linalg.norm(a[i]-a[j])) for ids in self.parents for i in ids for j in ids)
        if edge>=999.99:raise ValueError('Layout triangle exceeds conservative reception range')
        self.anchors=[tuple(p) for p in a.tolist()];cells=[];owners=[]
        for parent,ids in enumerate(self.parents):
            pending=[tuple(self.anchors[i] for i in ids)]
            while pending:
                tri=pending.pop()
                if max(distance(x,y) for x in tri for y in tri)>250:
                    x,y,z=tri;xy=tuple((u+v)/2 for u,v in zip(x,y));yz=tuple((u+v)/2 for u,v in zip(y,z));zx=tuple((u+v)/2 for u,v in zip(z,x))
                    pending.extend(((x,xy,zx),(xy,y,yz),(zx,yz,z),(xy,yz,zx)))
                else:
                    poly=clip_disk_outer(list(tri),(0.,0.),1800,sides=96) if any(math.hypot(*p)>1800 for p in tri) else list(tri)
                    for j in range(1,len(poly)-1):cells.append((poly[0],poly[j],poly[j+1]));owners.append(parent)
        self.vertices=np.asarray(cells);self.owners=np.asarray(owners);self.bins=bins
        self.full=(1<<(len(cells)*bins))-1;self.negative_mask=0;self.scanned=[];self.visited=set();self.cache={}
        self.parent_masks=[self.bits(np.repeat((self.owners==i)[:,None],bins,axis=1)) for i in range(len(self.parents))]
        self.certificate=dict(outer_apothem_m=apothem,largest_triangle_edge_m=edge,
            source_domain_radius_m=1800,minimum_receive_radius_m=1000,
            anchor_count=len(a),method='independently recomputed convex hull and Delaunay triangulation',
            continuous_all_headings=True,global_minimum_site_count_proved=False)

    def pending(self,current,additional_points=()):
        pending=set(range(len(self.anchors)))-self.visited
        for i in sorted(pending,key=lambda i:-distance(current,self.anchors[i])):
            candidate=pending-{i}
            if self.covered(candidate,additional_points)==self.full:pending=candidate
        return sorted(pending)
