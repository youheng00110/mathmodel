"""Q3 joint service-mode/route optimization with Q4 observation branches.

Each target offers alternative first actions and a complete finite conditional
clearance tail. All service modes and their visit order are selected together.
Distances average over actual conditional exits, not a posterior centre.
Unseen sources remain certified coverage obligations, not expanded discoveries.
The reused Q3 route solver certifies only its frozen finite catalogue.
"""
import math
import time
import numpy as np
from coupled_route.model import Mode, clear_tail
from coupled_route.routing import RouteProblem
from solver.geometry import clear_position, distance, diameter
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from .joint_service import JointServiceController
from .numerical import snap
from .engineering import on_route_candidates


def target_mode(group, job, cloud):
    weights=cloud.weights/float(cloud.weights.sum())
    if job.kind=='clear':
        cost,exits,prob=clear_tail(cloud.points,weights,job.point,forced=job.point)
        return Mode(group,job,cost,exits,prob)
    p=job.point;d=np.linalg.norm(cloud.points-p,axis=1)
    visible=cloud.visibility(p)  # range AND type/heading, conditioned on history
    angle=np.degrees(np.arctan2(cloud.points[:,1]-p[1],cloud.points[:,0]-p[0]))
    mean,sigma=cloud.prediction(p);branches={}
    for offset,w in ((-math.sqrt(3),1/6),(0,2/3),(math.sqrt(3),1/6)):
        observed=np.round((angle+np.clip(mean+offset*sigma,-1,1))*100)/100%360
        bins=np.floor(observed/.5).astype(int);bins[d<=5]=-2
        for bucket in np.unique(bins):
            branches.setdefault(int(bucket),np.zeros(len(d)))[:] += weights*visible*w*(bins==bucket)
    branches[-1]=weights*(1-visible)
    cost=0.;exits=[];prob=[]
    for bucket,w in branches.items():
        selected=w>1e-12;mass=float(w[selected].sum())
        if mass<=1e-12:continue
        c,e,q=clear_tail(cloud.points[selected],w[selected],p,forced=p if bucket==-2 else None)
        cost+=mass*c;exits.extend(e);prob.extend(mass*q)
    prob=np.asarray(prob)
    if abs(float(prob.sum())-1)>1e-8:raise ValueError('Q4 observation partition lost mass')
    return Mode(group,job,cost,np.asarray(exits),prob)


class CoupledController(JointServiceController):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress,budget)
        self.mode_cache={}
        self.coupled_stats=dict(decisions=0,changed_actions=0,changed_tasks=0,
            exact_catalog_solves=0,beam_solves=0,milp_solves=0,expanded=0,cache_builds=0,
            modelled_savings_s=0.,maximum_catalog_gap_s=0.)

    def cached_mode(self,group,job,cloud):
        b=self.beliefs[job.channel];history=(tuple(b.observations),tuple(b.failed_clears))
        if job.channel not in self.mode_cache or self.mode_cache[job.channel][0]!=history:
            self.mode_cache[job.channel]=(history,{})
        cache=self.mode_cache[job.channel][1];key=(job.kind,tuple(job.point))
        if key not in cache:
            cache[key]=target_mode(group,job,cloud);self.coupled_stats['cache_builds']+=1
        m=cache[key]
        return Mode(group,job,m.internal_s,m.exits,m.weights)

    def solve_modes(self,problem,first,order):
        return problem.solve(first,order,beam_width=96)

    def catalogue_jobs(self,original,channel,jobs):
        return jobs

    def configure_root(self,problem,first):
        pass

    def next_job(self):
        self.planned=();original=self.base_job()
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        found=[b for b in self.beliefs.values() if b.state=='found']
        if not self.planned or original.guaranteed or not found:return original
        if unknown and self.since_scan>=16:return original
        if any(b.local_measurements>=self.local_budget or len(b.failed_clears)>=4 for b in found):return original
        if self.client.deadline is not None and self.client.deadline-time.monotonic()<self.client.exit_margin+15:return original
        try:clouds={b.channel:self.posterior.cloud(b) for b in found}
        except PosteriorUnavailable:return original
        current=self.client.position
        scans=list(dict.fromkeys(tuple(s.point) for s in self.planned if s.kind=='scan'))
        centres={c:snap(cloud.mean) for c,cloud in clouds.items()}
        groups=[];keys=[];first=None
        for b in found:
            c=b.channel;cloud=clouds[c];g=len(groups);jobs=[]
            def add(kind,p,guaranteed=False):
                p=snap(p)
                if math.hypot(*p)>3300:return
                if kind=='measure' and any(distance(p,q)<.01 for q,_,_ in b.observations):return
                if not any(j.kind==kind and j.point==p for j in jobs):jobs.append(Job(kind,p,c,guaranteed))
            if original.channel==c and original.kind in ('measure','clear'):jobs.append(original)
            add('clear',centres[c])
            reliable=clear_position(b.polygon,current)
            if reliable is not None:add('clear',reliable,True)
            length,a,z=diameter(b.polygon)
            axis=np.array([-(z[1]-a[1]),z[0]-a[0]])/max(length,1e-9)
            proposals=[current,centres[c]]
            for scale in (.35,.8):
                offset=max(25,min(700,b.radius*scale))
                proposals.extend(np.asarray(centres[c])+side*offset*axis for side in (-1,1))
            proposals+=sorted(scans,key=lambda p:distance(p,centres[c]))[:2]
            proposals+=sorted((p for other,p in centres.items() if other!=c),key=lambda p:distance(p,centres[c]))[:1]
            for p in proposals:add('measure',p)
            jobs=self.catalogue_jobs(original,c,jobs)
            modes=[self.cached_mode(g,job,cloud) for job in jobs]
            if not modes:return original
            if original.channel==c:first=(g,0)
            groups.append(modes);keys.append(('target',c))
        for p in scans:
            g=len(groups)
            job=Job('scan',p,anchor=next((s.anchor for s in self.planned if s.kind=='scan' and tuple(s.point)==p),None),scan_channels=tuple(unknown))
            if original.kind=='scan' and tuple(original.point)==p:first=(g,0)
            groups.append([Mode(g,job,0.,np.array([p]),np.array([1.]))]);keys.append(('scan',p))
        if first is None or len(groups)<2:return original
        order_keys=[('target',s.channel) if s.kind=='target' else ('scan',tuple(s.point)) for s in self.planned]
        order=[first[0]]+sorted((i for i in range(len(groups)) if i!=first[0]),
                               key=lambda i:order_keys.index(keys[i]) if keys[i] in order_keys else len(order_keys))
        problem=RouteProblem(groups,current,self.client.channel)
        self.configure_root(problem,problem.indices[first[0]][first[1]])
        indices,proof=self.solve_modes(problem,problem.indices[first[0]][first[1]],order)
        selected=problem.modes[indices[0]].job
        changed=(selected.kind,selected.channel,selected.point)!=(original.kind,original.channel,original.point)
        stats=self.coupled_stats;stats['decisions']+=1;stats['changed_actions']+=int(changed)
        stats['changed_tasks']+=int((selected.kind,selected.channel)!=(original.kind,original.channel))
        stats['exact_catalog_solves']+=int(proof['exact_catalog'])
        if proof.get('solver')=='joint_service_mode_open_route_MILP':stats['milp_solves']+=1
        elif not proof['exact_catalog']:stats['beam_solves']+=1
        stats['expanded']+=proof['expanded'];stats['modelled_savings_s']+=proof['reference_s']-proof['selected_s']
        stats['maximum_catalog_gap_s']=max(stats['maximum_catalog_gap_s'],proof['gap_s'])
        self.client.record('q4_coupled_route_decision',original=original.__dict__,selected=selected.__dict__,
            plan=[dict(job=problem.modes[i].job.__dict__,internal_s=problem.modes[i].internal_s,
                exits=problem.modes[i].exits.tolist(),weights=problem.modes[i].weights.tolist()) for i in indices],
            **proof,observation_model='Q4 conditional range and heading visibility',
            future_discoveries_expanded=False,episode_nonincrease_guaranteed=False)
        return selected

    def run(self):
        result=super().run();result.update(policy='q4_coupled',strategy_version='q4-coupled-modes-v1')
        result['q4_model'].update(coupled_route=self.coupled_stats,
            future_discoveries_expanded=False,global_optimality_certified=False)
        self.client.record('q4_coupled_summary',summary=result)
        return result


class CoupledMilpController(CoupledController):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.mode_budget=2.

    def solve_modes(self,problem,first,order):
        from .mode_milp import solve_nested
        budget=self.mode_budget
        if self.client.deadline is not None:
            budget=min(budget,max(0.,self.client.deadline-time.monotonic()-self.client.exit_margin-2.))
        return solve_nested(problem,first,order,seconds=budget)

    def run(self):
        result=super().run();result.update(policy='q4_coupled_milp',strategy_version='q4-coupled-milp-v1')
        result['q4_model'].update(mode_solver='joint mode and route MILP with receiver relaxation',
            mode_solver_budget_s=self.mode_budget)
        self.client.record('q4_coupled_milp_summary',summary=result)
        return result


class CoupledPathController(CoupledMilpController):
    """Joint Q3 modes with feasible coverage-path repairs at every solve."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.routing_primal_improvement=True

    def configure_root(self,problem,first):
        # The clearance-only mode tails approximate the multi-measurement Q4
        # local policy poorly. Retain that policy for the incumbent target;
        # use joint modes to decide whether a DIFFERENT task should precede it.
        # This is a smaller explicit catalogue, not a claimed robustness bound.
        group=problem.modes[first].group
        if problem.modes[first].job.kind in ('measure','clear'):
            problem.allowed_first={i for i,m in enumerate(problem.modes) if i==first or m.group!=group}

    def run(self):
        result=super().run();result.update(policy='q4_coupled_path',strategy_version='q4-coupled-path-v3')
        result['q4_model']['coverage_primal_improvement']=True
        result['q4_model']['incumbent_target_local_policy_retained']=True
        self.client.record('q4_coupled_path_summary',summary=result)
        return result
