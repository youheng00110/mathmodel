"""Continuously optimized scan coordinates + existing online engineering policy."""
from .engineering import EngineeringController
from .layout import LayoutMap
from solver.geometry import distance
from solver.planner import Job


class LayoutController(EngineeringController):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress,budget)
        self.map=LayoutMap();self.anchors=self.map.anchors

    def next_job(self):
        if not self.map.scanned:
            i=min(range(len(self.anchors)),key=lambda i:distance(self.client.position,self.anchors[i]))
            return Job('scan',self.anchors[i],anchor=i)
        return super().next_job()

    def run(self):
        result=super().run()
        result.update(policy='q4_layout',strategy_version='q4-layout-v1')
        result['q4_model'].update(layout='24 asymmetric continuously optimized scan sites',
            first_scan_at_origin=False,full_expectation_optimality_certified=False)
        self.client.record('q4_layout_summary',summary=result)
        return result
