"""21-point regular layout, certified by in-range convex hulls.

For a cell T, every witness scanner is <1000 m from all vertices of T and
T lies inside their convex hull. Convexity then proves coverage for EVERY
position in T and EVERY directional heading, independently of a prior.
The parent mesh's edges need not all be below 1000 m: that stronger condition
would exclude this layout. No sampled heading test is used for certification.
"""
import math
import numpy as np
from scipy.spatial import ConvexHull
from .layout import certify_layout,LayoutMap
from .model import DirectionMap
from .layout_policy import LayoutController


def compact_points(inner=995.,outer_apothem=1801.):
    outer=outer_apothem/math.cos(math.pi/12)
    return [(0.,0.)]+[(round(r*math.cos(2*k*math.pi/n),6),round(r*math.sin(2*k*math.pi/n),6))
        for n,r in ((8,inner),(12,outer)) for k in range(n)]


class CompactMap(DirectionMap):
    pending=LayoutMap.pending

    def __init__(self,points=None,bins=72):
        self.anchors=compact_points() if points is None else list(map(tuple,points))
        cert=certify_layout(self.anchors,minimum_cell=.5,maximum_cells=40000)
        if not cert['certified']:raise ValueError('Compact layout has unresolved continuous coverage cells')
        groups={}
        for tri,witness in zip(cert['vertices'],cert['witnesses']):
            groups.setdefault(tuple(witness),[]).extend(tri)
        cells=[];owners=[];self.parents=[];max_range=0.
        # Merge equal-witness leaves into their convex hull. Every new hull
        # vertex was already certified. Both range disks and the witness hull
        # are convex, so the larger merged region remains certified as well.
        for witness,vertices in sorted(groups.items()):
            unique=np.unique(np.asarray(vertices),axis=0);hull=ConvexHull(unique)
            polygon=unique[hull.vertices];scanners=np.asarray([self.anchors[i] for i in witness])
            distance=float(np.max(np.linalg.norm(polygon[:,None]-scanners[None],axis=2)))
            eq=ConvexHull(scanners).equations
            if distance>=999.99 or np.any(polygon@eq[:,:2].T+eq[:,2]>=-1e-6):
                raise ValueError('Merged witness region failed independent range/hull check')
            max_range=max(max_range,distance);owner=len(self.parents);self.parents.append(witness)
            for j in range(1,len(polygon)-1):
                cells.append((polygon[0],polygon[j],polygon[j+1]));owners.append(owner)
        self.vertices=np.asarray(cells);self.owners=np.asarray(owners);self.bins=bins
        self.full=(1<<(len(cells)*bins))-1;self.negative_mask=0;self.scanned=[];self.visited=set();self.cache={}
        self.parent_masks=[self.bits(np.repeat((self.owners==i)[:,None],bins,axis=1)) for i in range(len(self.parents))]
        self.certificate=dict(method='adaptive continuous triangle coverage + independently checked merged in-range convex hull witnesses',
            source_domain_radius_m=1800,minimum_receive_radius_m=1000,anchor_count=len(self.anchors),
            outer_apothem_m=float(min(-ConvexHull(np.asarray(self.anchors)).equations[:,2])),
            maximum_witness_range_m=max_range,unmerged_certificate_cells=len(cert['vertices']),
            merged_cells=len(cells),witness_groups=len(self.parents),continuous_all_headings=True,
            global_minimum_site_count_proved=False)


class CompactController(LayoutController):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress,budget)
        self.map=CompactMap();self.anchors=self.map.anchors

    def run(self):
        result=super().run();result.update(policy='q4_compact',strategy_version='q4-compact-v1')
        result['q4_model'].update(layout='21 regular sites: origin + 8 at 995m + 12 with outer apothem 1801m',
            first_scan_at_origin=True,localization_and_clear_policy='unchanged layout-v1',
            full_expectation_optimality_certified=False)
        self.client.record('q4_compact_summary',summary=result);return result
