"""Q3 actual-action comparison adapted to Q4 visibility and safe coverage.

Each alternative serves one found target, then pays a route from its actual
outcome-dependent clear location through ALL other frozen target/scan tasks.
Deferred targets have the same history-dependent service estimates in every
comparison. Original actions are explicitly rescored and retained as options.
Future discoveries are not expanded; this is not the full Bayes value function.
"""
from collections import defaultdict
import numpy as np
from discrete_model.continuation_policy import FrozenRoute,clearance_value
from solver.geometry import distance,clear_position
from solver.official_physics import movement_us
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from .rotated_scan_policy import RotatedScanController
from .numerical import LocalTime,snap
from .engineering import on_route_candidates


class ActionTime(LocalTime):
    def __init__(self):
        super().__init__();self.terminal=None;self.stats=defaultdict(int)

    def cover(self,points,weights,start,end=None):
        if self.terminal is None:return super().cover(points,weights,start,end)
        return clearance_value(points,weights,start,self.terminal,self.stats,limit=8)


def clear_action_value(local,cloud,point,start,terminal):
    """One submitted clear; continue only after its observable success/failure."""
    hit=np.linalg.norm(cloud.points-point,axis=1)<=20
    probability=float(cloud.weights[hit].sum())/float(cloud.weights.sum())
    cost=movement_us(start,point)/1e6+3+2*probability+probability*terminal(point)
    if not np.all(hit):
        value,_=clearance_value(cloud.points[~hit],cloud.weights[~hit],point,
                                terminal,local.stats,limit=8)
        cost+=(1-probability)*value
    return float(cost)


class JointServiceController(RotatedScanController):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress,budget)
        self.planned=();self.context=None;self.service_cache={};self.action_time=ActionTime()
        self.joint_stats=dict(decisions=0,changed_actions=0,changed_tasks=0,
            target_evaluations=0,scan_evaluations=0,posterior_fallbacks=0,
            forced_scans=0,retained_incumbent_checks=0)

    def base_job(self):
        return super().next_job()

    def candidate_channels(self,eligible):
        return sorted(eligible,key=lambda c:distance(self.client.position,self.context['positions'][c]))[:3]

    def refine_order(self,planned,current,unknown):
        self.planned=tuple(planned)
        return planned,None

    def setup_context(self):
        clouds={};positions={};service={}
        for c,b in self.beliefs.items():
            if b.state!='found':continue
            try:cloud=self.posterior.cloud(b)
            except PosteriorUnavailable:
                self.joint_stats['posterior_fallbacks']+=1;return False
            reliable=clear_position(b.polygon,self.client.position)
            positions[c]=snap(reliable if reliable is not None else cloud.mean)
            clouds[c]=cloud
            if reliable is not None:service[c]=5.;continue
            key=(tuple(b.observations),tuple(b.failed_clears))
            old=self.service_cache.get(c)
            if old is None or old[0]!=key:
                # A common deferred-service estimate, not a lower/upper bound.
                estimate=LocalTime().choose(b,cloud,positions[c],c)[0]
                self.service_cache[c]=(key,estimate)
            service[c]=self.service_cache[c][1]
        scans=list(dict.fromkeys(tuple(s.point) for s in self.planned if s.kind=='scan'))
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        self.context=dict(clouds=clouds,positions=positions,service=service,
                          scans=scans,unknown=unknown,tails={})
        return True

    def terminal(self,channel=None,scan=None):
        ctx=self.context;key=(channel,scan)
        if key not in ctx['tails']:
            points=[p for c,p in ctx['positions'].items() if c!=channel]
            scans=[p for p in ctx['scans'] if p!=scan]
            points+=scans
            cost=sum(v for c,v in ctx['service'].items() if c!=channel)
            # Future scan membership/receiver are frozen; actual first batch
            # is charged exactly in score_job. No new-discovery optimism.
            cost+=max(0,6*len(ctx['unknown'])-1)*len(scans)
            reference=[ctx['positions'].get(s.channel,s.point) if s.kind=='target' else s.point
                       for s in self.planned]
            ctx['tails'][key]=FrozenRoute(points,reference,service=cost,exact_limit=12)
        return ctx['tails'][key]

    def score_job(self,job):
        start=self.client.position
        if job.kind=='scan':
            unknown=self.context['unknown'];n=len(unknown)
            cost=5*n+max(0,n-1)+int(bool(n) and self.client.channel not in unknown)
            return movement_us(start,job.point)/1e6+cost+self.terminal(scan=tuple(job.point))(job.point)
        cloud=self.context['clouds'][job.channel];terminal=self.terminal(channel=job.channel)
        if job.kind=='clear':return clear_action_value(self.action_time,cloud,job.point,start,terminal)
        self.action_time.terminal=terminal
        try:return self.action_time.measurement(cloud,job.point,start,self.client.channel,job.channel,None)
        finally:self.action_time.terminal=None

    def next_job(self):
        self.context=None;self.planned=()
        original=self.base_job()
        if not self.planned or original.guaranteed or (not self.map.scanned and
                not getattr(self,'decide_during_partial_scan',False)):return original
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if unknown and self.since_scan>=16:
            scan=next((s for s in self.planned if s.kind=='scan'),None)
            if scan is not None:
                self.joint_stats['forced_scans']+=1
                return Job('scan',scan.point,anchor=scan.anchor)
        # Keep the existing finite recovery mechanism when its selected target
        # exhausts the local measurement/failure budget.
        if original.kind!='scan':
            b=self.beliefs[original.channel]
            if b.local_measurements>=self.local_budget or len(b.failed_clears)>=4:return original
        if not self.setup_context():return original
        try:
            incumbent=self.score_job(original);best=incumbent;selected=original
            evaluated=[dict(job=original.__dict__,value_s=incumbent,incumbent=True)]
            eligible=[c for c,b in self.beliefs.items() if b.state=='found' and
                b.local_measurements<self.local_budget and len(b.failed_clears)<4]
            # Bounded candidate set: three nearest found targets plus the
            # incumbent target; all remaining tasks still enter every tail.
            candidates=self.candidate_channels(eligible)
            if original.kind!='scan' and original.channel not in candidates:candidates.append(original.channel)
            for c in candidates:
                b=self.beliefs[c];cloud=self.context['clouds'][c];terminal=self.terminal(channel=c)
                reliable=clear_position(b.polygon,self.client.position)
                if reliable is not None:
                    job=Job('clear',snap(reliable),c,True);value=self.score_job(job)
                else:
                    end=next((s.point for s in self.planned if s.channel!=c),None)
                    positive=[p for p,k,_ in b.observations if k in ('direction','near')]
                    extra=on_route_candidates(self.client.position,end,cloud.mean,positive[-1] if positive else None)
                    extra += sorted(self.context['scans'],key=lambda p:distance(p,cloud.mean))[:2]
                    self.action_time.terminal=terminal
                    try:value,kind,p=self.action_time.choose(b,cloud,self.client.position,self.client.channel,end,extra)
                    finally:self.action_time.terminal=None
                    job=Job(kind,p,c,False)
                self.joint_stats['target_evaluations']+=1
                evaluated.append(dict(job=job.__dict__,value_s=float(value)))
                if value<best-1e-7:best=float(value);selected=job
            for s in self.planned:
                if s.kind!='scan':continue
                job=Job('scan',s.point,anchor=s.anchor);value=self.score_job(job)
                self.joint_stats['scan_evaluations']+=1
                evaluated.append(dict(job=job.__dict__,value_s=float(value)))
                if value<best-1e-7:best=float(value);selected=job
            assert best<=incumbent+1e-7
            self.joint_stats['decisions']+=1;self.joint_stats['retained_incumbent_checks']+=1
            self.joint_stats['changed_actions']+=int((selected.kind,selected.channel,selected.point)!=(original.kind,original.channel,original.point))
            self.joint_stats['changed_tasks']+=int((selected.kind,selected.channel)!=(original.kind,original.channel))
            self.client.record('q4_joint_service_decision',original=original.__dict__,selected=selected.__dict__,
                incumbent_s=incumbent,selected_s=best,candidates=evaluated,
                scope='approximate frozen task continuation, not full online E[T/N]',
                full_expectation_optimality=False)
            return selected
        finally:self.context=None;self.action_time.terminal=None

    def run(self):
        result=super().run();result.update(policy='q4_joint_service',strategy_version='q4-joint-service-v1')
        result['q4_model'].update(joint_service=self.joint_stats,
            joint_clear_dp=dict(self.action_time.stats),future_discoveries_expanded=False,
            global_optimality_certified=False)
        self.client.record('q4_joint_service_summary',summary=result)
        return result
