"""Explicit computation allowance; does not change the virtual-time objective."""
import math


def validate(seconds=None,gap=None):
    if seconds is not None and (not math.isfinite(seconds) or seconds<0):
        raise ValueError('planning-seconds must be finite and nonnegative')
    if gap is not None and (not math.isfinite(gap) or not 0<=gap<1):
        raise ValueError('route-gap must be finite and in [0, 1)')


def configure(controller,seconds=None,gap=None):
    validate(seconds,gap)
    if seconds is None and gap is None:return
    if not hasattr(controller,'routing_budget'):
        raise ValueError('Selected policy does not have a covering-path MILP')
    if seconds is not None:controller.routing_budget=seconds
    if gap is not None:controller.routing_gap=gap
