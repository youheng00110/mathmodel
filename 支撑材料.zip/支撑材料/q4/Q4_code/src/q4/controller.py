"""Q4 complete coverage + conditional local time + shared route decisions."""
import math
import numpy as np
from solver.controller import Controller,Config
from solver.geometry import clear_position,distance,fallback_grid
from solver.planner import Job
from solver.protocol import scan_channel_order
from solver.posterior import PosteriorUnavailable
from discrete_model.numerical import route
from .model import DirectionMap,remaining_lower_bound
from .numerical import Posterior,LocalTime,snap

class Q4Controller(Controller):
    def __init__(self,client,progress=None):
        super().__init__(client,Config(problem=4,policy='optimized',max_actions=30000),progress)
        self.map=DirectionMap();self.anchors=self.map.anchors;self.posterior=Posterior();self.local=LocalTime()
        self.statistics=dict(shared_batches=0,shared_measurements=0,geometric_fallbacks=0,
            certified_absent=[],count_bound_absent=[],planning_calls=0,
            shared_scan_proposals=0,shared_scan_rejections=0,shared_scan_predicted_savings_s=0.,
            coverage_tasks_replaced=0)
        self.local_budget=8

    def update_absence(self):
        known=sum(b.state in ('found','cleared') for b in self.beliefs.values())
        if known==16 or self.map.remaining==0:
            reason='count_bound_absent' if known==16 else 'certified_absent'
            for b in self.beliefs.values():
                if b.state=='unknown':b.state='absent';self.statistics[reason].append(b.channel)

    def scan(self,job):
        # All channels that remain unknown have the SAME shared negative history.
        for c in scan_channel_order([c for c,b in self.beliefs.items() if b.state=='unknown'],self.client.channel):
            if self.completed():break
            b=self.beliefs[c]
            if any(distance(p,job.point)<.001 for p,_,_ in b.observations):continue
            self.measure(c,job.point,job.anchor)
        self.map.observe(job.point)
        if job.anchor is not None:self.visited.add(job.anchor)
        self.update_absence();self.since_scan=0

    def fallback(self,b,current):
        self.statistics['geometric_fallbacks']+=1
        if b.fallback_cache is None:b.fallback_cache=fallback_grid(b.polygon,25)
        # 25/sqrt(2)<20: a finite covering of the entire conservative polygon.
        remaining=[p for p in b.fallback_cache if all(distance(p,q)>.01 for q in b.failed_clears)]
        if not remaining:raise ValueError('Q4 conservative optical cover exhausted')
        try:
            cloud=self.posterior.cloud(b)
            points=np.asarray(remaining)
            mass=(np.linalg.norm(points[:,None,:]-cloud.points[None,:,:],axis=2)<=20)@cloud.weights
            cost=np.linalg.norm(points-current,axis=1)/5+3
            if mass.max()>0:
                # Change only the ORDER of the finite conservative covering.
                # A depleted/misspecified cloud can never delete a clear site.
                point=remaining[int(np.argmax(mass/cost))]
                return Job('clear',point,b.channel,False)
        except PosteriorUnavailable:pass
        return Job('clear',min(remaining,key=lambda p:distance(current,p)),b.channel,False)

    def next_job(self):
        self.update_absence()
        if self.completed():raise ValueError('No action required in complete state')
        current=self.client.position;unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if unknown and not self.map.scanned:return Job('scan',(0.,0.),anchor=0)
        found=[b for b in self.beliefs.values() if b.state=='found']
        pending=self.map.pending(current) if unknown else []
        points=[self.anchors[i] for i in pending]+[snap(b.center) for b in found]
        order,length=route(points,current);ordered=[points[i] for i in order]
        if not ordered:raise ValueError('Q4 lost pending work')
        first=order[0]
        if unknown and self.since_scan>=16:first=next(i for i in order if i<len(pending))
        # A forced coverage job may differ from order[0]; its continuation is
        # the first remaining route node, not necessarily the old order[1].
        rest=[points[i] for i in order if i!=first]
        end=rest[0] if rest else None
        if first<len(pending):
            i=pending[first];job=Job('scan',self.anchors[i],anchor=i)
        else:
            b=found[first-len(pending)];reliable=clear_position(b.polygon,current)
            if reliable is not None:job=Job('clear',snap(reliable),b.channel,True)
            elif b.local_measurements>=self.local_budget or len(b.failed_clears)>=4:job=self.fallback(b,current)
            else:
                try:
                    cloud=self.posterior.cloud(b)
                    extras=[self.anchors[i] for i in pending if distance(self.anchors[i],b.center)<1000][:2]
                    _,kind,p=self.local.choose(b,cloud,current,self.client.channel,end,extras)
                    job=Job(kind,p,b.channel,False)
                except PosteriorUnavailable:job=self.fallback(b,current)
        self.planning_calls+=1;self.statistics['planning_calls']+=1
        self.client.record('q4_planning',job=job.__dict__,frozen_route=ordered,
            route_length_proxy_m=length,remaining_orientation_cells=self.map.remaining.bit_count(),
            lower_bound=remaining_lower_bound(self.beliefs,current,self.client.virtual_s),
            time_optimality_certified=False)
        return job

    def measure(self,channel,position,anchor=None):
        response=super().measure(channel,position,anchor)
        return response

    def shared_at_current(self):
        """Add a bounded number of profitable found-channel measurements, no move.

        An unknown-channel scan must pay for itself by replacing future scan
        tasks in a complete certified cover, including their travel/service.
        """
        if self.completed() or not self.client.time_available():return
        p=self.client.position;selected=[]
        for b in self.beliefs.values():
            if b.state!='found' or b.local_measurements>=self.local_budget:continue
            if any(distance(p,q)<.01 for q,_,_ in b.observations):continue
            if b.radius<=20 or distance(p,b.center)>1450:continue
            try:
                cloud=self.posterior.cloud(b)
                direct,_=self.local.cover(cloud.points,cloud.weights,p)
                measured=self.local.measurement(cloud,p,p,self.client.channel,b.channel,None)
                if direct-measured>8:selected.append((direct-measured,b.channel))
            except PosteriorUnavailable:continue
        for _,c in sorted(selected,reverse=True)[:2]:
            if self.completed():break
            self.measure(c,p);self.statistics['shared_measurements']+=1
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if unknown and all(distance(p,q)>.01 for q in self.map.scanned):
            self.statistics['shared_scan_proposals']+=1
            pending=self.map.pending(p)
            after=self.map.pending(p,additional_points=(p,))
            removed=set(pending)-set(after)
            # Avoid substituting an incomparable cover using an optimistic
            # route estimate: only shortcut the same feasible tail here.
            saving=-math.inf
            if removed and set(after)<=set(pending):
                found=[snap(b.center) for b in self.beliefs.values() if b.state=='found']
                points=[self.anchors[i] for i in pending]+found
                order,length=route(points,p)
                keep=[points[j] for j in order if j>=len(pending) or pending[j] not in removed]
                shortcut=sum(distance(a,b) for a,b in zip([p]+keep,keep))
                scan_cost=5*len(unknown)+max(0,len(unknown)-1)
                initial_switch=int(self.client.channel not in unknown)
                saving=(length-shortcut)/5+len(removed)*scan_cost-scan_cost-initial_switch
            accepted=saving>1.
            self.client.record('q4_shared_scan_decision',position=p,accepted=accepted,
                removed_anchors=sorted(removed),predicted_net_savings_s=saving if math.isfinite(saving) else None,
                scope='all-negative frozen feasible tail; not an expected-time certificate')
            if accepted:
                self.scan(Job('scan',p));self.statistics['shared_batches']+=1
                self.statistics['coverage_tasks_replaced']+=len(removed)
                self.statistics['shared_scan_predicted_savings_s']+=saving
            else:self.statistics['shared_scan_rejections']+=1

    def run(self):
        # Parent loop remains responsible for transport errors/deadlines/exit.
        original=self.next_job
        def next_with_shared():
            # A completed state after sharing is handled by a harmless empty
            # batch; the parent loop rechecks completion before its next step.
            if self.actions:self.shared_at_current()
            if self.completed():return Job('batch',self.client.position,scan_channels=())
            return original()
        self.next_job=next_with_shared
        result=super().run()
        result.update(policy='q4_joint',strategy_version='q4-joint-v3',
            q4_model=dict(objective='E[T/N]',target_seconds_per_source=None,
                source_domain_radius_m=1800,coverage_certificate=self.map.certificate,
                position_heading_cells=len(self.map.vertices)*self.map.bins,
                remaining_position_heading_cells=self.map.remaining.bit_count(),
                quadrature_size=self.posterior.size,posterior_depletions=self.posterior.depletions,
                measurement_candidates_evaluated=self.local.evaluations,
                exact_official_seed_posterior=False,global_optimality_certified=False,
                scoring_prior='uniform position/range/heading; equal type weight; Gaussian field closure',
                generator_alignment='Q4 generator not yet replicated',**self.statistics))
        self.client.record('q4_summary',summary=result);return result
