"""Use one HiGHS thread per Q4 planner process, including earlier LP calls."""
import warnings
from scipy.optimize import milp as scipy_milp, linprog as scipy_linprog


def _call(solver,*args,**kwargs):
    options=dict(kwargs.pop('options',{}) or {})
    options['threads']=1
    with warnings.catch_warnings():
        # SciPy forwards unknown options to HiGHS, which accepts `threads`.
        warnings.filterwarnings('ignore',message='Unrecognized options detected:.*threads.*')
        return solver(*args,options=options,**kwargs)


def milp(*args,**kwargs):return _call(scipy_milp,*args,**kwargs)


def linprog(*args,**kwargs):return _call(scipy_linprog,*args,**kwargs)
