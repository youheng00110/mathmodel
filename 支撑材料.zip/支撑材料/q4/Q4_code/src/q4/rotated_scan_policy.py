"""Rotate the entire certified Q4 layout after the origin scan.

Rotations preserve the disk, distance and visibility dot products when source
positions and headings are rotated together. The all-position/all-heading
coverage theorem therefore transfers. Quantized deployment coordinates are
independently checked against every transformed witness triangle.
"""
import math
import numpy as np
from scipy.spatial import ConvexHull
from discrete_model.numerical import route
from .compact_policy import CompactController
from .numerical import snap


def rotation(degrees):
    a=math.radians(degrees)
    return np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])


def rotate_map(mapping,degrees):
    if any(math.hypot(*p)>.01 for p in mapping.scanned):
        raise ValueError('Layout rotation is only allowed after origin-only scans')
    r=rotation(degrees)
    anchors=[snap(p) for p in np.asarray(mapping.anchors)@r.T]
    vertices=mapping.vertices@r.T
    maximum=0.
    for i,witness in enumerate(mapping.parents):
        sites=np.asarray([anchors[j] for j in witness]);tri=vertices[mapping.owners==i]
        if not len(tri):continue
        reach=float(np.max(np.linalg.norm(tri[:,:,None,:]-sites[None,None,:,:],axis=3)))
        if reach>=999.999:raise ValueError('Rotation lost range margin after coordinate rounding')
        eq=ConvexHull(sites).equations
        if np.max(tri@eq[:,:2].T+eq[:,2])>=-1e-8:
            raise ValueError('Rotation lost convex hull witness margin')
        maximum=max(maximum,reach)
    apothem=float(min(-ConvexHull(np.asarray(anchors)).equations[:,2]))
    if apothem<=1800:raise ValueError('Rotated layout fails to enclose source disk')
    # Commit only after every independent check succeeds.
    history=list(mapping.scanned)
    mapping.anchors=anchors;mapping.vertices=vertices
    mapping.cache={};mapping.scanned=[];mapping.visited=set();mapping.negative_mask=0
    for p in history:mapping.observe(p)
    mapping.certificate=dict(mapping.certificate,rotation_degrees=degrees,
        maximum_witness_range_m=maximum,outer_apothem_m=apothem,
        rotation_certificate='disk rotational symmetry + independently checked rounded witness geometry')


def select_rotation(anchors,targets,current):
    tested={}
    def value(degrees):
        angle=round(degrees%90,8)
        if angle not in tested:
            points=[snap(p) for p in np.asarray(anchors[1:])@rotation(angle).T]+list(targets)
            _,length=route(points,current)
            tested[angle]=float(length/5)
        return tested[angle]
    for a in range(0,90,5):value(a)
    best=min(tested,key=tested.get)
    for d in (-2,-1,1,2):value(best+d)
    best=min(tested,key=tested.get)
    if tested[best]>=tested[0.]-1.:best=0.
    return best,dict(reference_proxy_s=tested[0.],selected_proxy_s=tested[best],
                     candidates=len(tested),angle_deg=best,full_expectation_optimality=False)


class RotatedScanController(CompactController):
    def __init__(self,client,progress=None,budget=.5):
        super().__init__(client,progress,budget)
        self.rotation_done=False;self.rotation_decision=None

    def next_job(self):
        if self.map.scanned and not self.rotation_done:
            self.rotation_done=True
            targets=[snap(b.center) for b in self.beliefs.values() if b.state=='found']
            if targets:
                angle,decision=select_rotation(self.anchors,targets,self.client.position)
                decision['accepted']=False
                if angle:
                    try:
                        rotate_map(self.map,angle);self.anchors=self.map.anchors
                        decision['accepted']=True
                    except ValueError as exc:decision['rejection']=str(exc)
                self.rotation_decision=decision
                self.client.record('q4_scan_rotation',**decision)
        return super().next_job()

    def run(self):
        result=super().run();result.update(policy='q4_rotated_scan',strategy_version='q4-rotated-scan-v1')
        result['q4_model'].update(scan_rotation=self.rotation_decision,
            rotation_scope='origin-history frozen-route proxy; continuous coverage retained; no full V* claim')
        self.client.record('q4_rotated_scan_summary',summary=result);return result
