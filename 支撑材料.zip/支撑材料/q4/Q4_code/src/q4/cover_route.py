"""Finite robust covering-path MILP with connectivity cuts and a feasible tail.

This optimizes a frozen workload, not the partially observed full task. Each
scan pays for all CURRENT unknown channels. Found targets are mandatory proxy
locations. Branch-and-bound bounds apply only to this explicitly logged model.
"""
from dataclasses import dataclass
import math,time
import numpy as np
from scipy.optimize import Bounds,LinearConstraint
from .mip_runtime import milp
from scipy.sparse import coo_matrix
from discrete_model.numerical import route

@dataclass(frozen=True)
class Site:
    point: tuple
    kind: str
    channel: int = None
    anchor: int = None

def path_cost(sites,order,start,service):
    points=[start]+[sites[i].point for i in order]
    return sum(math.dist(a,b)/5 for a,b in zip(points,points[1:]))+sum(service[i] for i in order)

def improve_primal(sites,start,service,required,coverage,certificates,order):
    """Feasible descent: delete redundant scan visits, then reconnect/reorder.

    Coverage is tested on whole certificate conjunctions. Triangle inequality
    and nonnegative service costs make a feasible deletion nonincreasing.
    The final multistart route is accepted only after explicit cost comparison.
    """
    chosen=set(order);required=set(required);best=list(order)
    def feasible(ids):
        return required<=ids and all(ids.intersection(direct) or any(
            set(certificates[k])<=ids for k in witness) for direct,witness in coverage)
    if not feasible(chosen):raise ValueError('Infeasible primal route')
    while len(best)>1:
        choices=[]
        for k,i in enumerate(best):
            if i in required or not feasible(chosen-{i}):continue
            previous=start if k==0 else sites[best[k-1]].point
            saving=math.dist(previous,sites[i].point)/5+service[i]
            if k+1<len(best):
                following=sites[best[k+1]].point
                saving+=(math.dist(sites[i].point,following)-math.dist(previous,following))/5
            choices.append((saving,-i,k))
        if not choices:break
        _,_,k=max(choices);chosen.remove(best.pop(k))
    permutation,_=route([sites[i].point for i in best],start)
    candidate=[best[i] for i in permutation]
    if path_cost(sites,candidate,start,service)<path_cost(sites,best,start,service):best=candidate
    return best

def solve_path(sites,start,service,required,coverage,certificates,baseline,budget=.75,relative_gap=.005,primal_improvement=False):
    """Optional-vertex open path. coverage rows list direct site witnesses and
    certificate indices. A certificate can be activated only if every listed
    site is visited. baseline is independently known feasible by the caller.

    degree(i)=2*y_i-e_i; sum(e_i)=1; degree(start)=1. Subtour separation uses
    sum(x over cut(C)) >= y_k, k in C, for components not containing start.
    """
    if not math.isfinite(budget) or budget<0:raise ValueError('Invalid planning budget')
    if not math.isfinite(relative_gap) or not 0<=relative_gap<1:raise ValueError('Invalid relative gap')
    started=time.monotonic();n=len(sites)
    if not n:return [],dict(upper_bound_s=0.,lower_bound_s=0.,gap=0.,accepted=False,rounds=0)
    edges=[(i,j) for i in range(n+1) for j in range(i+1,n+1)]
    ne=len(edges);yo=ne;eo=yo+n;zo=eo+n;size=zo+len(certificates)
    positions=[s.point for s in sites]+[start]
    c=np.zeros(size);c[:ne]=[math.dist(positions[i],positions[j])/5 for i,j in edges];c[yo:eo]=service
    rows=[];lower=[];upper=[]
    def add(terms,lo,hi):rows.append(terms);lower.append(lo);upper.append(hi)
    incident=[[] for _ in positions]
    for k,(i,j) in enumerate(edges):incident[i].append(k);incident[j].append(k)
    for i in range(n):
        add({**{k:1. for k in incident[i]},yo+i:-2.,eo+i:1.},0,0)
        add({eo+i:1.,yo+i:-1.},-np.inf,0)
    add({k:1. for k in incident[n]},1,1)
    add({eo+i:1. for i in range(n)},1,1)
    for i in required:add({yo+i:1.},1,1)
    for k,ids in enumerate(certificates):
        for i in ids:add({zo+k:1.,yo+i:-1.},-np.inf,0)
    for direct,witness in coverage:
        add({**{yo+i:1. for i in direct},**{zo+k:1. for k in witness}},1,np.inf)
    best=list(baseline);upper_bound=path_cost(sites,best,start,service);dual=0.;rounds=0;cuts=0;status=None
    repairs=0;primal_savings=0.
    if primal_improvement:
        candidate=improve_primal(sites,start,service,required,coverage,certificates,best)
        value=path_cost(sites,candidate,start,service)
        if value<upper_bound-1e-7:
            primal_savings+=upper_bound-value;best=candidate;upper_bound=value
    # A cutoff is safe: the supplied incumbent itself satisfies this model.
    add({i:float(v) for i,v in enumerate(c) if v},-np.inf,upper_bound+1e-6)
    while time.monotonic()-started<budget:
        rr=[];cc=[];vv=[]
        for r,terms in enumerate(rows):
            for col,v in terms.items():rr.append(r);cc.append(col);vv.append(v)
        matrix=coo_matrix((vv,(rr,cc)),shape=(len(rows),size)).tocsc()
        remaining=budget-(time.monotonic()-started)
        if remaining<=0:break
        result=milp(c,integrality=np.ones(size),bounds=Bounds(np.zeros(size),np.ones(size)),
            constraints=LinearConstraint(matrix,np.array(lower),np.array(upper)),
            options=dict(time_limit=remaining,mip_rel_gap=relative_gap))
        rounds+=1;status=int(result.status)
        bound=getattr(result,'mip_dual_bound',None)
        if bound is not None and math.isfinite(bound):dual=max(dual,float(bound))
        if result.x is None:break
        x=result.x
        # Independently reject tolerance/integrality/linear infeasibility.
        rounded=np.rint(x)
        if np.max(np.abs(x-rounded))>1e-5:break
        values=matrix@rounded
        if np.any(values<np.array(lower)-1e-5) or np.any(values>np.array(upper)+1e-5):break
        chosen={i for i in range(n) if rounded[yo+i]};adj={i:[] for i in chosen|{n}}
        for k,(i,j) in enumerate(edges):
            if rounded[k]:adj.setdefault(i,[]).append(j);adj.setdefault(j,[]).append(i)
        todo=set(adj);components=[]
        while todo:
            component=set();stack=[min(todo)]
            while stack:
                i=stack.pop()
                if i in component:continue
                component.add(i);stack.extend(j for j in adj[i] if j not in component)
            todo-=component;components.append(component)
        disconnected=[g for g in components if n not in g]
        if primal_improvement:
            # An integer disconnected solution still has a valid chosen set.
            # Reconnecting its visits produces an executable incumbent before
            # the next connectivity-cut solve can exhaust its time budget.
            candidate=improve_primal(sites,start,service,required,coverage,certificates,sorted(chosen))
            repairs+=1;value=path_cost(sites,candidate,start,service)
            if value<upper_bound-1e-7:
                primal_savings+=upper_bound-value;best=candidate;upper_bound=value
        if not disconnected:
            order=[];previous=None;current=n
            while True:
                following=[i for i in adj[current] if i!=previous]
                if not following:break
                if len(following)!=1:raise ValueError('Invalid connected open path')
                previous,current=current,following[0];order.append(current)
                if len(order)>n:raise ValueError('Unexpected cycle')
            if set(order)!=chosen:raise ValueError('Path missed selected nodes')
            value=path_cost(sites,order,start,service)
            if value<upper_bound-1e-7:best=order;upper_bound=value
            break
        for component in disconnected:
            boundary={k:1. for k,(i,j) in enumerate(edges) if (i in component)!=(j in component)}
            for i in component:add({**boundary,yo+i:-1.},0,np.inf);cuts+=1
    # A dual above a known feasible incumbent is a numerical/model error, not
    # a global optimality certificate. Preserve the incumbent and flag it.
    valid_bound=dual<=upper_bound+1e-5
    return best,dict(upper_bound_s=upper_bound,lower_bound_s=dual if valid_bound else None,
        gap=max(0.,(upper_bound-dual)/max(upper_bound,1.)) if valid_bound else None,
        accepted=best!=list(baseline),rounds=rounds,connectivity_cuts=cuts,status=status,
        elapsed_s=time.monotonic()-started,bound_valid=valid_bound,
        requested_time_limit_s=budget,requested_relative_gap=relative_gap,
        primal_repairs=repairs,primal_savings_s=primal_savings,
        scope='finite frozen covering-path MILP; not full online expected time')

def covering_path(mapping,current,found,unknown,budget=.75,optional=(),relative_gap=.005,scan_counts=None,primal_improvement=False):
    """Build universal-visibility constraints, preserving a complete fallback.

    The fallback conjunction guarantees its feasibility even when its geometry
    is certified by the stronger hull test instead of individual heading bins.
    """
    pending=mapping.pending(current) if unknown else []
    sites=[Site(tuple(mapping.anchors[i]),'scan',anchor=i) for i in pending]
    sites += [Site(tuple(p),'target',channel=c) for c,p in found]
    required=list(range(len(pending),len(sites)))
    order,_=route([s.point for s in sites],current);baseline=order[:]
    for p in optional:
        if all(math.dist(p,s.point)>.01 for s in sites if s.kind=='scan') and all(math.dist(p,q)>.01 for q in mapping.scanned):
            sites.append(Site(tuple(p),'scan'))
    # Consecutive scans reuse the preceding receiver via snake ordering.
    # Their common first-receiver surcharge (0 or 1s) does not affect argmin.
    service=[float(max(0,6*(scan_counts(s.point) if scan_counts is not None else unknown)-1))
             if s.kind=='scan' else 5. for s in sites]
    if budget<=0:
        # With no search budget solve_path returns this exact incumbent.
        # Avoid constructing its unused MILP matrix, but retain geometry checks.
        selected=[sites[i] for i in baseline]
        if unknown and mapping.covered(additional_points=[s.point for s in selected if s.kind=='scan'])!=mapping.full:
            raise ValueError('Zero-budget fallback lost directional coverage')
        cost=path_cost(sites,baseline,current,service)
        return selected,dict(upper_bound_s=cost,lower_bound_s=0.,gap=cost/max(cost,1.),
            accepted=False,rounds=0,connectivity_cuts=0,status=None,elapsed_s=0.,bound_valid=True,
            scope='certified incumbent only; MILP disabled',candidate_sites=len(sites),
            baseline_sites=len(baseline),selected_sites=len(selected),coverage_rows=0,
            baseline_cost_s=cost,service_model='6U-1s per scan; 5s per found target proxy',
            skipped_unused_milp_construction=True)
    certificates=[];coverage=[]
    if unknown:
        remaining=mapping.remaining;cells=len(mapping.vertices)*mapping.bins
        active=np.unpackbits(np.frombuffer(remaining.to_bytes((cells+7)//8,'little'),dtype=np.uint8),bitorder='little')[:cells].astype(bool)
        columns=[]
        for s in sites:
            mask=mapping.mask(s.point) if s.kind=='scan' else 0
            columns.append(np.unpackbits(np.frombuffer(mask.to_bytes((cells+7)//8,'little'),dtype=np.uint8),bitorder='little')[:cells])
        anchor_site={s.anchor:i for i,s in enumerate(sites) if s.anchor is not None}
        for parent,ids in enumerate(mapping.parents):
            missing=set(ids)-mapping.visited
            if missing<=set(anchor_site):
                certificates.append([anchor_site[i] for i in sorted(missing)])
                columns.append(np.repeat(mapping.owners==parent,mapping.bins).astype(np.uint8))
        certificates.append(list(range(len(pending))));columns.append(np.ones(cells,dtype=np.uint8))
        patterns=np.unique(np.stack(columns,axis=1)[active],axis=0)
        for row in patterns:
            coverage.append((list(np.flatnonzero(row[:len(sites)])),list(np.flatnonzero(row[len(sites):]))))
    result,stats=solve_path(sites,current,service,required,coverage,certificates,baseline,budget,relative_gap,primal_improvement)
    selected=[sites[i] for i in result]
    future=[s.point for s in selected if s.kind=='scan']
    if unknown and mapping.covered(additional_points=future)!=mapping.full:
        selected=[sites[i] for i in baseline]
        stats.update(accepted=False,geometric_rejection=True,
            upper_bound_s=path_cost(sites,baseline,current,service))
        bound=stats['lower_bound_s']
        stats['gap']=max(0.,(stats['upper_bound_s']-bound)/max(1.,stats['upper_bound_s'])) if bound is not None else None
    stats.update(candidate_sites=len(sites),baseline_sites=len(baseline),selected_sites=len(selected),coverage_rows=len(coverage),
        baseline_cost_s=path_cost(sites,baseline,current,service),
        service_model=('6*remaining_channels(point)-1 per scan; 5s per found target proxy; first receiver approximated'
            if scan_counts is not None else '6U-1s per scan; 5s per found target proxy; common first-receiver surcharge omitted'))
    return selected,stats
