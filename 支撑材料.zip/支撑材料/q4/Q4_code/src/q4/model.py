"""Conservative directional coverage, continuous heading intervals, time bounds.

Mathematical model: min E[T/N] over history-dependent complete policies.
Hidden source: exists, position in D(0,1800), range [1000,1500], type,
heading. Visibility = in-range AND (omni OR dot(position-source,heading)>=0).
Clearance ignores heading. Sensor noise is a fixed spatial field, not iid.
No assumed directional fraction or quadrature is used for absence certificates.
"""
import math
import numpy as np
from solver.geometry import coverage_nodes, distance, clip_disk_outer

TAU=2*math.pi

def semicircle(angle):
    lo=(angle-math.pi/2)%TAU;hi=lo+math.pi
    return [(lo,min(hi,TAU))]+([(0,hi-TAU)] if hi>TAU else [])

def interval_overlap(lo,hi,intervals):
    return sum(max(0.,min(hi,b)-max(lo,a)) for a,b in intervals)

def components(b,g):
    """Exact piecewise range/heading volume at a fixed hypothetical position.

    Uniform range/heading and equal prior type weights are DESIGN assumptions.
    Zero-volume boundaries are irrelevant to scoring; never used to certify.
    Returns (heading_lo,heading_hi,range_lo,range_hi,omni,relative_mass).
    """
    positive=[p for p,k,_ in b.observations if k in ('direction','near')]
    if any(distance(g,p)>5+1e-7 for p,k,_ in b.observations if k=='near'):
        return []
    if any(distance(g,p)<=5 for p,k,_ in b.observations if k=='direction'):
        return []
    if any(distance(g,p)<=20 for p in b.failed_clears):return []
    low=max([1000.]+[distance(g,p) for p in positive])
    if low>=1500:return []
    negative=list(dict.fromkeys(b.negatives))
    angles=[math.atan2(p[1]-g[1],p[0]-g[0]) for p in positive+negative]
    cuts=sorted({0.,TAU,*[(a+side*math.pi/2)%TAU for a in angles for side in (-1,1)]})
    out=[]
    high=min([1500.]+[distance(g,p) for p in negative])
    if high>low:out.append((0.,TAU,low,high,True,.5*(high-low)/500))
    for a,z in zip(cuts,cuts[1:]):
        m=(a+z)/2;u=(math.cos(m),math.sin(m))
        if any((p[0]-g[0])*u[0]+(p[1]-g[1])*u[1]<0 for p in positive):continue
        high=min([1500.]+[distance(g,p) for p in negative
            if (p[0]-g[0])*u[0]+(p[1]-g[1])*u[1]>=0])
        if high>low:out.append((a,z,low,high,False,.5*(z-a)/TAU*(high-low)/500))
    return out

class DirectionMap:
    """Outer triangle cells x closed heading bins, with convex-hull certificates.

    Any still-unknown channel has been measured at every shared scan location.
    A bin is removed only if ALL positions/headings would have received signal.
    Parent triangles additionally certify all headings when all three vertices
    have been scanned. This avoids gaps from heading-bin conservatism.
    """
    def __init__(self,bins=72):
        self.anchors=coverage_nodes(4);parents=[]
        for k in range(12):
            i,j=1+k,1+(k+1)%12;o,n=13+k,13+(k+1)%12
            parents.extend([(0,i,j),(o,n,i),(1+(k-1)%12,i,o)])
        self.parents=parents;cells=[];owners=[]
        for parent,ids in enumerate(parents):
            pending=[tuple(self.anchors[i] for i in ids)]
            while pending:
                tri=pending.pop()
                if max(distance(a,b) for a in tri for b in tri)>250:
                    a,b,c=tri;ab=tuple((x+y)/2 for x,y in zip(a,b));bc=tuple((x+y)/2 for x,y in zip(b,c));ca=tuple((x+y)/2 for x,y in zip(c,a))
                    pending.extend([(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)])
                else:
                    # Intersect with an OUTER polygon of the actual source
                    # disk. Never require searching the unused outer corners
                    # of the original 1865m anchor polygon.
                    polygon=clip_disk_outer(list(tri),(0.,0.),1800,sides=96) if any(math.hypot(*p)>1800 for p in tri) else list(tri)
                    for j in range(1,len(polygon)-1):
                        cells.append((polygon[0],polygon[j],polygon[j+1]));owners.append(parent)
        self.vertices=np.array(cells);self.owners=np.array(owners);self.bins=bins
        self.full=(1<<(len(cells)*bins))-1;self.negative_mask=0;self.scanned=[];self.visited=set();self.cache={}
        self.parent_masks=[]
        for i in range(len(parents)):
            mask=np.repeat((self.owners==i)[:,None],bins,axis=1)
            self.parent_masks.append(self.bits(mask))
        self.certificate=dict(outer_apothem_m=1865*math.cos(math.pi/12),
            largest_triangle_edge_m=max(distance(self.anchors[a],self.anchors[b]) for ids in parents for a in ids for b in ids),
            source_domain_radius_m=1800,minimum_receive_radius_m=1000,anchor_count=25)
        assert self.certificate['outer_apothem_m']>1800
        assert self.certificate['largest_triangle_edge_m']<1000

    @staticmethod
    def bits(a):return int.from_bytes(np.packbits(a.reshape(-1),bitorder='little').tobytes(),'little')

    def mask(self,p):
        p=tuple(p)
        if p in self.cache:return self.cache[p]
        v=np.asarray(p)-self.vertices;dist=np.linalg.norm(v,axis=2)
        angles=np.arctan2(v[:,:,1],v[:,:,0])[:,:,None]
        center=(np.arange(self.bins)+.5)*TAU/self.bins
        delta=np.abs((angles-center+math.pi)%TAU-math.pi)
        # Minimum dot over every angle in a bin and every triangle vertex.
        # Linear dependence on source position extends this to the entire cell.
        worst=np.minimum(math.pi,delta+math.pi/self.bins)
        dot=dist[:,:,None]*np.cos(worst)
        ok=np.all(dist<999.999,axis=1)[:,None]&np.all(dot>1e-6,axis=1)
        value=self.bits(ok)
        if len(self.cache)>256:self.cache.clear()
        self.cache[p]=value;return value

    def hull_cover(self,points,unresolved):
        """Certify cells inside the convex hull of universally in-range sites.

        For any source g in a certified cell and any heading u, g=sum(w_i p_i)
        implies some dot(p_i-g,u)>=0. Every selected site is strictly within
        1000m of the whole cell. Thus at least one negative is impossible.
        Strict interior/range margins avoid certifying floating-point edges.
        """
        if len(points)<3 or not unresolved:return 0
        points=np.unique(np.asarray(points,dtype=float),axis=0)
        ids=[i for i in range(len(self.vertices))
             if (unresolved>>(i*self.bins))&((1<<self.bins)-1)]
        triangles=self.vertices[ids]
        safe=np.all(np.linalg.norm(points[None,:,None,:]-triangles[:,None,:,:],axis=3)<999.999,axis=2)
        groups={}
        for i,row in zip(ids,safe):
            selected=tuple(np.flatnonzero(row))
            if len(selected)>=3:groups.setdefault(selected,[]).append(i)
        result=0;cell_mask=(1<<self.bins)-1
        def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
        for selected,cells in groups.items():
            ordered=[tuple(points[i]) for i in selected];lower=[];upper=[]
            for p in ordered:
                while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
                lower.append(p)
            for p in reversed(ordered):
                while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
                upper.append(p)
            hull=np.asarray(lower[:-1]+upper[:-1])
            if len(hull)<3:continue
            edge=np.roll(hull,-1,axis=0)-hull
            delta=self.vertices[cells][:,:,None,:]-hull
            side=edge[:,0]*delta[:,:,:,1]-edge[:,1]*delta[:,:,:,0]
            inside=np.all(side>1e-5,axis=(1,2))
            for i in np.asarray(cells)[inside]:result |= cell_mask<<(int(i)*self.bins)
        return result

    def covered(self,extra=(),additional_points=()):
        out=self.negative_mask;visited=self.visited|set(extra)
        visited |= {i for i,a in enumerate(self.anchors)
                    if any(tuple(a)==tuple(p) for p in additional_points)}
        for i in extra:out |= self.mask(self.anchors[i])
        for p in additional_points:out |= self.mask(p)
        for ids,mask in zip(self.parents,self.parent_masks):
            if set(ids)<=visited:out |= mask
        if out!=self.full:
            points=self.scanned+[self.anchors[i] for i in extra]+list(additional_points)
            out |= self.hull_cover(points,self.full & ~out)
        return out

    @property
    def remaining(self):return self.full & ~self.covered()

    def observe(self,p):
        p=tuple(p);self.scanned.append(p);self.negative_mask |= self.mask(p)
        for i,a in enumerate(self.anchors):
            if p==tuple(a):self.visited.add(i)

    def pending(self,current,additional_points=()):
        pending=set(range(25))-self.visited
        # Delete only tasks whose removal preserves a complete directional cover.
        for i in sorted(pending,key=lambda i:-distance(current,self.anchors[i])):
            candidate=pending-{i}
            if self.covered(candidate,additional_points)==self.full:pending=candidate
        return sorted(pending)

def remaining_lower_bound(beliefs,position,elapsed):
    """MST between enclosing disks enlarged by 20m, plus necessary clear time.

    This is a path relaxation for every compatible scene, not a mean-optimum
    certificate. Future unknown locations have zero relaxed movement cost.
    Divide the total by N_max=16 to obtain a safe per-source bound before N is known.
    """
    found=[b for b in beliefs.values() if b.state=='found']
    cleared=sum(b.state=='cleared' for b in beliefs.values())
    best=[max(0,distance(position,b.center)-b.radius-20) for b in found]
    visited=set();length=0.
    while len(visited)<len(found):
        j=min((j for j in range(len(found)) if j not in visited),key=lambda j:best[j])
        length+=best[j];visited.add(j)
        for k in range(len(found)):
            if k not in visited:best[k]=min(best[k],max(0,distance(found[j].center,found[k].center)-found[j].radius-found[k].radius-40))
    service=5*max(len(found),10-cleared,0)
    return dict(remaining_time_lower_bound_s=length/5+service,
        elapsed_plus_remaining_lower_bound_s=elapsed+length/5+service,
        per_source_lower_bound_s=(elapsed+length/5+service)/16,
        method='clearance_disk_MST + minimum_remaining_clear_count; N<=16',
        global_optimality_gap=False)
