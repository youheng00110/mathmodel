# 第四问代码

Python 3.11

解压本目录

```powershell
python -m pip install -r requirements.txt
python main.py --check
```

## 启动

预检

```powershell
python main.py --robot-id "你的队号" --mode practice --preview
```

演练：

```powershell
python main.py --robot-id "你的队号" --mode practice
```

正式：

```powershell
python main.py --robot-id "你的队号" --mode formal
默认API为 `http://127.0.0.1:2026`。
```

## 输出

每局创建 `results/q4_时间_随机后缀/`；也可通过 `--output 新目录` 指定。

| 文件 | 内容 |
|---|---|
| `config.json` | 队号、声明模式、接口与固定参数，执行前写入 |
| `actions.jsonl` | 请求/响应、覆盖路线规划、联合模式选择等原始记录 |
| `summary.json` | 完成状态、清除数、耗时、路线与覆盖证书统计 |

## 算法与论文

主线：位置/朝向相容状态与频道排除 → 全朝向覆盖后备 → 条件定位与清除任务 →
覆盖路径MILP及服务模式/访问次序联合MILP → 每次反馈后滚动规划。

| 论文部分 | 源码 |
|---|---|
| 固定策略与实际预算核验 | `src/q4_strategy.py` |
| 定向源位置、朝向覆盖状态 | `src/q4/model.py` |
| 21站布局和连续全朝向覆盖证书 | `src/q4/compact_policy.py`、`src/q4/layout.py` |
| 初始覆盖布局旋转 | `src/q4/rotated_scan_policy.py` |
| 定向可见性、条件信息与局部动作成本 | `src/q4/numerical.py` |
| 控制流程、未知频道扫描和25 m后备 | `src/q4/controller.py` |
| 覆盖任务与目标任务构造 | `src/q4/engineering.py` |
| 含连通约束的覆盖开放路径MILP | `src/q4/cover_route.py` |
| 多服务模式与不同任务的联合决策 | `src/q4/coupled_policy.py` |
| 服务模式/访问次序MILP与界 | `src/q4/mode_milp.py` |
| 单线程HiGHS调用 | `src/q4/mip_runtime.py` |
| 定位凸外包和可靠清除几何 | `src/solver/belief.py`、`src/solver/geometry.py` |
| HTTP客户端和动作计时 | `src/solver/protocol.py`、`src/solver/official_physics.py` |
| 退出后参考统计 | `src/postprocess.py`、`src/solver/oracle.py` |
