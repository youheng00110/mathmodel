import ast
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))


class NoTransport:
    def exchange(self, *args, **kwargs):
        raise AssertionError('Self-check must not make a simulator request')

    def close(self):
        pass


def check():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest['files']:
        path = HERE / entry['path']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
            raise RuntimeError('文件缺失或与提交版本不一致：' + entry['path'])
        if path.suffix == '.py':
            ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
    import numpy
    import scipy
    from scipy.optimize import milp
    from q4_strategy import Q4Controller, build_controller
    from q4.coupled_policy import CoupledPathController
    from solver.protocol import Client
    assert Q4Controller is CoupledPathController
    client = Client(NoTransport(), 'selfcheck')
    try:
        controller = build_controller(client)
        certificate = controller.map.certificate
        assert certificate['continuous_all_headings']
        assert certificate['source_domain_radius_m'] == 1800
        assert certificate['anchor_count'] == 21
        assert not client.entered and client.stats['clear_success'] == 0
    finally:
        client.close()
    print(json.dumps(dict(
        check='passed', verified_files=len(manifest['files']),
        strategy='q4-coupled-path-v3', python=sys.version.split()[0],
        numpy=numpy.__version__, scipy=scipy.__version__,
        milp_available=callable(milp), source_domain_m=1800, coverage_sites=21,
        continuous_all_headings=certificate['continuous_all_headings'],
        simulator_requests=0,
    ), ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(check())
