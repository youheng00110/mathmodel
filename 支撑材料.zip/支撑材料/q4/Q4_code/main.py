"""第四问提交程序的唯一运行入口。

自检：python main.py --check
预览：python main.py --robot-id 队号 --mode practice --preview
演练：python main.py --robot-id 队号 --mode practice
正式：python main.py --robot-id 队号 --mode formal
--mode 仅记录客户端声明，实际模式需在模拟器页面选择。
"""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import sys
import uuid

# 与原 Windows PowerShell 入口的数值线程配置一致。
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--robot-id', help='模拟器当前登录队号')
    parser.add_argument('--mode', choices=('practice', 'formal'), help='页面模式声明')
    parser.add_argument('--base-url', default='http://127.0.0.1:2026', help='模拟器API地址')
    parser.add_argument('--output', type=Path, help='新建结果目录；默认自动生成唯一目录')
    parser.add_argument('--preview', action='store_true', help='只显示配置，不连接模拟器')
    parser.add_argument('--check', action='store_true', help='文件、依赖与覆盖构造自检，不连接模拟器')
    args = parser.parse_args()
    if args.check:
        if args.preview or args.robot_id or args.mode or args.output:
            parser.error('--check 单独使用')
    elif not args.robot_id or not args.robot_id.strip() or not args.mode:
        parser.error('运行或预览必须同时提供 --robot-id 和 --mode')
    return args


def main():
    args = parse_args()
    if args.check:
        from verify import check
        return check()
    from q4_strategy import effective_parameters
    config = dict(
        problem=4, policy='q4_coupled_path', strategy_version='q4-coupled-path-v3',
        declared_mode=args.mode, robot_id=args.robot_id, base_url=args.base_url,
        parameters=effective_parameters(), entry='Q4_submission/main.py',
    )
    print(json.dumps(config, ensure_ascii=False, indent=2), flush=True)
    print(f'Q4 {args.mode.upper()}: select the matching simulator UI mode before running.', flush=True)
    if args.preview:
        print('Preview only; no simulator requests.')
        return 0

    from q4_strategy import build_controller
    from solver.protocol import Client, HTTPTransport
    from postprocess import append_route_reference
    output = args.output or HERE / 'results' / (
        'q4_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
    )
    output.mkdir(parents=True, exist_ok=False)
    (output / 'config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    client = Client(HTTPTransport(args.base_url, 8), args.robot_id, output / 'actions.jsonl', 15, 360000)
    try:
        summary = build_controller(client, print).run()
    finally:
        client.close()
    summary['declared_mode'] = args.mode
    summary_path = output / 'summary.json'
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    append_route_reference(summary, output / 'actions.jsonl')
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    fields = ('policy', 'completion_certified', 'exit_confirmed', 'clear_success', 'clear_failure', 'average_clear_time_s', 'error')
    print(json.dumps({key: summary.get(key) for key in fields}, ensure_ascii=False, indent=2))
    print('Results:', output.resolve())
    return 0 if summary['completion_certified'] and summary['exit_confirmed'] and not summary['error'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
