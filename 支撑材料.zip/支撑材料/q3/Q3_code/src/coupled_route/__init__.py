"""Joint routing over observation-dependent target-service modes."""
