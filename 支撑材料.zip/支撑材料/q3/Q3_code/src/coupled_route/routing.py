"""Subset DP for <=7 service groups; bounded beam search above that size.

A complete incumbent whose first action is the reference action is retained.
The group-MST bound relaxes mode compatibility, channel costs and direction.
All optimality/bound statements concern this finite frozen expected-cost model.
"""
from functools import lru_cache
import math
import numpy as np
from solver.geometry import distance

class RouteProblem:
    def __init__(self,groups,start,receiver):
        self.groups=groups;self.start=start;self.receiver=receiver
        self.modes=[m for group in groups for m in group];self.n=len(groups)
        self.indices=[[i for i,m in enumerate(self.modes) if m.group==g] for g in range(self.n)]
        entries=np.array([m.job.point for m in self.modes])
        self.move=np.array([m.weights@ (np.linalg.norm(m.exits[:,None,:]-entries[None,:,:],axis=2)/5) for m in self.modes])
        self.first=np.linalg.norm(entries-start,axis=1)/5
        self.service=np.array([[m.service(q)[0] for q in range(1,21)] for m in self.modes])
        self.receiver_out=np.array([[m.service(q)[1] for q in range(1,21)] for m in self.modes],dtype=int)
        self.group_service=[min(float(self.service[i].min()) for i in ids) for ids in self.indices]
        self.edge=np.zeros((self.n,self.n))
        for g in range(self.n):
            for h in range(g):
                self.edge[g,h]=self.edge[h,g]=min(float(self.move[np.ix_(self.indices[g],self.indices[h])].min()),float(self.move[np.ix_(self.indices[h],self.indices[g])].min()))
        self.expanded=0;self.tree_cache={}

    def tree(self,mask):
        if mask in self.tree_cache:return self.tree_cache[mask]
        todo=[g for g in range(self.n) if mask>>g&1]
        if not todo:return 0.
        used=[todo.pop()];total=0.
        while todo:
            cost,j=min((self.edge[i,j],j) for i in used for j in todo)
            total+=cost;used.append(j);todo.remove(j)
        self.tree_cache[mask]=total
        return total

    def lower(self,mask,last):
        if not mask:return 0.
        groups=[g for g in range(self.n) if mask>>g&1]
        incoming=self.first if last<0 else self.move[last]
        return sum(self.group_service[g] for g in groups)+self.tree(mask)+min(float(incoming[i]) for g in groups for i in self.indices[g])

    def transitions(self,mask,last,q):
        incoming=self.first if last<0 else self.move[last]
        for g in range(self.n):
            if mask>>g&1:
                for i in self.indices[g]:
                    yield mask^(1<<g),i,int(self.receiver_out[i,q-1]),float(incoming[i]+self.service[i,q-1])

    def fixed_order(self,order,forced_first=None):
        states={(-1,self.receiver):(0.,())}
        for k,g in enumerate(order):
            nxt={}
            for (last,q),(cost,path) in states.items():
                incoming=self.first if last<0 else self.move[last]
                for i in ([forced_first] if k==0 and forced_first is not None else self.indices[g]):
                    q2=int(self.receiver_out[i,q-1]);v=cost+float(incoming[i]+self.service[i,q-1]);key=i,q2
                    if key not in nxt or v<nxt[key][0]:nxt[key]=(v,path+(i,))
            states=nxt
        return min(states.values(),key=lambda x:x[0])

    def solve(self,reference_first,reference_order,beam_width=64):
        original=self.fixed_order(reference_order,reference_first)
        best=original;full=(1<<self.n)-1;lower=self.lower(full,-1)
        if self.n<=7:
            @lru_cache(None)
            def dp(mask,last,q):
                if not mask:return 0.,()
                answer=(math.inf,())
                for left,i,q2,cost in self.transitions(mask,last,q):
                    tail,path=dp(left,i,q2);self.expanded+=1
                    if cost+tail<answer[0]:answer=cost+tail,(i,)+path
                return answer
            best=dp(full,-1,self.receiver);lower=best[0];exact=True
        else:
            # A fixed-width search is approximate even with admissible ranking.
            states={(full,-1,self.receiver):(0.,())}
            for depth in range(self.n):
                nxt={}
                for (mask,last,q),(cost,path) in states.items():
                    for left,i,q2,step in self.transitions(mask,last,q):
                        self.expanded+=1;value=cost+step;key=left,i,q2
                        if value+self.lower(left,i)>=best[0]-1e-9:continue
                        if key not in nxt or value<nxt[key][0]:nxt[key]=value,path+(i,)
                if not nxt:break
                if depth==self.n-1:
                    trial=min(nxt.values(),key=lambda x:x[0])
                    if trial[0]<best[0]:best=trial
                    break
                states=dict(sorted(nxt.items(),key=lambda item:item[1][0]+self.lower(item[0][0],item[0][1]))[:beam_width])
            exact=False
        assert best[0]<=original[0]+1e-6
        assert lower<=best[0]+1e-6
        return best[1],dict(reference_s=original[0],selected_s=best[0],lower_s=lower,gap_s=max(0,best[0]-lower),exact_catalog=exact,expanded=self.expanded,groups=self.n,modes=len(self.modes),scope='finite frozen service modes; not complete online time bound')
