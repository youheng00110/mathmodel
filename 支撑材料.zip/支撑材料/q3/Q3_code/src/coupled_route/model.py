"""Frozen service-mode routing surrogate, not the original Bayes-optimal SSP.

A mode has a first action, expected internal cost and a distribution of exits.
Transitions use E[distance(exit,next entry)], not distance(E[exit],next entry).
Mode tails condition only on observation bins and failed clears. The route
order is fixed inside this surrogate; actual feedback triggers a new solve.
"""
from dataclasses import dataclass
import math
import numpy as np
from solver.planner import Job
from solver.protocol import scan_channel_order
from solver.official_physics import movement_us

@dataclass
class Mode:
    group: int
    job: Job
    internal_s: float
    exits: np.ndarray
    weights: np.ndarray

    def service(self,receiver):
        if self.job.kind=='scan':
            order=scan_channel_order(self.job.scan_channels,receiver)
            return self.internal_s+5*len(order)+max(0,len(order)-1)+int(bool(order) and order[0]!=receiver),order[-1] if order else receiver
        if self.job.kind=='measure':return self.internal_s+5+int(receiver!=self.job.channel),self.job.channel
        return self.internal_s,receiver


def clear_tail(points,weights,start,forced=None):
    """Complete finite greedy clearance policy; success exits, failure continues.

    This is a constructive expected cost, not a lower bound. All remaining
    particles share each attempted point; no clairvoyant action selection.
    """
    mass=float(weights.sum());live=np.array(weights,dtype=float)/mass
    centres=np.unique(np.round(points/5)*5,axis=0)
    if forced is not None:centres=np.vstack([np.asarray(forced),centres])
    covers=np.linalg.norm(centres[:,None,:]-points[None,:,:],axis=2)<=20
    position=tuple(start);cost=0.;exits=[];prob=[]
    for k in range(len(centres)+1):
        remaining=float(live.sum())
        if remaining<1e-12:break
        hit=covers@live
        if k==0 and forced is not None:i=0
        else:
            rank=hit/(np.linalg.norm(centres-position,axis=1)/5+3)
            i=int(np.argmax(rank))
            if hit[i]<=0:raise ValueError('Incomplete finite clearance policy')
        p=tuple(centres[i]);cost+=remaining*(movement_us(position,p)/1e6+3)+2*float(hit[i])
        if hit[i]>0:exits.append(p);prob.append(float(hit[i]))
        live[covers[i]]=0;position=p
    if live.sum()>1e-10:raise ValueError('Finite tail exhausted before clearance')
    return cost,np.array(exits),np.array(prob)


def target_mode(group,job,cloud):
    weights=cloud.weights/float(cloud.weights.sum())
    if job.kind=='clear':
        cost,exits,prob=clear_tail(cloud.points,weights,job.point,forced=job.point)
        return Mode(group,job,cost,exits,prob)
    p=job.point;d=np.linalg.norm(cloud.points-p,axis=1)
    visible=np.clip((cloud.high-d)/np.maximum(1e-9,cloud.high-cloud.low),0,1)
    angle=np.degrees(np.arctan2(cloud.points[:,1]-p[1],cloud.points[:,0]-p[0]))
    mean,sigma=cloud.prediction(p);branches={}
    for offset,w in ((-math.sqrt(3),1/6),(0,2/3),(math.sqrt(3),1/6)):
        observed=np.round((angle+np.clip(mean+offset*sigma,-1,1))*100)/100%360
        bins=np.floor(observed/.5).astype(int);bins[d<=5]=-2
        for bucket in np.unique(bins):
            branches.setdefault(int(bucket),np.zeros(len(d)))[:] += weights*visible*w*(bins==bucket)
    branches[-1]=weights*(1-visible)
    cost=0.;exits=[];prob=[]
    for bucket,w in branches.items():
        selected=w>1e-12;mass=float(w[selected].sum())
        if mass<=1e-12:continue
        c,e,q=clear_tail(cloud.points[selected],w[selected],p,forced=p if bucket==-2 else None)
        cost+=mass*c;exits.extend(e);prob.extend(mass*q)
    prob=np.array(prob)
    if abs(float(prob.sum())-1)>1e-8:raise ValueError('Observation partition lost mass')
    return Mode(group,job,cost,np.array(exits),prob)
