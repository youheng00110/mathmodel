from formal_strategy import FormalController
from fixed_route.online import SafeRouteBaseline
from region_route.controller import ContinuousReferenceClient
from solver.parameters import effective_parameters


class Q3Strategy(SafeRouteBaseline):

    def __init__(self, client):
        self.variant = 'V3'
        self.actual = client
        self.reference = ContinuousReferenceClient(client)
        self.controller = FormalController(self.reference, progress=lambda message: None)
        self.controller.clearability_enabled = False
        self.actual.record(
            'effective_parameters', **effective_parameters(),
            anchors=self.controller.anchors,
            coverage_bound_m=self.controller.coverage_bound,
            variant=self.variant,
        )

    def run(self):
        result = super().run()
        result.update(
            strategy_version='q3-consistent-1150-safe19.7-V3',
            effective_parameters=effective_parameters(), variant=self.variant,
        )
        self.actual.record('summary', summary=result)
        return result
