"""Q3 posterior quadrature under explicitly declared working priors.

Positions are uniform by area; N is uniform on 10..16; channels are a uniform
N-subset; reception radii are uniform on 1000..1500.  Unique-position bearing
errors have uniform marginals on [-1,1] in the default hash model. The optional
smooth model integrates a shared unknown phase conditional on all bearings.
These are modeling assumptions,
not knowledge of the official generator.  Geometry remains the authority for
completion; a zero quadrature weight never marks a channel absent.
"""

from bisect import bisect_left
from dataclasses import dataclass
import math
import random
import time


class PosteriorUnavailable(ValueError):
    pass


class PlanningTimeout(RuntimeError):
    pass


def check_deadline(deadline):
    if deadline is not None and time.monotonic() >= deadline:
        raise PlanningTimeout("planning_time_budget")


def uniform_disk(rng, radius=1800.0):
    r, theta = radius*math.sqrt(rng.random()), 2*math.pi*rng.random()
    return r*math.cos(theta), r*math.sin(theta)


def polygon_sampler(poly):
    """Uniform area sampler of a convex polygon, via a triangle fan."""
    if len(poly) < 3:
        raise PosteriorUnavailable("Degenerate posterior polygon")
    origin, triangles, cumulative = poly[0], [], []
    total = 0.0
    for a, b in zip(poly[1:-1], poly[2:]):
        area = abs((a[0]-origin[0])*(b[1]-origin[1])
                   -(a[1]-origin[1])*(b[0]-origin[0]))/2
        if area > 0:
            total += area
            triangles.append((a, b))
            cumulative.append(total)
    if not total:
        raise PosteriorUnavailable("Zero-area posterior polygon")

    def sample(rng):
        a, b = triangles[bisect_left(cumulative, rng.random()*total)]
        r, v = math.sqrt(rng.random()), rng.random()
        return tuple((1-r)*origin[k]+r*(1-v)*a[k]+r*v*b[k] for k in (0, 1))
    return sample


def observation_kernel(belief, point, include_angle_weight=True):
    """Integrate fixed radius and rounded-bearing likelihood at a point.

    Bearing likelihood is scaled by the same positive constant per unique
    direction observation.  For a known-existing channel it cancels on
    normalization; unknown channels have no positive bearings.  Repeated
    measurements at exactly the same position count only once.
    """
    if math.hypot(*point) > 1800:
        return 0.0, 1000.0, 1000.0
    if any(math.dist(point, q) <= 20 for q in belief.failed_clears):
        return 0.0, 1000.0, 1000.0
    lower, upper, angle_weight = 1000.0, 1500.0, 1.0
    seen = {}
    for q, kind, observed in belief.observations:
        q = tuple(q)
        reading = kind, observed
        if q in seen:
            if seen[q] != reading:
                raise PosteriorUnavailable("Inconsistent repeated observation")
            continue
        seen[q] = reading
        d = math.dist(point, q)
        if kind == "no_signal":
            upper = min(upper, d)
        elif kind == "near":
            if d > 5:
                return 0.0, lower, upper
            lower = max(lower, d)
        elif kind == "direction":
            if d <= 5:
                return 0.0, lower, upper
            lower = max(lower, d)
            true_angle = math.degrees(math.atan2(point[1]-q[1], point[0]-q[0]))
            delta = (observed-true_angle+180) % 360-180
            width = max(0.0, min(1.0, delta+.005)-max(-1.0, delta-.005))
            angle_weight *= min(1.0, width/.01) if include_angle_weight else float(width>0)
        else:
            raise PosteriorUnavailable("Unknown observation type")
        if upper <= lower or not angle_weight:
            return 0.0, lower, upper
    return (upper-lower)/500*angle_weight, lower, upper


@dataclass(frozen=True)
class Particle:
    point: tuple
    radius_lower: float
    radius_upper: float
    weight: float
    phase_intervals: tuple = ()
    phase: float | None = None


@dataclass
class Cloud:
    particles: list
    evidence: float
    attempts: int
    proposal_method: str = 'uniform_spatial'
    pilot_evaluations: int = 0

    def draw(self, rng):
        if not self.particles:
            raise PosteriorUnavailable("No supported particles")
        p = rng.choices(self.particles, weights=[p.weight for p in self.particles], k=1)[0]
        return p.point, p.radius_lower+rng.random()*(p.radius_upper-p.radius_lower)

    def mean(self):
        total = sum(p.weight for p in self.particles)
        if total <= 0:
            raise PosteriorUnavailable("No posterior mass")
        return tuple(sum(p.weight*p.point[k] for p in self.particles)/total for k in (0, 1))


def subset_suffix(weights):
    """Elementary symmetric sums for sampling a size-constrained subset."""
    n = len(weights)
    table = [[0.0]*(n+1) for _ in range(n+1)]
    table[n][0] = 1.0
    for i in range(n-1, -1, -1):
        table[i][0] = 1.0
        for k in range(1, n-i+1):
            table[i][k] = table[i+1][k]+weights[i]*table[i+1][k-1]
    return table


def count_distribution(known_count, unknown_evidence):
    suffix = subset_suffix(unknown_evidence)
    mass = {}
    for n in range(10, 17):
        k = n-known_count
        if 0 <= k <= len(unknown_evidence):
            # Fixed known-existing channels contribute an N-independent
            # likelihood, but the uniform N-subset prior contributes 1/C(20,N).
            mass[n] = suffix[0][k]/math.comb(20, n)/7
    total = sum(mass.values())
    if total <= 0:
        raise PosteriorUnavailable("Particle evidence cannot support N in 10..16")
    return {n: value/total for n, value in mass.items() if value > 0}, suffix


def draw_subset(channels, weights, count, suffix, rng):
    out = []
    for i, channel in enumerate(channels):
        if not count:
            break
        denominator = suffix[i][count]
        if denominator <= 0:
            raise PosteriorUnavailable("Unsupported channel subset")
        probability = weights[i]*suffix[i+1][count-1]/denominator
        if rng.random() < min(1.0, probability):
            out.append(channel)
            count -= 1
    if count:
        raise PosteriorUnavailable("Channel subset sampling underflow")
    return out


@dataclass(frozen=True)
class SampledSource:
    channel: int
    point: tuple
    radius: float
    phase: float | None = None


@dataclass(frozen=True)
class Scenario:
    sources: tuple  # Only sources still alive at the planning state.
    total_count: int  # Includes sources cleared before planning.
    noise_seed: int
    error_model: str = 'hash'


class SpatialPosterior:
    def __init__(self, particles=256, seed=20260911, error_model='hash'):
        if error_model not in ('hash','smooth'):
            raise ValueError('Unsupported predictive error model')
        self.particles, self.seed = particles, seed
        self.error_model = error_model
        self.cache = {}

    def cloud(self, belief, deadline=None):
        signature = (belief.state, tuple(belief.observations), tuple(belief.failed_clears))
        cached = self.cache.get(belief.channel)
        if cached and cached[0] == signature:
            return cached[1]
        rng = random.Random(self.seed+1000003*belief.channel
                            +9176*len(belief.observations)+37*len(belief.failed_clears))
        # For two or more bearings, sample in phase/angle coordinates first.
        # This targets the thin feasible set rather than hoping that a broad
        # spatial polygon sample happens to satisfy the correlated readings.
        guided=None
        guided_attempts=0
        if self.error_model=='smooth' and belief.state=='found':
            from .guided_posterior import GuidedBearingProposal,unique_directions
            if len(unique_directions(belief))>=2:
                try:
                    guided=GuidedBearingProposal(belief,deadline)
                except ValueError:
                    guided=None
        if guided is not None:
            particles=[]
            attempts=self.particles*8
            guided_attempts=attempts
            for i in range(attempts):
                if i%16==0: check_deadline(deadline)
                proposed=guided.draw(rng)
                if proposed is None: continue
                point,phase,importance=proposed
                weight,lower,upper=observation_kernel(belief,point,False)
                if weight>0:
                    particles.append(Particle(point,lower,upper,weight*importance,phase=phase))
            if particles:
                cloud=Cloud(particles,sum(p.weight for p in particles)/attempts,attempts,
                            'phase_two_bearings_importance',guided.evaluations)
                self.cache[belief.channel]=signature,cloud
                return cloud
            # Do not combine differently normalized proposal weights. If no
            # guided proposal survived, use the old spatial scheme on its own.
        sample = uniform_disk if belief.state == "unknown" else polygon_sampler(belief.polygon)
        evidence_scale = 1.0
        proposal_name = 'uniform_spatial_after_guided_depletion' if guided else 'uniform_spatial'
        if getattr(belief, 'cells', ()):
            from .triangle_map import triangle_sampler
            sample, proposal_area = triangle_sampler(belief.cells)
            # Unknown-channel weights must remain evidence under the original
            # uniform disk prior, not likelihood conditional on a reduced map.
            if belief.state == 'unknown':
                evidence_scale = proposal_area/(math.pi*1800**2)
            proposal_name = 'uniform_triangle_support'
        particles, weight_sum = [], 0.0
        # Fixed proposal count, not stopping on a chosen number of successes:
        # weights remain an ordinary fixed-size importance quadrature.
        attempts = self.particles*(8 if self.error_model=='smooth' and belief.state=='found' else 1)
        for i in range(attempts):
            if i % 32 == 0:
                check_deadline(deadline)
            point = sample(rng)
            weight, lower, upper = observation_kernel(belief, point,self.error_model=='hash')
            phases = ()
            if weight and self.error_model=='smooth':
                from .smooth_error import compatible_phases, TAU
                phases = compatible_phases(belief,point)
                weight *= sum(b-a for a,b in phases)/TAU
            weight_sum += weight
            if weight > 0:
                particles.append(Particle(point, lower, upper, weight,phases))
        cloud = Cloud(particles, evidence_scale*weight_sum/attempts, attempts+guided_attempts,
                      proposal_name,
                      guided.evaluations if guided else 0)
        if belief.state == "found" and not particles:
            raise PosteriorUnavailable(f"Channel {belief.channel}: particle depletion")
        self.cache[belief.channel] = signature, cloud
        return cloud

    def scenarios(self, beliefs, count, sequence=0, deadline=None):
        known = [c for c, b in beliefs.items() if b.state in ("found", "cleared")]
        found = [c for c, b in beliefs.items() if b.state == "found"]
        unknown = [c for c, b in beliefs.items() if b.state == "unknown"]
        clouds = {c: self.cloud(beliefs[c], deadline) for c in found+unknown}
        weights = [clouds[c].evidence for c in unknown]
        probabilities, suffix = count_distribution(len(known), weights)
        rng = random.Random(self.seed+104729*sequence)
        samples = []
        for _ in range(count):
            check_deadline(deadline)
            total = rng.choices(list(probabilities), weights=list(probabilities.values()), k=1)[0]
            included = draw_subset(unknown, weights, total-len(known), suffix, rng)
            sources = []
            for c in found+included:
                if self.error_model=='smooth':
                    from .smooth_error import draw_phase
                    p = rng.choices(clouds[c].particles,weights=[p.weight for p in clouds[c].particles],k=1)[0]
                    radius = p.radius_lower+rng.random()*(p.radius_upper-p.radius_lower)
                    phase=p.phase if p.phase is not None else draw_phase(p.phase_intervals,rng)
                    sources.append(SampledSource(c,p.point,radius,phase))
                else:
                    point, radius = clouds[c].draw(rng)
                    sources.append(SampledSource(c, point, radius))
            samples.append(Scenario(tuple(sources), total, rng.getrandbits(64),self.error_model))
        info = dict(count_posterior={str(n): p for n, p in probabilities.items()},
                    known_targets=len(known), unknown_channels=len(unknown),
                    zero_mass_unknown_channels=[c for c in unknown if not clouds[c].particles],
                    particle_counts={str(c): len(cloud.particles) for c, cloud in clouds.items()},
                    effective_sample_sizes={str(c): (sum(p.weight for p in cloud.particles)**2/
                        sum(p.weight*p.weight for p in cloud.particles) if cloud.particles else 0.0)
                        for c,cloud in clouds.items()},
                    prior="uniform_area_disk; uniform_N_10_16; uniform_channel_subset; uniform_radius_1000_1500; "+
                          ('local_smooth_error_uniform_unknown_phase' if self.error_model=='smooth' else 'fixed_uniform_location_error'),
                    predictive_error_model=self.error_model,
                    particle_attempts={str(c): cloud.attempts for c,cloud in clouds.items()},
                    proposal_methods={str(c):cloud.proposal_method for c,cloud in clouds.items()},
                    proposal_pilot_evaluations={str(c):cloud.pilot_evaluations for c,cloud in clouds.items()},
                    posterior_is_numerical_approximation=True)
        return samples, clouds, info
