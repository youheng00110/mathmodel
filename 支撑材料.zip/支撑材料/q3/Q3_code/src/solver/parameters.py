"""One source for Q3 planning geometry; physical simulator rules stay separate."""
COVERAGE_RADIUS_M = 1150.0
CLEAR_PHYSICAL_RADIUS_M = 20.0
CLEAR_SAFETY_MARGIN_M = 0.3
CLEAR_SAFE_RADIUS_M = CLEAR_PHYSICAL_RADIUS_M - CLEAR_SAFETY_MARGIN_M
CERTIFICATE_FLOAT_TOL_M = 1e-9

def effective_parameters():
    return dict(coverage_radius_m=COVERAGE_RADIUS_M,
                clear_physical_radius_m=CLEAR_PHYSICAL_RADIUS_M,
                clear_safety_margin_m=CLEAR_SAFETY_MARGIN_M,
                clear_safe_radius_m=CLEAR_SAFE_RADIUS_M,
                certificate_float_tolerance_m=CERTIFICATE_FLOAT_TOL_M,
                source_domain_m=1800, objective="episode_mean_T_over_N",
                clear_gap_scope="conservative_polygon_continuous_position",
                sampled_gap_is_safety_certificate=False)
