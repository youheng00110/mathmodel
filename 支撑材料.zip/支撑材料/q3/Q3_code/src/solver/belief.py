from solver.parameters import CLEAR_SAFE_RADIUS_M
"""Online state built exclusively from accepted observations."""

from dataclasses import dataclass, field

from .geometry import bearing_clip, clip_disk_outer, disk_polygon, enclosing_circle


@dataclass
class Belief:
    channel: int
    state: str = "unknown"
    polygon: list = field(default_factory=disk_polygon)
    observations: list = field(default_factory=list)
    negatives: list = field(default_factory=list)
    failed_clears: list = field(default_factory=list)
    covered: set = field(default_factory=set)
    revision: int = 0
    misses: int = 0
    stagnant: int = 0
    local_measurements: int = 0
    radius: float = 1800.0
    center: tuple = (0.0, 0.0)
    sensing_cache: list | None = None
    fallback_cache: list | None = None
    # Ordered physical events per channel, including successful clears. Needed
    # by the joint official-seed posterior; geometric summaries are insufficient.
    physical_history: list = field(default_factory=list)

    def observe(self, position, response, anchor_index=None):
        kind = response["measure_result"]
        self.physical_history.append(('measure', tuple(position), kind, response.get('svd_deg')))
        self.observations.append((tuple(position), kind, response.get("svd_deg")))
        if anchor_index is not None:
            self.covered.add(anchor_index)
        if kind == "no_signal":
            self.negatives.append(tuple(position))
            if self.state == "found":
                self.misses += 1
                self.local_measurements += 1
                self.sensing_cache = None
            return kind
        if kind not in ("direction", "near"):
            raise ValueError(f"Unknown measure_result: {kind}")
        self.state = "found"
        old_radius = self.radius
        if kind == "near":
            poly = clip_disk_outer(self.polygon, position, 5)
        else:
            poly = bearing_clip(self.polygon, position, response["svd_deg"])
            poly = clip_disk_outer(poly, position, 1500)
        if not poly:
            raise ValueError(f"Channel {self.channel}: inconsistent bearing region; refusing false clearance certificate")
        self.polygon = poly
        self.center, self.radius = enclosing_circle(poly)
        self.stagnant = self.stagnant + 1 if self.radius > .85*old_radius else 0
        self.misses = 0
        self.local_measurements += 1
        self.revision += 1
        self.sensing_cache = None
        self.fallback_cache = None
        return kind

    def clear_feedback(self, point, response, guaranteed=False):
        self.physical_history.append(('clear', tuple(point), response['clear_result'], None))
        if response["clear_result"] == "success":
            self.state = "cleared"
        else:
            self.failed_clears.append(tuple(point))
            if guaranteed:
                raise ValueError(f"Channel {self.channel}: a geometrically guaranteed clearance failed; check simulator/model rules")

    @property
    def clear_gap(self):
        """Conservative continuous-region radius excess, not a grid certificate."""
        return max(0.0, self.radius-CLEAR_SAFE_RADIUS_M)

    def certificate(self):
        return {"channel": self.channel, "state": self.state, "coverage_nodes": sorted(self.covered),
                "bearing_observations": sum(o[1] == "direction" for o in self.observations),
                "region_radius_m": self.radius, "clear_gap_m": self.clear_gap, "clear_safe_radius_m": CLEAR_SAFE_RADIUS_M, "region_center": self.center,
                "failed_clears": len(self.failed_clears)}
