from solver.parameters import COVERAGE_RADIUS_M
"""Conservative convex geometry; all angles in radians unless named *_deg."""
from solver.parameters import CLEAR_SAFE_RADIUS_M

import math
import random

EPS_DEG = 1.005  # one-degree error plus rounding to two decimals


def distance(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def disk_polygon(center=(0.0, 0.0), radius=1800.0, sides=64):
    """Circumscribed polygon: never cuts away any point of the disk."""
    r = radius / math.cos(math.pi / sides)
    return [(center[0] + r * math.cos(2 * math.pi * (i + .5) / sides),
             center[1] + r * math.sin(2 * math.pi * (i + .5) / sides))
            for i in range(sides)]


def clip(poly, normal, offset):
    """Intersect a convex polygon with normal . x <= offset."""
    if not poly:
        return []
    out = []
    previous = poly[-1]
    old = normal[0] * previous[0] + normal[1] * previous[1] - offset
    for point in poly:
        new = normal[0] * point[0] + normal[1] * point[1] - offset
        if (new <= 0) != (old <= 0):
            t = old / (old - new)
            out.append((previous[0] + t * (point[0] - previous[0]),
                        previous[1] + t * (point[1] - previous[1])))
        if new <= 0:
            out.append(point)
        previous, old = point, new
    clean = []
    for point in out:
        if not clean or distance(point, clean[-1]) > 1e-8:
            clean.append(point)
    if len(clean) > 1 and distance(clean[0], clean[-1]) < 1e-8:
        clean.pop()
    return clean


def bearing_clip(poly, position, bearing_deg, epsilon_deg=EPS_DEG):
    lower, upper = [math.radians(bearing_deg + sign * epsilon_deg) for sign in (-1, 1)]
    for normal in ((math.sin(lower), -math.cos(lower)),
                   (-math.sin(upper), math.cos(upper))):
        offset = normal[0] * position[0] + normal[1] * position[1]
        poly = clip(poly, normal, offset + 1e-7)
    return poly


def clip_disk_outer(poly, center, radius, sides=32):
    for i in range(sides):
        angle = 2 * math.pi * i / sides
        n = math.cos(angle), math.sin(angle)
        poly = clip(poly, n, n[0] * center[0] + n[1] * center[1] + radius + 1e-7)
        if not poly:
            break
    return poly


def contains(poly, point, tolerance=1e-5):
    if not poly:
        return False
    if len(poly) == 1:
        return distance(poly[0], point) <= tolerance
    if len(poly) == 2:
        return segment_distance(point, *poly) <= tolerance
    return all((b[0]-a[0]) * (point[1]-a[1]) - (b[1]-a[1]) * (point[0]-a[0])
               >= -tolerance * max(1.0, distance(a, b))
               for a, b in zip(poly, poly[1:] + poly[:1]))


def segment_distance(point, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    den = dx*dx + dy*dy
    t = max(0.0, min(1.0, ((point[0]-a[0])*dx+(point[1]-a[1])*dy)/den)) if den else 0
    return distance(point, (a[0]+t*dx, a[1]+t*dy))


def polygon_distance(poly, point):
    if contains(poly, point):
        return 0.0
    return min(segment_distance(point, a, b) for a, b in zip(poly, poly[1:]+poly[:1]))


def diameter(poly):
    if not poly:
        raise ValueError("Empty localization region")
    a, b = max(((a, b) for a in poly for b in poly), key=lambda ab: distance(*ab))
    return distance(a, b), a, b


def _pair_circle(a, b):
    return ((a[0]+b[0])/2, (a[1]+b[1])/2), distance(a, b)/2


def _triple_circle(a, b, c):
    bx, by, cx, cy = b[0]-a[0], b[1]-a[1], c[0]-a[0], c[1]-a[1]
    den = 2*(bx*cy-by*cx)
    if abs(den) < 1e-12:
        return max((_pair_circle(a, b), _pair_circle(a, c), _pair_circle(b, c)), key=lambda cr: cr[1])
    nb, nc = bx*bx+by*by, cx*cx+cy*cy
    center = (a[0]+(cy*nb-by*nc)/den, a[1]+(bx*nc-cx*nb)/den)
    return center, distance(center, a)


def enclosing_circle(poly):
    if not poly:
        raise ValueError("Empty localization region")
    points = list(poly)
    random.Random(0).shuffle(points)
    center, radius = points[0], 0.0
    for i, a in enumerate(points):
        if distance(center, a) <= radius + 1e-8:
            continue
        center, radius = a, 0.0
        for j, b in enumerate(points[:i]):
            if distance(center, b) <= radius + 1e-8:
                continue
            center, radius = _pair_circle(a, b)
            for c in points[:j]:
                if distance(center, c) > radius + 1e-8:
                    center, radius = _triple_circle(a, b, c)
    # Recompute actual coverage even after numerical roundoff.
    return center, max(distance(center, p) for p in points) + 1e-7


def clear_position(poly, current, radius=CLEAR_SAFE_RADIUS_M):
    """Closest point in intersection of vertex-centered clearance disks."""
    center, r = enclosing_circle(poly)
    if r > radius:
        return None
    def feasible(p):
        return all(distance(p, v) <= radius + 1e-7 for v in poly)
    if feasible(current):
        return current
    candidates = [center]
    for v in poly:
        d = distance(v, current)
        if d:
            p = (v[0]+radius*(current[0]-v[0])/d, v[1]+radius*(current[1]-v[1])/d)
            if feasible(p):
                candidates.append(p)
    for i, a in enumerate(poly):
        for b in poly[:i]:
            d = distance(a, b)
            if d < 1e-9 or d > 2*radius:
                continue
            mid = ((a[0]+b[0])/2, (a[1]+b[1])/2)
            h = math.sqrt(max(0, radius*radius-d*d/4))
            for sign in (-1, 1):
                p = (mid[0]+sign*h*(b[1]-a[1])/d, mid[1]-sign*h*(b[0]-a[0])/d)
                if feasible(p):
                    candidates.append(p)
    return min(candidates, key=lambda p: distance(p, current))


def coverage_nodes(problem):
    if problem == 3:
        return [(0.0, 0.0)] + [(COVERAGE_RADIUS_M*math.cos(k*math.pi/3), COVERAGE_RADIUS_M*math.sin(k*math.pi/3)) for k in range(6)]
    if problem != 4:
        raise ValueError("Problem must be 3 or 4")
    # A circumscribed outer dodecagon, staggered inner dodecagon, and center.
    # Triangulate the annulus with (O_k,O_{k+1},I_k) and
    # (I_{k-1},I_k,O_k), then the inner polygon with the center.
    # Outer apothem >1800; every edge <1000 (largest about 978m).
    # Thus any target is in the convex hull of three vertices <=1000 away:
    # at least one vertex lies in every closed emitting half-plane.
    inner = [(950*math.cos((k+.5)*math.pi/6), 950*math.sin((k+.5)*math.pi/6)) for k in range(12)]
    outer = [(1865*math.cos(k*math.pi/6), 1865*math.sin(k*math.pi/6)) for k in range(12)]
    return [(0.0, 0.0)] + inner + outer


def fallback_grid(poly, step=25.0):
    """Superset of all grid cells meeting P; nearest center <= step/sqrt(2)."""
    xmin, xmax = min(p[0] for p in poly), max(p[0] for p in poly)
    ymin, ymax = min(p[1] for p in poly), max(p[1] for p in poly)
    margin = step/math.sqrt(2)+1e-6
    return [(i*step, j*step)
            for i in range(math.floor(xmin/step)-1, math.ceil(xmax/step)+2)
            for j in range(math.floor(ymin/step)-1, math.ceil(ymax/step)+2)
            if polygon_distance(poly, (i*step, j*step)) <= margin]
