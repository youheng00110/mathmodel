"""Online bearing localization and jammer clearance (Python standard library)."""
