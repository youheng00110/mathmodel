"""Numerical clearance optimization inside feedback-dependent route policies."""

from .convex_clearance import optimize_clearance_points
from .joint_route_optimizer import optimize_joint_route
from .route_sensing import route_plan


def mathematical_route_proposals(state, coverage_gap=12, deadline=None):
    # Order generation is still a frozen subproblem. Its order certificate
    # must not be reused after continuously changing the point coordinates.
    route, order_info = route_plan(state,coverage_gap,refine=False,deadline=deadline)
    forced = (any(b.state == 'unknown' for b in state.beliefs.values())
              and state.since_scan >= coverage_gap)
    refined, joint_info = optimize_joint_route(
        route,state.beliefs,state.position,state.receiver,forced_scan=forced,
        node_limit=2000,deadline=deadline)
    position_info = joint_info['initial_convex_position_optimization']
    return refined,dict(order_before_position_optimization=order_info,
                        convex_position_optimization=position_info,
                        joint_route_optimization=joint_info,
                        joint_order_position_optimality_certified=False,
                        full_feedback_global_optimality_certified=False)


def convex_route_tail_job(state, coverage_gap=12):
    # Fixed iteration limits preserve the same rule for identical observable
    # histories. No hidden target data and no wall-clock-dependent tail choice.
    route,_ = route_plan(state,coverage_gap,exact_limit=4,passes=1,refine=False)
    refined,_ = optimize_clearance_points(route,state.beliefs,state.position,iterations=8)
    return refined[0]
