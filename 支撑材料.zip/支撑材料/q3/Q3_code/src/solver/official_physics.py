"""Port of math identified in the supplied 2026-09-10 Windows executable.

Provenance: alignment/official_20260910. Requires the actual scene noise seed;
the previous smooth sine field is not interchangeable with this model.
"""

from functools import lru_cache
import hashlib
import math


def round_away(value):
    n = math.trunc(value)
    if value-n >= .5:
        return n+1
    if value-n <= -.5:
        return n-1
    return n


def distance(a, b):
    # Go amd64 math.archHypot evaluation order (not Python's n-dimensional
    # correctly rounded hypot implementation).
    x, y = sorted((abs(a[0]-b[0]), abs(a[1]-b[1])), reverse=True)
    if x == 0:
        return 0.0
    ratio = y/x
    return x*math.sqrt(1.0+ratio*ratio)


def movement_us(a, b):
    # Official moveTo multiplies by 1e12, divides by speed in micrometers/s,
    # rounds movement separately, then adds integral service microseconds.
    return round_away(distance(a,b)*1e12/5000000)


@lru_cache(maxsize=8192)
def grid(seed, channel, ix, iy):
    key = f'{seed}:{channel}:{ix}:{iy}'.encode('ascii')
    u = int.from_bytes(hashlib.blake2b(key, digest_size=8).digest(), 'big')
    # Match Go amd64 uint64->float64 conversion, including the high-bit path.
    converted = float(u) if u < 1 << 63 else float((u >> 1) | (u & 1))*2
    return (converted/18446744073709551616.0)*2-1


def error_degrees(seed, channel, point):
    x, y = point[0]/150.0, point[1]/150.0
    ix, iy = math.floor(x), math.floor(y)
    u, v = max(0.,min(1.,x-ix)), max(0.,min(1.,y-iy))
    u, v = (3.-(u+u))*(u*u), (3.-(v+v))*(v*v)
    a,b,c,d = (grid(seed,channel,ix,iy),grid(seed,channel,ix+1,iy),
               grid(seed,channel,ix,iy+1),grid(seed,channel,ix+1,iy+1))
    bottom,top = a+(b-a)*u, c+(d-c)*u
    return bottom+(top-bottom)*v


def quantize_bearing(true_degrees, error):
    h = round_away((true_degrees+error)*100.)
    h = max(math.ceil((true_degrees-1.)*100.),
            min(math.floor((true_degrees+1.)*100.),h))
    return (h % 36000)/100.


def bearing(seed, channel, source, point):
    # Preserve multiplication/division order found in the executable.
    angle = (math.atan2(source[1]-point[1],source[0]-point[0])*180./math.pi)%360.
    return quantize_bearing(angle,error_degrees(seed,channel,point))


def directional_visible(source, point, heading_radians, heading_microdegrees=None):
    if source == point:
        return True
    angle=(math.atan2(point[1]-source[1],point[0]-source[0])*180./math.pi)%360.
    heading=(heading_microdegrees/1000000. if heading_microdegrees is not None
             else heading_radians*180./math.pi)
    return abs(math.remainder(angle-heading,360.)) <= 90.
