"""Importance proposals in phase and two measured-angle coordinates.

The pilot only shapes a proposal. A positive uniform phase mixture keeps full
phase support; the exact mixture density and triangulation Jacobian correct
weights. Remaining readings are acceptance constraints, never relaxed data.
"""
import math

from .posterior import PosteriorUnavailable,check_deadline
from .smooth_error import TAU,smooth_error


def wrap_angle(value):
    return (value+180)%360-180


def unique_directions(belief):
    seen={}
    directions=[]
    for point,kind,angle in belief.observations:
        point=tuple(point)
        if point in seen:
            if seen[point]!=(kind,angle):
                raise PosteriorUnavailable('Inconsistent repeated observation')
            continue
        seen[point]=(kind,angle)
        if kind=='direction': directions.append((point,angle))
    return directions


def triangulate(first,second,phase,offsets=(0.0,0.0)):
    """Return point and |d(theta1,theta2)/d(x,y)| in radians^2/m^2."""
    (p,a),(q,b)=first,second
    a=math.radians(a-smooth_error(p,phase)+offsets[0])
    b=math.radians(b-smooth_error(q,phase)+offsets[1])
    u,v=(math.cos(a),math.sin(a)),(math.cos(b),math.sin(b))
    determinant=u[0]*v[1]-u[1]*v[0]
    if abs(determinant)<1e-12: return None
    delta=(q[0]-p[0],q[1]-p[1])
    t=(delta[0]*v[1]-delta[1]*v[0])/determinant
    s=(delta[0]*u[1]-delta[1]*u[0])/determinant
    if t<=0 or s<=0: return None
    return (p[0]+t*u[0],p[1]+t*u[1]),abs(determinant)/(t*s)


def bearing_gradient(target,point):
    dx,dy=target[0]-point[0],target[1]-point[1]
    squared=dx*dx+dy*dy
    return (-dy/squared,dx/squared) if squared>1e-16 else None


def reproduces_directions(directions,target,phase):
    for point,angle in directions:
        predicted=round((math.degrees(math.atan2(target[1]-point[1],target[0]-point[0]))
                         +smooth_error(point,phase))%360,2)%360
        if abs(wrap_angle(predicted-angle))>1e-8: return False
    return True


class PhaseMixture:
    """Circular uniform windows plus a uniform full-support component."""
    def __init__(self,windows=(),uniform_weight=.1):
        if not 0<uniform_weight<=1:
            raise ValueError('Phase proposal must retain positive uniform support')
        if any(width<=0 or width>math.pi or weight<=0 for _,width,weight in windows):
            raise ValueError('Invalid phase proposal window')
        total=sum(weight for _,_,weight in windows)
        self.windows=tuple((center%TAU,width,weight/total) for center,width,weight in windows)
        self.uniform_weight=uniform_weight if self.windows else 1.0

    def density(self,phase):
        return self.uniform_weight/TAU+(1-self.uniform_weight)*sum(
            weight/(2*width) for center,width,weight in self.windows
            if abs((phase-center+math.pi)%TAU-math.pi)<=width)

    def draw(self,rng):
        if rng.random()<self.uniform_weight:
            phase=rng.random()*TAU
        else:
            center,width,_=rng.choices(self.windows,weights=[w[2] for w in self.windows],k=1)[0]
            phase=(center+rng.uniform(-width,width))%TAU
        return phase,self.density(phase)


class GuidedBearingProposal:
    def __init__(self,belief,deadline=None,pilot_points=64):
        self.directions=unique_directions(belief)
        if len(self.directions)<2:
            raise ValueError('Two distinct bearing positions required')
        pairs=[(a,b) for i,a in enumerate(self.directions) for b in self.directions[:i]
               if math.dist(a[0],b[0])>1e-6]
        if not pairs: raise ValueError('No separated bearing positions')
        self.first,self.second=max(pairs,key=lambda pair:abs(math.sin(math.radians(pair[0][1]-pair[1][1]))))
        self.evaluations=0

        def loss(phase):
            check_deadline(deadline)
            self.evaluations+=1
            value=triangulate(self.first,self.second,phase)
            if value is None: return math.inf
            target,_=value
            grad1=bearing_gradient(target,self.first[0])
            grad2=bearing_gradient(target,self.second[0])
            if grad1 is None or grad2 is None: return math.inf
            determinant=grad1[0]*grad2[1]-grad1[1]*grad2[0]
            if abs(determinant)<1e-20: return math.inf
            score=(max(0,math.hypot(*target)-1800)/20)**2
            for point,observed in self.directions:
                grad=bearing_gradient(target,point)
                if grad is None: return math.inf
                # Quantization in the first two readings also moves target.
                # Propagate it to set a sensible pilot scale, not a likelihood.
                c1=(grad[0]*grad2[1]-grad[1]*grad2[0])/determinant
                c2=(-grad[0]*grad1[1]+grad[1]*grad1[0])/determinant
                scale=.005*(1+abs(c1)+abs(c2))
                predicted=math.degrees(math.atan2(target[1]-point[1],target[0]-point[0]))+smooth_error(point,phase)
                score+=(wrap_angle(predicted-observed)/scale)**2
                score+=(max(0,math.dist(target,point)-1500)/20)**2
            return score

        self.phase_proposal=PhaseMixture()
        if len(self.directions)>2:
            step=TAU/pilot_points
            values=[loss(i*step) for i in range(pilot_points)]
            minima=[i for i,v in enumerate(values) if math.isfinite(v)
                    and v<=values[(i-1)%pilot_points] and v<=values[(i+1)%pilot_points]]
            if not minima:
                minima=sorted((i for i,v in enumerate(values) if math.isfinite(v)),key=lambda i:values[i])[:1]
            windows=[]
            for index in sorted(minima,key=lambda i:values[i])[:6]:
                left,right=(index-1)*step,(index+1)*step
                ratio=(math.sqrt(5)-1)/2
                x1,x2=right-ratio*(right-left),left+ratio*(right-left)
                f1,f2=loss(x1),loss(x2)
                for _ in range(28):
                    if f1<f2:
                        right,x2,f2=x2,x1,f1
                        x1=right-ratio*(right-left);f1=loss(x1)
                    else:
                        left,x1,f1=x1,x2,f2
                        x2=left+ratio*(right-left);f2=loss(x2)
                center=(left+right)/2
                delta=1e-4
                curvature=(loss(center+delta)+loss(center-delta)-2*loss(center))/(delta*delta)
                width=min(step,max(1e-5,2/math.sqrt(max(1.0,curvature)))) if math.isfinite(curvature) else step
                windows.extend(((center,width,.45),(center,min(math.pi,4*width),.35),(center,step,.20)))
            self.phase_proposal=PhaseMixture(windows)

    def draw(self,rng):
        phase,density=self.phase_proposal.draw(rng)
        offsets=(rng.uniform(-.005,.005),rng.uniform(-.005,.005))
        value=triangulate(self.first,self.second,phase,offsets)
        if value is None: return None
        point,jacobian=value
        if not reproduces_directions(self.directions,point,phase): return None
        # Constants common to this known-existing channel cancel: the angle
        # bin width squared, uniform position density and uniform phase prior.
        return point,phase,1/(density*jacobian)
