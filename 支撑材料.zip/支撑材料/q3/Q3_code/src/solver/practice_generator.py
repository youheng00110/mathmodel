"""Q3 practice-gen-v1 port of the supplied simulator, not a formal-data model.

Source values are generated in integer micrometers. Hidden generator/noise seeds
belong to the environment and must never be passed to an online controller.
"""
import hashlib
import hmac
import math
import re
from .local_simulator import Source
from .official_physics import round_away

GENERATOR_VERSION = 'practice-gen-v1'
GENERATOR_RULES_VERSION = 'practice-gen-rules-v1'
TARGET_AREA_RADIUS_UM = 1800000000
JAMMER_MAX_RADIUS_UM = 1770000000
EXE_SHA256 = '110542502401761b81f701ca1a866092e38d4ac290fa025bf18aed73ff8e9628'


def parse_seed(value):
    if isinstance(value, bytes) and len(value) == 32:
        return value
    if isinstance(value, str) and re.fullmatch(r'[0-9a-fA-F]{64}', value):
        return bytes.fromhex(value)
    raise ValueError('Practice generator seed must be exactly 32 bytes / 64 hex digits')


def seed_for_case(index):
    """Our batch-index mapping, NOT the official app's entropy/seed selection."""
    if type(index) is not int:
        raise ValueError('Case index must be an integer')
    return hashlib.sha256(f'mathmodel-practice-case-index-v1:{index}'.encode()).digest()


class CounterSource:
    def __init__(self, seed):
        self.seed = parse_seed(seed)
        self.counters = {}

    def next(self, label):
        counter = self.counters.get(label, 0)
        if counter >= 2**64-1:
            raise OverflowError('Practice per-label counter exhausted')
        message = b'practice-case-v1\0' + label.encode('utf-8') + b'\0' + counter.to_bytes(8, 'big')
        self.counters[label] = counter + 1
        return int.from_bytes(hmac.digest(self.seed, message, 'sha256')[:8], 'big')

    def uint_n(self, label, n):
        if type(n) is not int or not 0 < n <= 2**63:
            raise ValueError('n must be in 1..2**63')
        threshold = (2**64-n) % n
        while True:
            value = self.next(label)
            if value >= threshold:
                return value % n

    def shuffle(self, label, items):
        for i in range(len(items)-1, 0, -1):
            j = self.uint_n(label, i+1)
            items[i], items[j] = items[j], items[i]


# Exact binary64 coefficients and evaluation order of the bundled Go Sincos.
# Only the generator domain [0, 2*pi] is supported, avoiding a libm substitution.
_SIN = tuple(map(float.fromhex, ('0x1.5d8fd1fd19ccdp-33', '-0x1.ae5e5a9291f5dp-26',
    '0x1.71de3567d48a1p-19', '-0x1.a01a019bfdf03p-13', '0x1.111111110f7d0p-7', '-0x1.5555555555548p-3')))
_COS = tuple(map(float.fromhex, ('-0x1.8fa49a0861a9bp-37', '0x1.1ee9d7b4e3f05p-29',
    '-0x1.27e4f7eac4bc6p-22', '0x1.a01a019c844f5p-16', '-0x1.6c16c16c14f91p-10', '0x1.555555555554bp-5')))
_FOUR_OVER_PI = float.fromhex('0x1.45f306dc9c883p+0')
_DP = tuple(map(float.fromhex, ('0x1.921fb40000000p-1', '0x1.4442d00000000p-25', '0x1.8469898cc5170p-49')))


def practice_sincos(theta):
    if not 0 <= theta <= 2*math.pi:
        raise ValueError('Practice Sincos supports angles in [0, 2*pi] only')
    if theta == 0:
        return theta, 1.0
    j = int(_FOUR_OVER_PI*theta)
    if j & 1:
        j += 1
    y = float(j)
    z = ((theta-_DP[0]*y)-_DP[1]*y)-_DP[2]*y
    j &= 7
    zz = z*z
    sp, cp = _SIN[0], _COS[0]
    for k in range(1, 6):
        sp = sp*zz + _SIN[k]
        cp = cp*zz + _COS[k]
    sine = sp*(z*zz) + z
    cosine = (1.0-0.5*zz) + cp*(zz*zz)
    if (j & 3) == 2:
        sine, cosine = cosine, sine
    if j > 3:
        sine = -sine
    if j in (2, 4):
        cosine = -cosine
    return sine, cosine


def generate_practice(seed):
    """Return integer source truth + derived noise seed for exactly one Q3 case."""
    seed = parse_seed(seed)
    rng = CounterSource(seed)
    count = 10 + rng.uint_n('count', 7)
    channels = list(range(1, 21))
    rng.shuffle('channels', channels)
    jammers = []
    for channel in sorted(channels[:count]):
        while True:
            rho = JAMMER_MAX_RADIUS_UM * math.sqrt((rng.next(f'jammer/{channel}/radius') >> 11)*2**-53)
            theta = ((rng.next(f'jammer/{channel}/theta') >> 11)*2**-53)*(2*math.pi)
            sine, cosine = practice_sincos(theta)
            x, y = round_away(rho*cosine), round_away(rho*sine)
            if x*x + y*y <= JAMMER_MAX_RADIUS_UM**2:
                break
        radius = 1000000000 + rng.uint_n(f'jammer/{channel}/receive', 500000001)
        jammers.append(dict(channel=channel, x_um=x, y_um=y, max_receive_um=radius))
    return dict(generator_version=GENERATOR_VERSION, generator_rules_version=GENERATOR_RULES_VERSION,
                generator_seed_hex=seed.hex(), noise_seed=str(rng.next('noise-seed')), jammers=jammers)


def scene_sources(scene):
    return [Source(j['channel'], j['x_um']/1e6, j['y_um']/1e6, j['max_receive_um']/1e6)
            for j in scene['jammers']]


def interchange_scene(scene):
    return dict(schema='mathmodel-q3-scene-v1', problem=3, origin=GENERATOR_VERSION,
                noise_seed=scene['noise_seed'], generator_seed_hex=scene['generator_seed_hex'],
                sources=[dict(channel=s.channel, x=s.x, y=s.y, radius=s.radius)
                         for s in scene_sources(scene)])
