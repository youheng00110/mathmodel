"""Frozen-route variants with shared measurements and a residual-route endpoint cost.

Each variant services exactly the same selected target/coverage tasks. Route DP
is exact for that variant, not for adaptive observations or continuous placement.
"""

from .geometry import distance
from .planner import Job, exact_order, frozen_route_lower_bound, nearest_order


def select_joint_job(jobs, current, receiver, horizon, beliefs, evaluator,
                     remaining_points=(), shared=True, route_tail=True, insertion=True):
    scans = [job for job in jobs if job.kind == "scan"]
    local = [job for job in jobs if job.kind != "scan"]
    next_scan = scans[0].point if scans else None

    def rank(job):
        travel = distance(current, job.point)
        if insertion and next_scan is not None and job.kind == "clear" and job.guaranteed:
            detour = travel+distance(job.point, next_scan)-distance(current, next_scan)
            travel = min(travel, max(0.0, detour))
        return travel/5 + job.service(receiver)[0] + .25*job.future_cost

    local.sort(key=rank)
    selected = local[:max(0, horizon-len(scans))]+scans
    if not selected:
        raise ValueError("No selected task")
    selected_ids = {id(job) for job in selected}
    residual = [job.point for job in local if id(job) not in selected_ids]
    residual.extend(point for point in remaining_points
                    if not any(distance(point, scan.point) < .1 for scan in scans))

    def terminal(point):
        return min((distance(point, q)/5 for q in residual), default=0.0) if route_tail else 0.0

    variants = [(selected, "individual")]
    measures = [job for job in selected if job.kind == "measure"]
    if shared and len(measures) >= 2:
        points = [current]+[job.point for job in selected]
        points += [((a.point[0]+b.point[0])/2, (a.point[1]+b.point[1])/2)
                   for i, a in enumerate(measures) for b in measures[:i]
                   if distance(a.point, b.point) <= 400]
        for point in dict.fromkeys(tuple(p) for p in points):
            compatible = []
            for job in measures:
                score = evaluator.evaluate(beliefs[job.channel], point)
                if score and score["information_gain"] >= .10 and score["visibility_score"] >= .5:
                    compatible.append((job, score))
            if len(compatible) < 2:
                continue
            replaced = {id(job) for job, _ in compatible}
            batch = Job("batch", point, scan_channels=tuple(job.channel for job, _ in compatible),
                        future_cost=sum(score["future_cost_s"] for _, score in compatible))
            variant = [job for job in selected if id(job) not in replaced]+[batch]
            variants.append((variant, "shared"))
    outcomes = []
    for variant, name in variants:
        route, travel_service_tail = exact_order(variant, current, receiver, terminal)
        future = sum(job.future_cost for job in variant)
        outcomes.append((travel_service_tail+future, route, variant, name, travel_service_tail, future))
    objective, route, variant, name, routing, future = min(outcomes, key=lambda row: row[0])
    greedy, greedy_cost = nearest_order(variant, current, receiver)
    greedy_cost += terminal(greedy[-1].point)
    # Bounds cover ONLY executing these fixed jobs at these fixed positions.
    # Estimated future_cost and terminal scores are not executable completion
    # policies, so neither belongs in a certified route upper bound.
    frozen_lb = frozen_route_lower_bound(variant, current)
    frozen_ub = 0.0
    position, frozen_receiver = current, receiver
    for job in route:
        service, frozen_receiver = job.service(frozen_receiver)
        # An exploratory clear costs 5 s on success, not the optimistic 3 s
        # used by the ranking model.  Use the larger cost for an upper bound.
        if job.kind == "clear" and not job.guaranteed:
            service += 2
        frozen_ub += distance(position, job.point)/5 + service
        position = job.point
    frozen_gap = frozen_ub-frozen_lb
    if frozen_gap < -1e-6:
        raise ValueError("Inconsistent frozen route bounds")
    frozen_gap = max(0.0, frozen_gap)
    return route[0], dict(horizon_jobs=len(variant), selected_target_tasks=len(selected),
                         selected_route_cost_s=routing, greedy_same_jobs_cost_s=greedy_cost,
                         subproblem_exact=True, variant=name, variants_evaluated=len(variants),
                         estimated_future_cost_s=future, selection_objective_s=objective,
                         terminal_cost_s=terminal(route[-1].point),
                         frozen_task_lower_bound_s=frozen_lb,
                         frozen_task_upper_bound_s=frozen_ub,
                         frozen_task_gap_s=frozen_gap,
                         frozen_task_gap_pct=(100.0*frozen_gap/frozen_ub
                                              if frozen_ub > 1e-12 else 0.0),
                         frozen_task_optimality_certified=(frozen_gap <= 1e-6),
                         bound_scope="selected_frozen_variant_route_only",
                         bounds_include_unexpanded_tasks=False,
                         global_optimality_certified=False)
