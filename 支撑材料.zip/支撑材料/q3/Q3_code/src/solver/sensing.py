"""Discrete robust lookahead for the next bearing observation.

Scenario evaluation is a heuristic, not a continuous minimax certificate.
Only conservative geometry and full coverage provide certificates.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

import math

from .geometry import (bearing_clip, clear_position, diameter, distance,
                       enclosing_circle, fallback_grid)


def representatives(poly, failed):
    center = (sum(p[0] for p in poly)/len(poly), sum(p[1] for p in poly)/len(poly))
    raw = list(poly) + [center] + [((p[0]+center[0])/2, (p[1]+center[1])/2) for p in poly]
    if len(raw) > 13:
        raw = [raw[round(i*(len(raw)-1)/12)] for i in range(13)]
    keep = [p for p in raw if all(distance(p, q) > 20 for q in failed)]
    return keep or raw


def candidate_points(belief):
    poly = belief.polygon
    length, a, b = diameter(poly)
    if length < 1e-6:
        return [belief.center]
    u = ((b[0]-a[0])/length, (b[1]-a[1])/length)
    v = (-u[1], u[0])
    center = belief.center
    points = [center]
    lateral = sorted(set([max(12, min(600, belief.radius*f)) for f in (.25, .65, 1.0)]))
    for offset in (0.0, -.35*belief.radius, .35*belief.radius):
        for step in lateral:
            for side in (-1, 1):
                points.append((center[0]+offset*u[0]+side*step*v[0],
                               center[1]+offset*u[1]+side*step*v[1]))
    # Points on the observed side help directional sources after signal loss.
    positives = [p for p, kind, _ in belief.observations if kind in ("direction", "near")]
    for p in positives[-2:]:
        for f in (.35, .7):
            points.append((p[0]*(1-f)+center[0]*f, p[1]*(1-f)+center[1]*f))
    measured = [p for p, _, _ in belief.observations]
    out = []
    for p in points:
        if (all(distance(p, q) > .1 for q in measured)
                and all(distance(p, q) > .1 for q in out)):
            out.append(p)
    return out


def expected_visibility(belief, q, g, problem):
    d = distance(q, g)
    if d > 1500:
        return 0.0
    positives = [p for p, kind, _ in belief.observations if kind in ("direction", "near")]
    lower_r = max([1000.0] + [distance(p, g) for p in positives])
    visibility = 1.0 if d <= lower_r else max(0.0, (1500-d)/max(1, 1500-lower_r))
    if problem == 3:
        if any(distance(p, g) <= 1000 for p in belief.negatives):
            return 0.0
        return visibility
    # A small orientation grid affects scoring only, never completeness logic.
    plausible = []
    for k in range(16):
        angle = k*math.pi/8
        n = math.cos(angle), math.sin(angle)
        if any(n[0]*(p[0]-g[0])+n[1]*(p[1]-g[1]) < -1e-6 for p in positives):
            continue
        if any(distance(p, g) <= 1000 and n[0]*(p[0]-g[0])+n[1]*(p[1]-g[1]) >= 0
               for p in belief.negatives):
            continue
        plausible.append(n[0]*(q[0]-g[0])+n[1]*(q[1]-g[1]) >= 0)
    fraction = sum(plausible)/len(plausible) if plausible else .5
    return visibility*(.15+.85*fraction)


def evaluate_candidates(belief, problem):
    samples = representatives(belief.polygon, belief.failed_clears)
    outcomes = []
    for q in candidate_points(belief):
        radii, followup, visibility = [], [], []
        for g in samples:
            visibility.append(expected_visibility(belief, q, g, problem))
            if distance(g, q) <= 5:
                radii.append(0.0)
                followup.append(5.0)
                continue
            angle = math.degrees(math.atan2(g[1]-q[1], g[0]-q[0]))
            for error in (-1.005, 1.005):
                poly = bearing_clip(belief.polygon, q, angle+error)
                if poly:
                    center, radius = enclosing_circle(poly)
                    radii.append(radius)
                    followup.append(max(0, distance(q, center)-CLEAR_SAFE_RADIUS_M)/5)
        if not radii:
            continue
        worst = max(radii)
        average = sum(radii)/len(radii)
        receive = sum(visibility)/len(visibility)
        # Approximate time to reduce remaining radius; all terms measured in seconds.
        uncertainty_cost = .30*worst + .12*average + 16*math.log2(max(1.0, worst/CLEAR_SAFE_RADIUS_M))
        loss_cost = (1-receive)*(25+.30*belief.radius)
        completion_cost = sum(followup)/len(followup)
        outcomes.append((q, uncertainty_cost+loss_cost+completion_cost, worst, receive))
    return outcomes


def choose_local_action(belief, current, problem):
    point = clear_position(belief.polygon, current)
    if point is not None:
        return "clear", point, True, 0.0
    fallback = (bool(belief.failed_clears) or belief.misses >= 3
                or belief.stagnant >= 3 or belief.local_measurements >= 9)
    if not fallback:
        if belief.sensing_cache is None:
            belief.sensing_cache = evaluate_candidates(belief, problem)
        previous = [p for p, _, _ in belief.observations]
        candidates = [row for row in belief.sensing_cache if all(distance(row[0], p) > .1 for p in previous)]
        if candidates:
            q, cost, _, _ = min(candidates, key=lambda row: distance(current, row[0])/5+row[1])
            return "measure", q, False, cost
    if belief.fallback_cache is None:
        belief.fallback_cache = fallback_grid(belief.polygon)
    candidates = [p for p in belief.fallback_cache if all(distance(p, q) > .1 for q in belief.failed_clears)]
    if not candidates:
        raise ValueError(f"Channel {belief.channel}: optical covering exhausted without finding target")
    point = min(candidates, key=lambda p: distance(current, p) + .1*distance(belief.center, p))
    return "clear", point, False, 20.0
