"""Offline environment using public rules; hidden truth never enters the planner."""

from dataclasses import asdict, dataclass
import json
import math
import random
import time
from . import official_physics


@dataclass
class Source:
    channel: int
    x: float
    y: float
    radius: float
    heading: float | None = None
    phase: float = 0.0
    # Optional exact official Q4 representation, used by shared-scene audits.
    heading_microdegrees: int | None = None

    @property
    def position(self):
        return self.x, self.y


def generate_sources(seed, problem=3, count=None, mode="random"):
    rng = random.Random(seed)
    count = count if count is not None else rng.randint(10, 16)
    channels = rng.sample(range(1, 21), count)
    sources = []
    for i, channel in enumerate(channels):
        angle = rng.uniform(0, 2*math.pi)
        r = 1800*math.sqrt(rng.random())
        if mode == "edge":
            r = 1799.99
        elif mode == "cluster":
            angle = .7+rng.uniform(-.04, .04)
            r = 1300+rng.uniform(-40, 40)
        radius = 1000.0 if mode in ("edge", "minimum", "extreme") else rng.uniform(1000, 1500)
        directional = problem == 4 and (i == 0 or (i != 1 and rng.random() < .65))
        heading = (angle if mode == "edge" else rng.uniform(0, 2*math.pi)) if directional else None
        sources.append(Source(channel, r*math.cos(angle), r*math.sin(angle), radius,
                              heading, rng.uniform(-math.pi, math.pi)))
    return sources


class LocalSimulator:
    def __init__(self, sources, robot_id="offline", error_mode="smooth", real_limit=1200,
                 noise_seed=None):
        if error_mode not in ("official", "smooth", "zero", "extreme", "blocks"):
            raise ValueError("Unknown simulator error model")
        if error_mode == "official" and (type(noise_seed) is not int or not 0 <= noise_seed < 2**64):
            raise ValueError("official mode requires the scene's uint64 noise_seed")
        self.sources = {s.channel: s for s in sources}
        self.noise_seed = noise_seed
        self.robot_id, self.error_mode, self.real_limit = robot_id, error_mode, real_limit
        self.cleared = set()
        self.position, self.channel, self.virtual_us = (0.0, 0.0), 1, 0
        self.active = False
        self.finished = False
        self.started = None
        self.cache = {}

    def _response(self, accepted, **data):
        return {"accepted": accepted, "real_timestamp_ms": int(time.time()*1000),
                "virtual_time_s": self.virtual_us/1e6 if accepted else 0, **data}

    def _error(self, source, position):
        if self.error_mode == "official":
            return official_physics.error_degrees(self.noise_seed, source.channel, position)
        x, y = position
        if self.error_mode == "zero":
            return 0.0
        if self.error_mode == "extreme":
            return 1.0 if math.sin(x/37+y/53+source.phase) >= 0 else -1.0
        if self.error_mode == "blocks":
            # Fixed spatial cells, deliberately discontinuous; not new noise per call.
            return math.sin(math.floor(x/50)*12.9898+math.floor(y/50)*78.233+source.phase)
        return .6*math.sin(x/211+y/173+source.phase)+.4*math.cos(x/97-y/131+source.phase)

    def exchange(self, path, body):
        request = json.loads(body)
        required = {"arena_id", "robot_id", "request_id"}
        if path in ("/measure", "/clear"):
            required |= {"position", "channel"}
        if path not in ("/enter", "/exit", "/measure", "/clear"):
            return 404, self._response(False)
        if not required <= request.keys():
            return 400, self._response(False)
        if request.keys() != required or request["arena_id"] != "default" or request["robot_id"] != self.robot_id:
            return 200, self._response(False)
        request_id = request["request_id"]
        if not isinstance(request_id, str) or not request_id or len(request_id.encode()) > 128:
            return 400, self._response(False)
        signature = path, json.dumps(request, sort_keys=True)
        if request_id in self.cache:
            old_signature, response = self.cache[request_id]
            return (200, dict(response)) if old_signature == signature else (409, self._response(False))
        if self.finished:
            return 200, self._response(False)
        if path == "/enter":
            if self.active:
                return 200, self._response(False)
            self.active = True
            self.started = time.monotonic()
            response = self._response(True, max_virtual_duration_s=360000,
                                      max_real_duration_s=self.real_limit,
                                      remaining_real_duration_s=self.real_limit)
        elif not self.active:
            return 200, self._response(False)
        elif path == "/exit":
            self.active = False
            self.finished = True
            response = self._response(True, exit_reason="user_exit")
        else:
            if time.monotonic()-self.started >= self.real_limit or self.virtual_us >= 360000000000:
                self.finished = True
                return 200, self._response(False)
            try:
                coordinates = request["position"]
                if set(coordinates) != {"x", "y"}:
                    return 200, self._response(False)
                point = (float(coordinates["x"]), float(coordinates["y"]))
                channel = request["channel"]
                valid_channel = (isinstance(channel, (int, float)) and not isinstance(channel, bool)
                                 and channel == int(channel) and 1 <= channel <= 20)
                if not valid_channel or not all(math.isfinite(x) and abs(x) <= 2000000 for x in point):
                    return 400, self._response(False)
                channel = int(channel)
            except (TypeError, ValueError, KeyError):
                return 400, self._response(False)
            official = self.error_mode == "official"
            move_us = official_physics.movement_us(self.position, point) if official else None
            elapsed = math.dist(self.position, point)/5
            self.position = point
            source = self.sources.get(channel)
            live = source is not None and channel not in self.cleared
            dist = official_physics.distance if official else math.dist
            d = dist(point, source.position) if live else math.inf
            if path == "/clear":
                success = d <= 20
                service = 5 if success else 3
                elapsed += service
                if success:
                    self.cleared.add(channel)
                fields = {"clear_result": "success" if success else "no_target_in_range"}
            else:
                service = 5 + (channel != self.channel)
                elapsed += service
                self.channel = channel
                visible = live and d <= source.radius
                if visible and source.heading is not None:
                    visible = (official_physics.directional_visible(source.position, point, source.heading,
                                   source.heading_microdegrees)
                               if official else ((point[0]-source.x)*math.cos(source.heading)
                               +(point[1]-source.y)*math.sin(source.heading)) >= -1e-9)
                if not visible:
                    fields = {"measure_result": "no_signal"}
                elif d <= 5:
                    fields = {"measure_result": "near"}
                else:
                    bearing = math.degrees(math.atan2(source.y-point[1], source.x-point[0]))
                    fields = {"measure_result": "direction",
                              "svd_deg": (official_physics.bearing(self.noise_seed, channel, source.position, point)
                                          if official else round((bearing+self._error(source, point)) % 360, 2) % 360)}
            self.virtual_us += move_us + service*1000000 if official else round(elapsed*1e6)
            response = self._response(True, **fields)
        self.cache[request_id] = signature, dict(response)
        return 200, response

    def close(self):
        pass


def optimistic_lower_bound(sources):
    """MST on distances between clearance disks, plus unavoidable clear time."""
    if not sources:
        return 0.0
    best = [max(0, math.hypot(s.x, s.y)-20) for s in sources]
    visited = set()
    total = 0.0
    for _ in sources:
        i = min((i for i in range(len(sources)) if i not in visited), key=lambda i: best[i])
        total += best[i]
        visited.add(i)
        for j in range(len(sources)):
            if j not in visited:
                best[j] = min(best[j], max(0, math.dist(sources[i].position, sources[j].position)-40))
    return total/5+5*len(sources)


def serialize_sources(sources):
    return [asdict(s) for s in sources]
