"""Certified multi-disk clearance candidates; all geometry uses public belief.

Complete sampled feedback costs, not covering-route length alone, decide
whether to clear-search or measure. A search stops on first successful clear.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

from dataclasses import dataclass

from .geometry import distance, enclosing_circle
from .planner import Job
from .posterior import check_deadline, PlanningTimeout
from .route_sensing import optimize_order, route_plan
from .saa_rollout import local_tail_job, tail_job
from .triangle_map import split, triangulate


@dataclass
class ClearSearchJob(Job):
    search_points: tuple = ()
    cover_certified: bool = True

    def service(self, current_channel):
        # Worst case: every preceding clear fails, final clear succeeds.
        travel = sum(distance(a, b)/5 for a, b in zip(self.search_points, self.search_points[1:]))
        return travel+3*(len(self.search_points)-1)+5, current_channel


def covering_clear_job(belief, current, deadline=None, max_points=12, max_cells=192):
    if belief.state != 'found':
        return None, dict(status='not_found')
    pending = list(getattr(belief, 'cells', ()) or triangulate(belief.polygon))
    if len(pending) > max_cells:
        return None, dict(status='cover_cell_budget')
    cells, centers = [], []
    while pending:
        check_deadline(deadline)
        cell = pending.pop()
        center, radius = enclosing_circle(cell)
        if radius <= CLEAR_SAFE_RADIUS_M:
            cells.append(cell)
            centers.append(center)
        elif len(pending)+len(cells)+2 <= max_cells:
            pending.extend(split(cell))
        else:
            return None, dict(status='cover_cell_budget')
    # Candidate disks cover entire cells, not just isolated sampled points.
    probes = list(dict.fromkeys([belief.center, *centers]))
    masks = []
    for p in probes:
        check_deadline(deadline)
        masks.append({i for i, cell in enumerate(cells)
                      if all(distance(v, p) <= (CLEAR_SAFE_RADIUS_M + 1e-6) for v in cell)})
    remaining, chosen = set(range(len(cells))), []
    while remaining:
        check_deadline(deadline)
        i = max(range(len(probes)), key=lambda i: (len(masks[i] & remaining),
                                                  -distance(current, probes[i])))
        if not masks[i] & remaining or len(chosen) >= max_points:
            return None, dict(status='cover_point_budget')
        chosen.append(probes[i])
        remaining -= masks[i]
    jobs = [Job('clear', p, belief.channel, True) for p in chosen]
    route, bounds = optimize_order(jobs, current, 1, exact_limit=8, passes=1, deadline=deadline)
    points = tuple(j.point for j in route)
    job = ClearSearchJob('clear_search', points[0], belief.channel,
                         search_points=points)
    worst = distance(current, points[0])/5+job.service(1)[0]
    return job, dict(status='certified_cover', disk_count=len(points), covered_cells=len(cells),
                     worst_case_until_success_s=worst,
                     fixed_cover_point_order_exact=bounds['exact'],
                     global_optimality_certified=False)


def terminal_route(state, deadline=None):
    if any(b.state == 'unknown' for b in state.beliefs.values()):
        return None
    jobs = [local_tail_job(b, state.position) for b in state.beliefs.values() if b.state == 'found']
    if not jobs or not all(j.kind == 'clear' and j.guaranteed for j in jobs):
        return None
    # Held-Karp over all remaining reliable clear locations (at most 16).
    # If the deadline interrupts, caller retains the old incumbent; never call
    # an unfinished DP exact. Position choice itself is still geometric.
    return optimize_order(jobs, state.position, state.receiver,
                          exact_limit=16, deadline=deadline)


def triangle_proposals(state, coverage_gap, deadline=None, enable_clear=True):
    terminal = terminal_route(state, deadline)
    if terminal is not None:
        route, info = terminal
        return route[:3], dict(terminal_fixed_points=info, full_problem_optimal=False)
    proposals, covers = [], []
    if enable_clear:
        # Work on the smallest local regions first; these are the most likely
        # to admit a short certified covering sequence within the action cap.
        found = sorted((b for b in state.beliefs.values() if b.state == 'found' and b.radius > CLEAR_SAFE_RADIUS_M),
                       key=lambda b: b.radius)
        for b in found[:3]:
            try:
                job, info = covering_clear_job(b, state.position, deadline)
            except PlanningTimeout:
                return proposals, dict(clearance_covers=covers, preparation_timed_out=True,
                                       full_problem_optimal=False)
            covers.append(dict(channel=b.channel, **info))
            if job is not None:
                proposals.append(job)
    try:
        route, info = route_plan(state, coverage_gap, exact_limit=6, passes=1, deadline=deadline)
    except PlanningTimeout:
        return proposals, dict(clearance_covers=covers, preparation_timed_out=True,
                               full_problem_optimal=False)
    return [*proposals, *route[:3]], dict(clearance_covers=covers, insertion_route=info,
                                        full_problem_optimal=False)


class TriangleTail:
    def __init__(self, enable_clear=True):
        self.enable_clear = enable_clear

    def for_episode(self, deadline):
        def choose(state, coverage_gap=12):
            base = tail_job(state, coverage_gap)
            # Bounded routing effort inside every sampled tail; the full
            # terminal Held-Karp is a root proposal, not repeated per sample.
            if self.enable_clear and base.kind == 'measure':
                b = state.beliefs[base.channel]
                job, info = covering_clear_job(b, state.position, deadline)
                if job is not None:
                    measure_then_clear_lower = (distance(state.position, base.point)/5
                                                +base.service(state.receiver)[0]+5)
                    if info['worst_case_until_success_s'] <= measure_then_clear_lower:
                        return job
            return base
        return choose
