"""Serial, idempotent simulator client and authoritative action ledger."""

import http.client
import json
import math
from pathlib import Path
import time
from urllib.parse import urlsplit
import uuid


class ProtocolError(RuntimeError):
    pass


class BudgetExpired(RuntimeError):
    pass


class HTTPTransport:
    def __init__(self, base_url, timeout=8.0):
        parts = urlsplit(base_url)
        if parts.scheme not in ("http", "https") or not parts.hostname or parts.path not in ("", "/"):
            raise ValueError("Use an HTTP(S) origin without path, e.g. http://127.0.0.1:2026")
        self.parts, self.timeout, self.connection = parts, timeout, None

    def exchange(self, path, body):
        if self.connection is None:
            cls = http.client.HTTPSConnection if self.parts.scheme == "https" else http.client.HTTPConnection
            self.connection = cls(self.parts.hostname, self.parts.port, timeout=self.timeout)
        try:
            self.connection.request("POST", path, body=body,
                                    headers={"Content-Type": "application/json"})
            response = self.connection.getresponse()
            raw = response.read()
            status = response.status
            data = json.loads(raw.decode("utf-8"))
            return status, data
        except (OSError, http.client.HTTPException, ValueError, UnicodeError):
            self.close()
            raise

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None


class Client:
    def __init__(self, transport, robot_id, log_path=None, exit_margin=12.0, max_virtual_s=None):
        self.transport, self.robot_id = transport, robot_id
        self.log = None
        if log_path:
            Path(log_path).parent.mkdir(parents=True, exist_ok=True)
            self.log = open(log_path, "a", encoding="utf-8", buffering=1)
        self.position = (0.0, 0.0)
        self.channel = 1
        self.virtual_s = 0.0
        self.deadline = None
        self.started = None
        self.entered = False
        self.exit_attempted = False
        self.exited = False
        self.max_virtual_s = max_virtual_s if max_virtual_s is not None else 360000.0
        self.exit_margin = exit_margin
        self.stats = dict(distance_m=0.0, measurements=0, switches=0,
                          clear_success=0, clear_failure=0, retries=0, timing_mismatches=0)

    def record(self, event, **data):
        if self.log:
            self.log.write(json.dumps({"event": event, "local_time": time.time(), **data},
                                      ensure_ascii=False, allow_nan=False) + "\n")

    def time_available(self):
        return self.deadline is None or time.monotonic() < self.deadline - self.exit_margin

    def act(self, path, position=None, channel=None):
        payload = {"arena_id": "default", "robot_id": self.robot_id, "request_id": uuid.uuid4().hex}
        if position is not None:
            if not all(math.isfinite(x) and abs(x) <= 2000000 for x in position):
                raise ProtocolError("Invalid coordinate")
            payload["position"] = {"x": float(position[0]), "y": float(position[1])}
        if channel is not None:
            payload["channel"] = channel
        if path in ("/measure", "/clear"):
            if not self.time_available():
                raise BudgetExpired("real_time_reserve")
            estimate = math.dist(self.position, position)/5 + 5 + (path == "/measure" and channel != self.channel)
            if self.virtual_s + estimate > self.max_virtual_s:
                raise BudgetExpired("virtual_time_reserve")
        body = json.dumps(payload, allow_nan=False).encode("utf-8")
        sent = time.monotonic()
        result = None
        for attempt in range(3):
            if self.deadline is not None and time.monotonic() >= self.deadline:
                raise BudgetExpired("real_time_expired")
            self.record("request", path=path, payload=payload, attempt=attempt+1)
            try:
                status, result = self.transport.exchange(path, body)
            except (OSError, http.client.HTTPException, ValueError, UnicodeError) as error:
                self.record("transport_error", request_id=payload["request_id"], error=str(error))
                if attempt == 2:
                    raise ProtocolError(f"Transport failed after retries: {error}") from error
                self.stats["retries"] += 1
                time.sleep(.2*(attempt+1))
                continue
            self.record("response", path=path, request_id=payload["request_id"], status=status, response=result)
            if status in (429, 500, 502, 503, 504) and attempt < 2:
                self.stats["retries"] += 1
                time.sleep(.2*(attempt+1))
                continue
            if status != 200 or not isinstance(result, dict) or result.get("accepted") is not True:
                raise ProtocolError(f"{path} rejected: HTTP {status}; {result}")
            break
        if not isinstance(result, dict) or result.get("accepted") is not True:
            raise ProtocolError("No accepted response")
        old_time = self.virtual_s
        self.virtual_s = float(result["virtual_time_s"])
        if path == "/enter":
            self.entered = True
            self.started = sent
            self.deadline = sent + float(result["remaining_real_duration_s"])
            self.max_virtual_s = min(self.max_virtual_s, float(result["max_virtual_duration_s"]))
        elif path in ("/measure", "/clear"):
            traveled = math.dist(self.position, position)
            self.stats["distance_m"] += traveled
            self.position = tuple(position)
            predicted = traveled/5
            if path == "/measure":
                switch = int(channel != self.channel)
                self.stats["switches"] += switch
                self.stats["measurements"] += 1
                self.channel = channel
                predicted += 5 + switch
            else:
                success = result.get("clear_result") == "success"
                if result.get("clear_result") not in ("success", "no_target_in_range"):
                    raise ProtocolError("Unknown clear result")
                self.stats["clear_success" if success else "clear_failure"] += 1
                predicted += 5 if success else 3
            if abs((self.virtual_s-old_time)-predicted) > 2e-4:
                self.stats["timing_mismatches"] += 1
                self.record("timing_mismatch", expected=predicted, actual=self.virtual_s-old_time)
        elif path == "/exit":
            self.exited = True
        return result

    def enter(self):
        return self.act("/enter")

    def exit(self):
        if self.entered and not self.exit_attempted:
            self.exit_attempted = True
            return self.act("/exit")

    def close(self):
        self.transport.close()
        if self.log:
            self.log.close()


def scan_channel_order(channels, current):
    channels = sorted(channels)
    return ([current] + [c for c in channels if c != current]) if current in channels else channels
