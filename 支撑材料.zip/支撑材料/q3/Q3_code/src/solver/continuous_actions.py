"""Continuous first-action search with finite-scenario physical lower bounds.

All legal coordinates are covered by branch boxes; feedback tails remain fixed
policies. The interval is NOT a bound for the original expected optimal policy.
Incomplete/failed rollouts never supply a finite upper bound. Only sampled
worlds, not actual environment truth, are used to calculate optimistic bounds.
"""
from dataclasses import replace
import heapq
import math
import time

from .geometry import distance
from .planner import Job
from .posterior import check_deadline, PlanningTimeout, PosteriorUnavailable
from .saa_rollout import RolloutWorld, RolloutLimit

DOMAIN = (-2000000.0, 2000000.0, -2000000.0, 2000000.0)


def point_box_distance(point, box):
    x0,x1,y0,y1 = box
    return math.hypot(max(x0-point[0], 0., point[0]-x1),
                      max(y0-point[1], 0., point[1]-y1))


def box_tree_length(points, box):
    """MST on the first-action box and target clearance disks (relaxation)."""
    weights = [max(0.,point_box_distance(p,box)-20.) for p in points]
    todo = set(range(len(points)))
    total = 0.
    while todo:
        i = min(todo,key=weights.__getitem__)
        total += weights[i]
        todo.remove(i)
        for j in todo:
            weights[j] = min(weights[j],max(0.,distance(points[i],points[j])-40.))
    return total


def box_lower(state, scenarios, kind, channel, box, objective='total'):
    """Expected lower bound for *any* first point in box and any legal tail.

    Successful first clearance can remove its target; unsuccessful clearance
    adds 3s. Taking the minimum of relaxed branches remains a lower bound.
    All remaining targets still require their 5s successful clear operation.
    """
    movement = point_box_distance(state.position,box)/5
    costs = []
    for scenario in scenarios:
        sources = scenario.sources
        points = [s.point for s in sources]
        clear_cost = 5*len(sources)
        tree = box_tree_length(points,box)/5
        if kind == 'measure':
            cost = clear_cost+5+int(channel!=state.receiver)+tree
        else:
            cost = clear_cost+3+tree
            target = next((s for s in sources if s.channel==channel),None)
            if target is not None and point_box_distance(target.point,box)<=20:
                remaining = [s.point for s in sources if s.channel!=channel]
                cost = min(cost,clear_cost+box_tree_length(remaining,box)/5)
        costs.append((movement+cost)/(scenario.total_count if objective=='per_target' else 1))
    return max(0.,sum(costs)/len(costs)-1e-6)


def continuous_search(state, scenarios, incumbent, incumbent_cost, *,
                      continuation, coverage_gap=12, max_actions=600,
                      virtual_limit=360000., deadline=None, node_limit=128,
                      tolerance_s=.01, route_proposals=(), prior_lower=0., objective='total'):
    if objective not in ('total','per_target'):
        raise ValueError('Unknown continuous search objective')
    if not scenarios or not math.isfinite(incumbent_cost) or node_limit<0:
        raise ValueError('Continuous search requires samples and a complete incumbent')
    local_until = (time.monotonic()+max(0.,deadline-time.monotonic())*.45
                   if deadline is not None else math.inf)
    upper = initial_upper = incumbent_cost
    best = incumbent
    queue=[];serial=0;expanded=0;evaluated=0;complete=0;pruned=0;invalid=0
    visited=set();initialization_complete=False;timed_out=False
    # The baseline policy is a separate member of this enlarged policy class.
    # Its finite-policy lower bound must also remain represented.
    def evaluate(job):
        nonlocal upper,best,evaluated,complete,pruned,invalid
        key=(job.kind,job.channel,tuple(job.point))
        if key in visited:return
        visited.add(key)
        check_deadline(deadline)
        evaluated+=1
        point=job.point
        box=(point[0],point[0],point[1],point[1])
        if box_lower(state,scenarios,job.kind,job.channel,box,objective)>=upper:
            pruned+=1;return
        total=0.
        for scenario in scenarios:
            check_deadline(deadline)
            world=RolloutWorld(state,scenario,max_actions,virtual_limit,deadline)
            try:
                world.execute(job)
                total+=world.finish(coverage_gap,continuation)/(scenario.total_count if objective=='per_target' else 1)
            except (RolloutLimit,PosteriorUnavailable,ValueError):
                invalid+=1;return
            # Nonnegative unevaluated sample costs give a safe partial prune.
            if total/len(scenarios)>=upper:
                pruned+=1;return
        complete+=1
        cost=total/len(scenarios)
        if cost<upper:
            upper,best=cost,job

    try:
        # These 40 roots cover the original continuous coordinate domain,
        # including absent channels; no finite candidate list replaces it.
        for kind in ('measure','clear'):
            for channel in range(1,21):
                check_deadline(deadline)
                lb=box_lower(state,scenarios,kind,channel,DOMAIN,objective)
                serial+=1;heapq.heappush(queue,(lb,serial,kind,channel,DOMAIN))
        initialization_complete=True
        # Good feasible proposals improve U before branching the full space.
        for job in route_proposals:
            if time.monotonic()>=local_until:break
            if job.kind in ('measure','clear'):evaluate(job)
        # Deterministic continuous coordinate refinement of the best first
        # position. Its local search never supplies a lower bound/certificate.
        if best.kind in ('measure','clear'):
            for step in (80.,40.,20.,10.):
                if time.monotonic()>=local_until:break
                origins=[best]
                if incumbent.kind in ('measure','clear'):
                    origins.append(incumbent)
                for origin in origins:
                    for dx,dy in ((step,0),(-step,0),(0,step),(0,-step)):
                        if time.monotonic()>=local_until:break
                        q=(origin.point[0]+dx,origin.point[1]+dy)
                        if DOMAIN[0]<=q[0]<=DOMAIN[1] and DOMAIN[2]<=q[1]<=DOMAIN[3]:
                            evaluate(replace(origin,point=q,guaranteed=False))
        while queue and expanded<node_limit:
            check_deadline(deadline)
            lb,number,kind,channel,box=heapq.heappop(queue)
            if lb>=upper:continue
            node=(lb,number,kind,channel,box)
            try:
                expanded+=1
                x0,x1,y0,y1=box
                evaluate(Job(kind,((x0+x1)/2,(y0+y1)/2),channel))
                # Even evaluated centers leave infinitely many other points.
                if max(x1-x0,y1-y0)<1e-6:
                    heapq.heappush(queue,node);break
                if x1-x0>=y1-y0:
                    mid=(x0+x1)/2;children=((x0,mid,y0,y1),(mid,x1,y0,y1))
                else:
                    mid=(y0+y1)/2;children=((x0,x1,y0,mid),(x0,x1,mid,y1))
                for child in children:
                    check_deadline(deadline)
                    child_lb=max(lb,box_lower(state,scenarios,kind,channel,child,objective))
                    if child_lb<upper:
                        serial+=1;heapq.heappush(queue,(child_lb,serial,kind,channel,child))
            except PlanningTimeout:
                # Cover unevaluated children if timeout occurs mid-expansion.
                heapq.heappush(queue,node);raise
            lower=min(prior_lower,queue[0][0] if queue else upper)
            if upper-lower<=tolerance_s:break
    except PlanningTimeout:
        timed_out=True
    lower=min(upper,prior_lower,queue[0][0] if queue else upper) if initialization_complete else 0.
    gap=max(0.,upper-lower)
    return best,dict(method='continuous_first_action_box_branch_and_bound',
        objective=objective,cost_units=('seconds_per_target' if objective=='per_target' else 'seconds'),
        bound_scope='fixed_conditional_samples_continuous_first_action_fixed_feedback_tail_plus_baseline',
        coordinate_domain=list(DOMAIN),continuous_position_search=True,
        lower_bound_s=lower,upper_bound_s=upper,gap_s=gap,
        gap_target_met=gap<=tolerance_s,tolerance_s=tolerance_s,
        initial_upper_s=initial_upper,sample_improvement_s=initial_upper-upper,
        expanded_boxes=expanded,queued_boxes=len(queue),root_coverage_complete=initialization_complete,
        evaluated_points=evaluated,completed_candidates=complete,pruned_candidates=pruned,
        incomplete_or_invalid_candidates=invalid,timed_out=timed_out,
        node_limit_reached=expanded>=node_limit and bool(queue),
        all_future_policies_optimized=False,original_expectation_bounds_certified=False,
        global_optimality_certified=False)
