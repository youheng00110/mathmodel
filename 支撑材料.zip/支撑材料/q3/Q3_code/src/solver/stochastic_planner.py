"""Sample-average optimization over first-job + fixed feedback-tail policies.

Bounds refer to this finite candidate policy class on one shared scenario set.
Unfinished rollouts never receive a guessed finite upper bound.  No posterior
sample or zero probability can certify live completion.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

import math
import time

from .active_sensing import needs_fallback
from .geometry import clear_position, distance
from .planner import Job
from .posterior import (PlanningTimeout, PosteriorUnavailable, SpatialPosterior,
                        check_deadline)
from .saa_rollout import (ObservationState, RolloutLimit, RolloutWorld,
                          local_tail_job, measurement_points, tail_job)


def job_key(job):
    return (job.kind, tuple(job.point), job.channel, job.anchor, tuple(job.scan_channels), tuple(getattr(job,"search_points",())))


def candidate_jobs(state, clouds, base, limit, deadline=None, route_proposals=(), model=None):
    proposals = [base, *route_proposals]
    unknown = tuple(c for c, b in state.beliefs.items() if b.state == "unknown")
    if unknown:
        proposals.extend(Job("scan", p, anchor=i, scan_channels=unknown)
                         for i, p in enumerate(state.anchors) if i not in state.visited)
    for c, b in state.beliefs.items():
        check_deadline(deadline)
        if b.state != "found":
            continue
        local = local_tail_job(b, state.position, model)
        proposals.append(local)
        if local.kind == "clear":
            # Retain the full reliable clearance region: add its nearest
            # feasible points toward remaining scan nodes, not just its center.
            if local.guaranteed:
                for i, p in enumerate(state.anchors):
                    if unknown and i not in state.visited:
                        q = clear_position(b.polygon, p)
                        if q is not None:
                            proposals.append(Job("clear", q, c, True))
            continue
        if needs_fallback(b):
            continue
        mean = clouds[c].mean()
        for p in [mean, state.position, *measurement_points(b, model.lateral_scale if model is not None else .65)]:
            if all(distance(p, q) > .1 for q, _, _ in b.observations):
                proposals.append(Job("measure", p, c))
        eligible = True
        if model is not None and model.clear_probability_min:
            from .decision_model import clear_probability
            eligible = clear_probability(clouds[c],mean) >= model.clear_probability_min
        if eligible and all(distance(mean, q) > .1 for q in b.failed_clears):
            proposals.append(Job("clear", mean, c, False))

    # Shared-location measurements are real sequential channel operations.
    # Candidate discovery probabilities are used only for proposing batches.
    for point in [state.position, *[j.point for j in proposals if j.kind == "measure"]]:
        check_deadline(deadline)
        channels = []
        for c, b in state.beliefs.items():
            if (b.state != "found" or needs_fallback(b) or b.radius <= CLEAR_SAFE_RADIUS_M
                    or any(distance(point, old) <= .1 for old, _, _ in b.observations)):
                continue
            cloud = clouds[c]
            total = sum(p.weight for p in cloud.particles)
            visible = 0.0
            for particle in cloud.particles:
                d = distance(point, particle.point)
                width = particle.radius_upper-particle.radius_lower
                fraction = (float(d <= particle.radius_upper) if width == 0 else
                            max(0.0, min(1.0, (particle.radius_upper-d)/width)))
                visible += particle.weight*fraction
            if total and visible/total >= .5:
                channels.append(c)
        if len(channels) >= 2:
            proposals.append(Job("batch", point, scan_channels=tuple(channels)))

    unique = {job_key(j): j for j in proposals}
    ordered = sorted(unique.values(), key=lambda j: distance(state.position, j.point)/5
                     +j.service(state.receiver)[0])
    # Reserve a few route-level alternatives before cheap immediate actions
    # consume the entire candidate budget. Preserve the old SAA behavior when
    # there are no whole-route proposals.
    kept = [base]
    for job in [*route_proposals[:3], *ordered]:
        if len(kept) >= limit:
            break
        if job_key(job) not in {job_key(j) for j in kept}:
            kept.append(job)
    return kept, len(unique)


class StochasticPlanner:
    def __init__(self, particles=256, scenarios=8, candidates=12, seconds=3.0,
                 relative_gap=.03, seed=20260911, rollout_actions=600, coverage_gap=12,
                 route_aware=False, mathematical=False, sensory=False, error_model="hash", hybrid=False, triangular=False,
                 decision_model=None, continuous=False, objective='total'):
        if objective not in ('total','per_target'):
            raise ValueError('Unknown SAA objective')
        self.objective = objective
        self.continuous = continuous
        self.continuous_calls = self.continuous_improvements = 0
        self.requested_error_model = error_model
        self.world_class = None
        if error_model == 'official':
            if route_aware or mathematical or sensory or hybrid or triangular or continuous:
                raise ValueError('Official joint prediction currently supports the saa policy only')
            from .official_joint import OfficialJointPosterior, OfficialRolloutWorld
            self.posterior = OfficialJointPosterior(particles, seed)
            self.world_class = OfficialRolloutWorld
        else:
            self.posterior = SpatialPosterior(particles, seed, error_model)
        self.scenario_count, self.candidate_limit = scenarios, candidates
        self.seconds, self.relative_gap = seconds, relative_gap
        self.rollout_actions, self.coverage_gap = rollout_actions, coverage_gap
        self.calls = 0
        self.completed_comparisons = 0
        self.fallbacks = 0
        self.gap_stops = 0
        self.total_planning_s = 0.0
        self.route_aware = route_aware
        self.mathematical = mathematical
        self.sensory = sensory
        self.hybrid = hybrid
        self.triangular = triangular
        self.staged = mathematical or sensory or hybrid or triangular
        self.error_model = self.posterior.error_model
        self.decision_model = None
        self.continuation = tail_job
        if decision_model is not None:
            if route_aware or mathematical or sensory or hybrid or triangular:
                raise ValueError('Decision model tuning currently applies to the saa baseline only')
            from .decision_model import DecisionParameters, ParameterizedTail
            self.decision_model = DecisionParameters(**decision_model)
            self.continuation = ParameterizedTail(self.decision_model)
        if route_aware:
            from .route_sensing import route_tail_job
            self.continuation = route_tail_job
        self.continuations = [('whole_observed_task_route' if route_aware else
                               'local_feedback_tail',self.continuation)]
        if mathematical:
            from .mathematical_route import convex_route_tail_job
            # Keep the entire original local-tail policy class; add a second
            # legal feedback continuation, selected jointly with the first job.
            self.continuations = [('local_feedback_tail',tail_job),
                                  ('convex_route_tail',convex_route_tail_job)]
        if sensory:
            from .sensing_search import TwoStageSensingTail
            self.continuations = [('local_feedback_tail',tail_job),
                                  ('one_feedback_sensing_search',TwoStageSensingTail(
                                      error_model=error_model,max_actions=rollout_actions))]

        if hybrid:
            from .hybrid_pomdp import DynamicRouteTail
            self.continuations = [('local_feedback_tail', tail_job),
                                  ('dynamic_tsp_feedback_tail', DynamicRouteTail())]

        if triangular:
            from .triangle_search import TriangleTail
            self.continuations = [('local_feedback_tail', tail_job),
                                  ('triangle_clearance_feedback_tail', TriangleTail())]

    def select(self, state, real_deadline=None, virtual_remaining=360000.0):
        began = time.monotonic()
        self.calls += 1
        base = tail_job(state, self.coverage_gap, self.decision_model)
        deadline = began+self.seconds
        if real_deadline is not None:
            deadline = min(deadline, real_deadline)
        common = dict(global_optimality_certified=False,
                      predictive_error_model=self.error_model,
                      bound_scope="shared_sample_first_job_plus_fixed_feedback_tail",
                      objective=('sample_mean_remaining_time_per_total_target' if self.objective=='per_target'
                                 else 'sample_mean_remaining_virtual_time_s'),
                      cost_units=('seconds_per_target' if self.objective=='per_target' else 'seconds'),
                      sample_gap_target=self.relative_gap)
        if self.decision_model is not None:
            common['decision_model_parameters'] = self.decision_model.as_dict()
        route_proposals = ()
        if self.staged:
            common['candidate_policy_class'] = ('triangle_map_clear_search_and_route' if self.triangular else
                                                'geometry_dynamic_tsp_posterior_rollout' if self.hybrid else
                                                'original_plus_sensing_jobs_and_one_feedback_search' if self.sensory else
                                                'original_saa_jobs_plus_convex_route_proposals_times_two_feedback_tails')
            common['predictive_error_model'] = self.error_model
            common['search_schedule'] = ('complete_incumbent_then_route_competition' if self.hybrid else
                                         'original_class_first_then_optional_expansion')
            common['baseline_gap_target_met'] = False
            common['expansion_started'] = False
            common['expansion_materialized'] = False
            common['bound_scope'] = 'shared_sample_original_saa_class'
        elif self.route_aware:
            from .route_sensing import route_plan
            try:
                # Whole-route preparation is part of the per-decision budget.
                route_proposals, route_info = route_plan(
                    state, self.coverage_gap,
                    deadline=min(deadline, began+min(.25,self.seconds*.2)))
                base = route_proposals[0]
                common['observed_task_route'] = route_info
            except (PlanningTimeout, PosteriorUnavailable) as exc:
                common['observed_task_route'] = dict(status='preparation_fallback', reason=str(exc))
            common['continuation_policy'] = 'whole_observed_task_route'

        def fallback(reason, extra=None):
            self.error_model = self.posterior.error_model
            common['predictive_error_model'] = self.error_model
            common['requested_error_model'] = self.requested_error_model
            common['model_switches'] = list(getattr(self.posterior, 'switches', []))
            self.fallbacks += 1
            elapsed = time.monotonic()-began
            self.total_planning_s += elapsed
            return base, dict(common, status=reason, planning_elapsed_s=elapsed,
                              sample_gap_target_met=False,
                              fixed_policy_class_optimality_certified=False, **(extra or {}))

        # Preserve a finite coverage-progress mechanism.  This is an explicit
        # policy restriction, not an optimality claim derived from the prior.
        if (any(b.state == "unknown" for b in state.beliefs.values())
                and (not state.visited or state.since_scan >= self.coverage_gap)):
            return fallback("coverage_progress_action")
        try:
            samples, clouds, posterior_info = self.posterior.scenarios(
                state.beliefs, self.scenario_count, self.calls, deadline)
            self.error_model = self.posterior.error_model
            common['predictive_error_model'] = self.error_model
            common['requested_error_model'] = self.requested_error_model
            common['model_switches'] = list(getattr(self.posterior, 'switches', []))
            # math_saa retains the same original candidate set before adding
            # up to three convex-route proposals; it never replaces old jobs.
            jobs, generated = candidate_jobs(state, clouds, base, self.candidate_limit, deadline,
                                             () if self.staged else route_proposals, self.decision_model)
            if self.staged:
                common['original_candidate_count'] = len(jobs)
                common['added_route_candidates'] = 0
            check_deadline(deadline)
            denominators = [sample.total_count if self.objective=='per_target' else 1 for sample in samples]
            if any(n<=0 for n in denominators):
                raise ValueError('Nonpositive scenario target count')
            initial_lower = [(self.world_class or RolloutWorld)(state, sample).physical_remaining_lower_bound()/n
                             for sample,n in zip(samples,denominators)]
        except (PlanningTimeout, PosteriorUnavailable) as exc:
            return fallback("posterior_or_generation_fallback", {"fallback_reason": str(exc),
                            "posterior": dict(getattr(self.posterior, 'last_info', {}))})

        # Missing costs stay unknown, not zero or an estimated future_cost.
        def make_row(job, name, continuation):
            return dict(job=job, lower=list(initial_lower), costs=[None]*len(samples),
                        limited=set(),continuation=continuation,continuation_name=name)

        initial_tails = self.continuations[:1] if self.staged else self.continuations
        rows = [make_row(job,name,continuation)
                for name,continuation in initial_tails for job in jobs]
        timed_out = False
        evaluations = 0
        focused_row = None
        focus_starts = 0

        def row_lower(row):
            return sum(row["lower"])/len(samples)

        def row_upper(row):
            return (sum(row["costs"])/len(samples)
                    if all(x is not None for x in row["costs"]) else math.inf)

        def root_bounds():
            return min(map(row_lower, rows)), min(map(row_upper, rows))

        def expand_after_baseline(lower, upper):
            nonlocal generated
            common['baseline_sample_lower_s'] = lower
            common['baseline_sample_upper_s'] = upper
            common['baseline_gap_target_met'] = upper-lower <= max(1e-6,self.relative_gap*upper)
            common['baseline_elapsed_s'] = time.monotonic()-began
            common['expansion_started'] = True
            proposals = ()
            # Root geometry is delayed until the old class has been solved to
            # its requested gap. It cannot take time away from that first phase.
            try:
                if self.triangular:
                    from .triangle_search import triangle_proposals
                    proposals, triangle_info = triangle_proposals(state, self.coverage_gap,
                        deadline=min(deadline,time.monotonic()+min(.5,self.seconds*.3)))
                    common['triangle_actions'] = triangle_info
                elif self.hybrid:
                    from .route_sensing import route_plan
                    proposals, route_info = route_plan(
                        state, self.coverage_gap, exact_limit=6, passes=2,
                        deadline=min(deadline,time.monotonic()+min(.25,self.seconds*.2)))
                    common['dynamic_tsp_route'] = route_info
                elif self.sensory:
                    from .sensing_search import sensing_candidates
                    proposals = sensing_candidates(state,6,deadline)
                    common['sensing_proposals'] = dict(count=len(proposals),
                        nested_feedback_decisions=1,nested_scenarios=2,
                        uses_actual_simulator_truth=False)
                else:
                    from .mathematical_route import mathematical_route_proposals
                    proposals,route_info = mathematical_route_proposals(
                        state,self.coverage_gap,
                        deadline=min(deadline,time.monotonic()+min(.25,self.seconds*.2)))
                    common['mathematical_route'] = route_info
            except (PlanningTimeout,PosteriorUnavailable,ValueError) as exc:
                common['proposal_preparation_fallback'] = str(exc)
            check_deadline(deadline)
            original_count = len(jobs)
            for proposal in proposals[:6 if (self.sensory or self.triangular) else 3]:
                if job_key(proposal) not in {job_key(job) for job in jobs}:
                    jobs.append(proposal)
            common['added_route_candidates'] = len(jobs)-original_count
            generated += len(jobs)-original_count
            # Old rows/costs stay intact. Only completely evaluated policies
            # can replace their incumbent. Global gap now includes new rows.
            rows.extend(make_row(job,*self.continuations[0]) for job in jobs[original_count:])
            rows.extend(make_row(job,name,continuation)
                        for name,continuation in self.continuations[1:] for job in jobs)
            common['expansion_materialized'] = True
            common['bound_scope'] = 'shared_sample_first_job_and_continuation_choice'

        try:
            while True:
                check_deadline(deadline)
                lower, upper = root_bounds()
                # A completed incumbent is sufficient to protect the baseline.
                # Do not spend the entire budget certifying every old action
                # before the requested route continuation gets any work.
                if self.hybrid and math.isfinite(upper) and not common['expansion_started']:
                    expand_after_baseline(lower,upper)
                    continue
                if math.isfinite(upper) and upper-lower <= max(1e-6, self.relative_gap*upper):
                    if self.staged and not common['expansion_started']:
                        expand_after_baseline(lower,upper)
                        continue
                    break
                available = [r for r in rows if row_lower(r) < upper
                             and any(value is None and i not in r["limited"]
                                     for i, value in enumerate(r["costs"]))]
                if not available:
                    break
                if (self.sensory or self.hybrid or self.triangular) and common.get('expansion_materialized'):
                    # Keep all pending bounds, but avoid spreading a small
                    # budget over hundreds of one-sample unfinished policies.
                    # Continue one candidate until complete, pruned, capped or
                    # timed out. Bounds still decide which candidate to start.
                    if (focused_row is None or focused_row['limited']
                            or not any(r is focused_row for r in available)):
                        finishable=[r for r in available if not r['limited']]
                        focused_row=min(finishable or available,key=lambda r: (
                            0 if self.hybrid and r['continuation_name']=='dynamic_tsp_feedback_tail' else 1,
                            row_lower(r)))
                        focus_starts+=1
                    row=focused_row
                else:
                    # Preserve the original SAA schedule during phase one.
                    row = next((r for r in available if r is rows[0]), None)
                    if row is None:
                        row = min(available, key=row_lower)
                index = next(i for i, value in enumerate(row["costs"])
                             if value is None and i not in row["limited"])
                world = (self.world_class or RolloutWorld)(state, samples[index], self.rollout_actions,
                                     virtual_remaining, deadline)
                try:
                    world.execute(row["job"])
                    row["lower"][index] = max(row["lower"][index], (world.elapsed
                                              +world.physical_remaining_lower_bound())/denominators[index])
                    continuation = row['continuation']
                    if hasattr(continuation,'for_episode'):
                        continuation = continuation.for_episode(deadline)
                    cost = world.finish(self.coverage_gap, continuation)
                    row["costs"][index] = cost/denominators[index]
                    row["lower"][index] = cost/denominators[index]
                    evaluations += 1
                except RolloutLimit:
                    # A computational rollout cap is not proof of infeasibility.
                    row["lower"][index] = max(row["lower"][index], (world.elapsed
                                              +world.physical_remaining_lower_bound())/denominators[index])
                    row["limited"].add(index)
                except PlanningTimeout:
                    row["lower"][index] = max(row["lower"][index], (world.elapsed
                                              +world.physical_remaining_lower_bound())/denominators[index])
                    raise
        except PlanningTimeout:
            timed_out = True
        except (PosteriorUnavailable, ValueError) as exc:
            if not self.staged:
                return fallback("inconsistent_numerical_rollout", {"fallback_reason": str(exc),
                                                                   "posterior": posterior_info})
            common['numerical_search_interruption'] = str(exc)

        lower, upper = root_bounds()
        details = []
        for r in rows:
            value = row_upper(r)
            details.append(dict(job=r["job"].__dict__, lower_mean_s=row_lower(r),
                                continuation_policy=r['continuation_name'],
                                upper_mean_s=value if math.isfinite(value) else None,
                                completed_samples=sum(x is not None for x in r["costs"]),
                                capped_samples=len(r["limited"])))
        extra = dict(posterior=posterior_info, scenario_count=len(samples),
                     candidate_count=len(jobs), generated_candidates=generated,
                     candidate_policy_count=len(rows),
                     complete_rollout_evaluations=evaluations, candidate_bounds=details,
                     sample_lower_bound_s=lower, timed_out=timed_out)
        if self.sensory or self.hybrid or self.triangular:
            extra['expansion_schedule']='finish_candidate_or_bound_prune'
            extra['candidate_focus_starts']=focus_starts
        if self.staged:
            original_rows = rows[:common['original_candidate_count']]
            original_upper = min(map(row_upper,original_rows))
            extra['evaluated_original_saa_upper_s'] = (original_upper
                                                       if math.isfinite(original_upper) else None)
            extra['sample_saving_vs_evaluated_original_saa_s'] = (
                original_upper-upper if math.isfinite(original_upper) and math.isfinite(upper) else None)
            baseline_upper = common.get('baseline_sample_upper_s')
            extra['baseline_incumbent_preserved'] = (
                upper <= baseline_upper+1e-8 if baseline_upper is not None else None)
            extra['sample_improvement_from_baseline_incumbent_s'] = (
                baseline_upper-upper if baseline_upper is not None and math.isfinite(upper) else None)
        if not math.isfinite(upper):
            return fallback("no_complete_sample_incumbent", extra)

        chosen = min(rows, key=row_upper)
        gap = max(0.0, upper-lower)
        met = (gap <= max(1e-6, self.relative_gap*upper)
               and not common.get('numerical_search_interruption'))
        self.completed_comparisons += 1
        self.gap_stops += int(met)
        elapsed = time.monotonic()-began
        self.total_planning_s += elapsed
        selected = chosen['job']
        result = dict(common, **extra, status="sample_incumbent",
                                   selected_continuation_policy=chosen['continuation_name'],
                                   sample_upper_bound_s=upper, sample_gap_s=gap,
                                   sample_gap_pct=100*gap/upper if upper else 0.0,
                                   sample_gap_target_met=met,
                                   fixed_policy_class_optimality_certified=(gap <= 1e-6 and met),
                                   selected_policy_all_sample_tails_completed=True,
                                   planning_elapsed_s=elapsed)
        if self.continuous:
            from .continuous_actions import continuous_search
            from .mathematical_route import mathematical_route_proposals
            proposals = ()
            # A route certificate remains confined to the frozen task problem.
            # Its first action competes through complete feedback rollouts.
            try:
                if time.monotonic() < deadline:
                    proposals, route_info = mathematical_route_proposals(
                        state, self.coverage_gap,
                        deadline=min(deadline,time.monotonic()+min(.2,self.seconds*.1)))
                    result['continuous_clearance_route'] = route_info
            except (PlanningTimeout,PosteriorUnavailable,ValueError) as exc:
                result['route_proposal_interruption'] = str(exc)
            refined, continuous_info = continuous_search(
                state,samples,selected,upper,continuation=self.continuation,
                coverage_gap=self.coverage_gap,max_actions=self.rollout_actions,
                virtual_limit=virtual_remaining,deadline=deadline,
                route_proposals=proposals[:3],prior_lower=lower,objective=self.objective)
            selected = refined
            self.continuous_calls += 1
            self.continuous_improvements += int(continuous_info['sample_improvement_s']>1e-6)
            self.gap_stops += int(continuous_info['gap_target_met'])-int(met)
            result['continuous_search'] = continuous_info
            result['finite_candidate_sample_lower_s'] = lower
            result['finite_candidate_sample_upper_s'] = upper
            result['sample_lower_bound_s'] = continuous_info['lower_bound_s']
            result['sample_upper_bound_s'] = continuous_info['upper_bound_s']
            result['sample_gap_s'] = continuous_info['gap_s']
            result['sample_gap_pct'] = (100*continuous_info['gap_s']/continuous_info['upper_bound_s']
                                        if continuous_info['upper_bound_s'] else 0.)
            result['sample_gap_target_met'] = continuous_info['gap_target_met']
            result['fixed_policy_class_optimality_certified'] = False
            result['bound_scope'] = continuous_info['bound_scope']
            extra_elapsed = time.monotonic()-began-elapsed
            self.total_planning_s += extra_elapsed
            result['planning_elapsed_s'] = time.monotonic()-began
        return selected, result

    def summary(self):
        return dict(planning_calls=self.calls, sample_comparisons=self.completed_comparisons,
                    optimization_objective=self.objective,
                    cost_units=('seconds_per_target' if self.objective=='per_target' else 'seconds'),
                    decision_model_parameters=self.decision_model.as_dict() if self.decision_model else None,
                    fallback_calls=self.fallbacks, sample_gap_stops=self.gap_stops,
                    total_planning_s=self.total_planning_s,
                    scenarios=self.scenario_count, candidates=self.candidate_limit,
                    particles_per_channel=(None if self.error_model=='official' else self.posterior.particles),
                    joint_seed_proposal_limit=getattr(self.posterior,'max_draws',None),
                    predictive_error_model=self.error_model,
                    requested_error_model=self.requested_error_model,
                    model_switches=list(getattr(self.posterior, 'switches', [])),
                    continuous_first_action_search=self.continuous,
                    continuous_search_calls=self.continuous_calls,
                    continuous_sample_improvements=self.continuous_improvements,
                    posterior_version=('official-joint-seed-rejection-v1' if self.error_model=='official' else
                                       'smooth-phase-importance-v2' if self.error_model=='smooth' else 'hash-v1'),
                    feedback_search=(dict(self.continuations[1][1].statistics) if self.sensory else None),
                    continuation_policy=('triangle_map_clearance_and_insertion' if self.triangular else
                                         'geometry_dynamic_tsp_posterior_rollout' if self.hybrid else
                                         'joint_local_and_one_feedback_sensing_search' if self.sensory else
                                         'joint_local_and_convex_route_choice' if self.mathematical else
                                         'whole_observed_task_route' if self.route_aware
                                         else 'local_feedback_tail'),
                    bound_scope=('fixed_conditional_samples_continuous_first_action_fixed_feedback_tail_plus_baseline' if self.continuous else
                                 'finite_sample_first_job_and_tail_choice' if self.staged
                                 else 'finite_sample_candidate_first_job_fixed_tail_only'),
                    global_optimality_certified=False)
