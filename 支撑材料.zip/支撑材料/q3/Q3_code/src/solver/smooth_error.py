"""Conditional phase support for the declared LOCAL smooth error family.

This model is an explicit assumption, not an official simulator calibration.
Angles in observations are degrees; phase and interval endpoints are radians.
"""
import math

TAU = 2*math.pi


def smooth_error(point,phase):
    x,y = point
    return .6*math.sin(x/211+y/173+phase)+.4*math.cos(x/97-y/131+phase)


def phase_intervals(point,lower,upper):
    """All phases with lower <= error(point, phase) <= upper."""
    x,y = point
    a,b = x/211+y/173,x/97-y/131
    sine = .6*math.cos(a)-.4*math.sin(b)
    cosine = .6*math.sin(a)+.4*math.cos(b)
    amplitude = math.hypot(sine,cosine)
    offset = math.atan2(cosine,sine)
    if lower>upper or lower>amplitude or upper < -amplitude:
        return ()
    cuts = [0.0,TAU]
    for level in (lower,upper):
        if -amplitude <= level <= amplitude:
            angle = math.asin(max(-1.0,min(1.0,level/amplitude)))
            cuts.extend(((angle-offset)%TAU,(math.pi-angle-offset)%TAU))
    cuts = sorted(set(cuts))
    return tuple((left,right) for left,right in zip(cuts,cuts[1:])
                 if right>left and lower <= smooth_error(point,(left+right)/2) <= upper)


def intersect_intervals(first,second):
    return tuple((max(a,c),min(b,d)) for a,b in first for c,d in second
                 if max(a,c)<min(b,d))


def compatible_phases(belief,target):
    support = ((0.0,TAU),)
    seen = set()
    for point,kind,observed in belief.observations:
        if kind!='direction' or tuple(point) in seen:
            continue
        seen.add(tuple(point))
        angle = math.degrees(math.atan2(target[1]-point[1],target[0]-point[0]))
        residual = (observed-angle+180)%360-180
        support = intersect_intervals(support,phase_intervals(point,residual-.005,residual+.005))
        if not support:
            break
    return support


def draw_phase(intervals,rng):
    total = sum(b-a for a,b in intervals)
    if total<=0:
        raise ValueError('Empty conditional phase support')
    offset = rng.random()*total
    for a,b in intervals:
        if offset < b-a:
            return a+offset
        offset -= b-a
    return (intervals[-1][0]+intervals[-1][1])/2
