"""Whole observed-task routes; certificates apply only to frozen job positions.

Never accepts hidden source positions. Measurement jobs are one next legal
observation per found channel, not a claim that that observation completes it.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

from dataclasses import replace
import math

from .active_sensing import needs_fallback
from .geometry import clear_position, distance
from .planner import Job, frozen_route_lower_bound
from .posterior import PosteriorUnavailable, check_deadline
from .saa_rollout import local_tail_job, measurement_points


def service(job, receiver):
    value, after = job.service(receiver)
    # Frozen routing charges all clears 5 s; actual failed clears still cost 3.
    return (5 if job.kind == 'clear' else value), after


def route_cost(route, current, receiver):
    total = 0.0
    for job in route:
        cost, receiver = service(job, receiver)
        total += distance(current, job.point)/5 + cost
        current = job.point
    return total


def optimize_order(jobs, current, receiver, forced_scan=False, exact_limit=8,
                   passes=3, deadline=None):
    """Exact receiver-aware subset DP for small sets; full-set 2-opt otherwise.

No jobs are discarded on the approximate path. The first-job scan constraint
is respected both in DP and segment reversal. Costs exclude guessed future.
"""
    jobs = list(jobs)
    if not jobs:
        return [], dict(lower_s=0.0, upper_s=0.0, exact=True, method='empty')
    allowed = {i for i, job in enumerate(jobs) if not forced_scan or job.kind == 'scan'}
    if not allowed:
        raise PosteriorUnavailable('Forced scan without a coverage job')
    n = len(jobs)
    edges = [[distance(a.point, b.point)/5 for b in jobs] for a in jobs]
    start = [distance(current, job.point)/5 for job in jobs]
    if n <= exact_limit:
        states = {(0, -1, receiver): (0.0, ())}
        for step in range(n):
            check_deadline(deadline)
            nxt = {}
            for count, ((mask, last, channel), (cost, indices)) in enumerate(states.items()):
                if count % 128 == 0:
                    check_deadline(deadline)
                for i, job in enumerate(jobs):
                    if mask & (1 << i) or (step == 0 and i not in allowed):
                        continue
                    fee, after = service(job, channel)
                    value = cost + (start[i] if last < 0 else edges[last][i]) + fee
                    key = mask | (1 << i), i, after
                    if key not in nxt or value < nxt[key][0]:
                        nxt[key] = value, indices+(i,)
            states = nxt
        cost, indices = min(states.values(), key=lambda row: row[0])
        return [jobs[i] for i in indices], dict(lower_s=cost, upper_s=cost,
                                               exact=True, method='subset_dp')

    todo, order, last, channel = set(range(n)), [], -1, receiver
    while todo:
        check_deadline(deadline)
        eligible = todo & allowed if not order else todo
        i = min(eligible, key=lambda k: ((start[k] if last < 0 else edges[last][k])
                                        +service(jobs[k], channel)[0], k))
        channel = service(jobs[i], channel)[1]
        order.append(i)
        todo.remove(i)
        last = i
    route = [jobs[i] for i in order]
    cost = route_cost(route, current, receiver)
    for _ in range(passes):
        best_route, best_cost = route, cost
        for i in range(n-1):
            check_deadline(deadline)
            for j in range(i+1, n):
                candidate = route[:i]+list(reversed(route[i:j+1]))+route[j+1:]
                if forced_scan and candidate[0].kind != 'scan':
                    continue
                value = route_cost(candidate, current, receiver)
                if value < best_cost-1e-9:
                    best_route, best_cost = candidate, value
        if best_cost >= cost-1e-9:
            break
        route, cost = best_route, best_cost
    return route, dict(lower_s=frozen_route_lower_bound(jobs, current), upper_s=cost,
                       exact=False, method='all_jobs_nearest_then_2opt')


def frozen_jobs(state):
    """All remaining anchors plus one observation/clearance per found source."""
    unknown = tuple(c for c, b in state.beliefs.items() if b.state == 'unknown')
    scans = [Job('scan', p, anchor=i, scan_channels=unknown)
             for i, p in enumerate(state.anchors) if unknown and i not in state.visited]
    if unknown and not scans:
        raise PosteriorUnavailable('Unknown channels after complete coverage')
    local = [local_tail_job(b, state.position) for b in state.beliefs.values()
             if b.state == 'found']
    return local+scans


def refine_route(route, state, deadline=None):
    """Monotone waypoint proposals, not a continuous global optimum proof.

    Reliable clear locations stay in the intersection of vertex-centered
    19.7 m disks. Measurement alternatives are existing geometric proposals.
    """
    improved = list(route)
    for i, job in enumerate(improved):
        check_deadline(deadline)
        if job.kind not in ('measure', 'clear'):
            continue
        belief = state.beliefs[job.channel]
        before = state.position if i == 0 else improved[i-1].point
        after = improved[i+1].point if i+1 < len(improved) else None
        candidates = [job.point]
        if job.kind == 'clear' and job.guaranteed:
            probes = [before]
            if after is not None:
                probes += [after, tuple((a+b)/2 for a,b in zip(before,after))]
            for probe in probes:
                check_deadline(deadline)
                point = clear_position(belief.polygon, probe)
                if point is not None and all(distance(point,v) <= (CLEAR_SAFE_RADIUS_M + 1e-6) for v in belief.polygon):
                    candidates.append(point)
        elif job.kind == 'measure' and not needs_fallback(belief):
            candidates += measurement_points(belief)
        def length(point):
            return distance(before,point)+(distance(point,after) if after is not None else 0)
        improved[i] = replace(job, point=min(candidates,key=length))
    return improved


def route_plan(state, coverage_gap=12, exact_limit=8, passes=3, refine=True, deadline=None):
    jobs = frozen_jobs(state)
    if not jobs:
        raise PosteriorUnavailable('No jobs in a nonterminal route state')
    forced = (any(b.state == 'unknown' for b in state.beliefs.values())
              and state.since_scan >= coverage_gap)
    # Keep the existing initial origin scan; there is no paid travel here.
    if not state.visited and any(j.kind == 'scan' for j in jobs):
        first = next(j for j in jobs if j.kind == 'scan' and j.anchor == 0)
        return [first], dict(scope='initial_origin_scan', all_observed_tasks_included=False,
                             global_optimality_certified=False)
    route, bounds = optimize_order(jobs,state.position,state.receiver,forced,
                                   exact_limit,passes,deadline)
    before_refinement = bounds['upper_s']
    refined = False
    if refine:
        proposal = refine_route(route,state,deadline)
        # Positional changes alter the frozen model: recompute its bounds.
        # For large sets retain the original order as an incumbent if NN
        # initialization on the changed points would produce a worse tour.
        new_route, new_bounds = optimize_order(proposal,state.position,state.receiver,forced,
                                              exact_limit,passes,deadline)
        proposal_cost = route_cost(proposal,state.position,state.receiver)
        if proposal_cost < new_bounds['upper_s']:
            new_route, new_bounds['upper_s'] = proposal, proposal_cost
        if new_bounds['upper_s'] <= before_refinement+1e-8:
            refined = any(a.point != b.point for a,b in zip(route,proposal))
            route, bounds = new_route, new_bounds
    lower, upper = bounds['lower_s'], bounds['upper_s']
    if lower > upper+1e-6:
        raise ValueError('Frozen route lower bound exceeds incumbent')
    return route, dict(scope='current_frozen_jobs_at_final_proposed_positions',
                       all_observed_tasks_included=True, task_count=len(jobs),
                       found_tasks=sum(j.kind != 'scan' for j in jobs),
                       remaining_scan_tasks=sum(j.kind == 'scan' for j in jobs),
                       frozen_route_lower_bound_s=lower, frozen_route_upper_bound_s=upper,
                       frozen_route_gap_s=max(0.0,upper-lower),
                       fixed_positions_order_optimal=bounds['exact'], method=bounds['method'],
                       positional_refinement=refined,
                       before_refinement_cost_s=before_refinement,
                       continuous_position_optimality_certified=False,
                       full_feedback_completion_bound=False,
                       global_optimality_certified=False,
                       route=[j.__dict__ for j in route])


def route_tail_job(state, coverage_gap=12):
    # Fixed numerical effort makes the same feedback history choose the same
    # tail action, independently of the hidden sample and elapsed CPU time.
    return route_plan(state,coverage_gap,exact_limit=4,passes=1,refine=False)[0][0]
