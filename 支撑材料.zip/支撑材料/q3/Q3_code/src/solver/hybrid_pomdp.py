"""Geometry + dynamic open TSP continuation for posterior rollout search.

This is a feedback policy on observable beliefs, not an exact POMDP solver.
The deadline may interrupt evaluation; incomplete trajectories have no finite
upper bound. No sampled source truth is accepted by the action selector.
"""

from .route_sensing import route_plan


class DynamicRouteTail:
    def __call__(self, state, coverage_gap=12):
        return self.for_episode(None)(state, coverage_gap)

    def for_episode(self, deadline):
        def choose(state, coverage_gap=12):
            # Rebuild after every observation: measurements are pending jobs,
            # never treated as if they already localized their targets.
            route, _ = route_plan(state, coverage_gap, exact_limit=4,
                                  passes=1, refine=False, deadline=deadline)
            return route[0]
        return choose
