"""Conditional-gradient optimization of reliable clear points in a fixed route.

The objective is convex, the feasible set is a product of intersections of
disks. Bounds apply to this fixed order and fixed measurement/scan points.
No optimization call reads source truth or changes observations.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

from dataclasses import replace
from functools import lru_cache
import math

from .geometry import distance, enclosing_circle
from .posterior import PlanningTimeout, check_deadline


def dot(a, b):
    return a[0]*b[0]+a[1]*b[1]


def minus(a, b):
    return a[0]-b[0], a[1]-b[1]


class ClearanceRegion:
    """Linear minimization and a feasible dual bound for an intersection."""

    def __init__(self, vertices, radius=CLEAR_SAFE_RADIUS_M):
        self.vertices = tuple(dict.fromkeys(tuple(v) for v in vertices))
        self.radius = radius
        if not self.vertices or radius <= 0:
            raise ValueError('Empty or invalid clearance region')
        self.center, _ = enclosing_circle(self.vertices)
        self.center_radius = max(distance(self.center,v) for v in self.vertices)
        if self.center_radius > radius:
            raise ValueError('No certified feasible center in clearance region')
        self.corners = []
        for i,a in enumerate(self.vertices):
            for j,b in enumerate(self.vertices[:i]):
                d = distance(a,b)
                if d < 1e-12 or d > 2*radius:
                    continue
                middle = ((a[0]+b[0])/2,(a[1]+b[1])/2)
                h = math.sqrt(max(0.0,radius*radius-d*d/4))
                for sign in (-1,1):
                    p = (middle[0]+sign*h*(b[1]-a[1])/d,
                         middle[1]-sign*h*(b[0]-a[0])/d)
                    if self.feasible(p,1e-7):
                        self.corners.append((self.repair(p),i,j,p))

    def feasible(self, point, tolerance=0.0):
        return all(distance(point,v) <= self.radius+tolerance for v in self.vertices)

    def repair(self, point):
        """Convex interpolation with an interior center repairs roundoff."""
        maximum = max(distance(point,v) for v in self.vertices)
        if maximum <= self.radius:
            return tuple(point)
        if maximum <= self.center_radius:
            return self.center
        weight = max(0.0,(self.radius-self.center_radius)/(maximum-self.center_radius))
        weight *= 1-1e-12
        return tuple(c+weight*(p-c) for c,p in zip(self.center,point))

    def linear_minimum(self, vector):
        """Return feasible minimizer proposal and independent dual lower bound.

        For any y_i summing to a:
          min_{q in K} a.q >= sum_i (y_i.v_i - R ||y_i||).
        A one-disk dual always exists. At an active corner a two-disk dual
        usually makes the bound tight. A nonexact proposal cannot make this
        bound invalid: it is constructed from feasible dual vectors.
        """
        norm = math.hypot(*vector)
        if norm == 0:
            return self.center, 0.0
        candidates = [(self.center,None)]
        candidates += [(p,(i,j,raw)) for p,i,j,raw in self.corners]
        for v in self.vertices:
            point = tuple(v[k]-self.radius*vector[k]/norm for k in (0,1))
            if self.feasible(point,1e-7):
                candidates.append((self.repair(point),None))
        point, active = min(candidates,key=lambda item:dot(vector,minus(item[0],self.center)))
        offsets = [minus(v,self.center) for v in self.vertices]
        dual = max(dot(vector,v)-self.radius*norm for v in offsets)
        if active is not None:
            i,j,raw = active
            a = tuple((self.vertices[i][k]-raw[k])/self.radius for k in (0,1))
            b = tuple((self.vertices[j][k]-raw[k])/self.radius for k in (0,1))
            determinant = a[0]*b[1]-a[1]*b[0]
            if abs(determinant) > 1e-10:
                coefficient = (vector[0]*b[1]-vector[1]*b[0])/determinant
                first = (coefficient*a[0],coefficient*a[1])
                # The residual enforces the dual vector sum, without relying
                # on rounded KKT multipliers having an exact sum.
                second = minus(vector,first)
                pair = (dot(first,offsets[i])+dot(second,offsets[j])
                        -self.radius*(math.hypot(*first)+math.hypot(*second)))
                if math.isfinite(pair):
                    dual = max(dual,pair)
        guard = 1e-9*(1+norm*(math.hypot(*self.center)+self.radius))
        return point, dot(vector,self.center)+dual-guard


@lru_cache(maxsize=256)
def clearance_region(vertices, radius=CLEAR_SAFE_RADIUS_M):
    return ClearanceRegion(vertices,radius)


def path_length(points, start):
    return sum(distance(a,b) for a,b in zip([start]+list(points[:-1]),points))


def smooth_value_gradient(points, start, epsilon):
    value = 0.0
    gradient = [[0.0,0.0] for _ in points]
    previous = start
    for i,point in enumerate(points):
        delta = minus(point,previous)
        length = math.sqrt(dot(delta,delta)+epsilon*epsilon)
        value += length
        for k in (0,1):
            gradient[i][k] += delta[k]/length
            if i:
                gradient[i-1][k] -= delta[k]/length
        previous = point
    return value,gradient


def line_search(points, directions, start, epsilon):
    """Bisection on the monotone derivative of a convex one-dimensional loss."""
    def derivative(step):
        value = 0.0
        previous, previous_direction = start,(0.0,0.0)
        for point,direction in zip(points,directions):
            delta = minus(point,previous)
            change = minus(direction,previous_direction)
            edge = tuple(delta[k]+step*change[k] for k in (0,1))
            value += dot(edge,change)/math.sqrt(dot(edge,edge)+epsilon*epsilon)
            previous,previous_direction = point,direction
        return value
    if derivative(0.0) >= 0:
        return 0.0
    if derivative(1.0) <= 0:
        return 1.0
    left,right = 0.0,1.0
    for _ in range(40):
        middle = (left+right)/2
        if derivative(middle) > 0:
            right = middle
        else:
            left = middle
    return (left+right)/2


def optimize_clearance_points(route, beliefs, start, iterations=80, tolerance_m=.02,
                              smoothing_m=.0001, deadline=None):
    """Feasible convex solver with a bound for the original unsmoothed length."""
    if iterations < 0 or tolerance_m < 0 or smoothing_m <= 0:
        raise ValueError('Invalid convex optimization parameters')
    route = list(route)
    points = [tuple(j.point) for j in route]
    regions = {}
    for i,job in enumerate(route):
        check_deadline(deadline)
        if job.kind == 'clear' and job.guaranteed:
            region = clearance_region(tuple(tuple(v) for v in beliefs[job.channel].polygon))
            # The incumbent must be feasible for the stated convex problem.
            # Repair only rounding; an unrelated infeasible point is not an
            # upper bound and is replaced by the region's interior center.
            points[i] = region.repair(points[i])
            regions[i] = region
    original = path_length(points,start)
    best, upper, lower = list(points),original,0.0
    timed_out, used = False,0
    if not regions:
        lower = upper
    else:
        try:
            for _ in range(iterations):
                check_deadline(deadline)
                value,gradient = smooth_value_gradient(points,start,smoothing_m)
                direction = [(0.0,0.0) for _ in points]
                bound = value-len(points)*smoothing_m
                for i,region in regions.items():
                    check_deadline(deadline)
                    proposal,support_lower = region.linear_minimum(gradient[i])
                    direction[i] = minus(proposal,points[i])
                    bound += support_lower-dot(gradient[i],points[i])
                # Subtracting n*epsilon transfers the supporting hyperplane
                # bound from the smooth objective back to true path length.
                lower = max(lower,bound)
                if lower > upper+1e-5:
                    raise ValueError('Inconsistent convex primal/dual bounds')
                used += 1
                if upper-lower <= tolerance_m:
                    break
                step = line_search(points,direction,start,smoothing_m)
                if step == 0:
                    break
                points = [tuple(p[k]+step*d[k] for k in (0,1)) for p,d in zip(points,direction)]
                for i,region in regions.items():
                    points[i] = region.repair(points[i])
                actual = path_length(points,start)
                if actual < upper:
                    best,upper = list(points),actual
        except PlanningTimeout:
            timed_out = True
    optimized = [replace(job,point=best[i]) for i,job in enumerate(route)]
    if lower > upper+1e-5:
        raise ValueError('Final convex lower bound exceeds feasible length')
    gap = max(0.0,upper-lower)
    return optimized,dict(method='conditional_gradient_with_disk_support_dual',
                          bound_scope='fixed_order_reliable_clearance_points_only',
                          initial_length_m=original,length_upper_bound_m=upper,
                          length_lower_bound_m=lower,optimality_gap_m=gap,
                          optimality_gap_s=gap/5,iterations=used,timed_out=timed_out,
                          optimized_clearance_points=len(regions),
                          fixed_order_gap_target_met=(gap<=tolerance_m),
                          smoothing_error_bound_m=len(points)*smoothing_m,
                          global_optimality_certified=False)
