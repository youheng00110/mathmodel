"""Conservative per-channel outer sets, represented by adaptive triangles.

Cells crossing an exclusion boundary are retained at the resource limit.
Empty support is a geometric certificate, never a particle-count decision.
"""

from dataclasses import dataclass, field
from bisect import bisect_left
from copy import deepcopy
from functools import lru_cache
import math

from .belief import Belief
from .geometry import distance, enclosing_circle, polygon_distance


def triangulate(poly):
    if len(poly) <= 3:
        return [tuple(poly)] if poly else []
    return [(poly[0], poly[i], poly[i+1]) for i in range(1, len(poly)-1)]


def triangle_sampler(cells):
    """Uniform area proposal and its area, needed for existence evidence."""
    triangles, cumulative, area = [], [], 0.0
    for cell in cells:
        if len(cell) != 3:
            continue
        a, b, c = cell
        weight = abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
        if weight > 0:
            area += weight
            triangles.append(cell)
            cumulative.append(area)
    if not triangles:
        raise ValueError('No positive area in triangle support')
    def draw(rng):
        a, b, c = triangles[bisect_left(cumulative, rng.random()*area)]
        u, v = math.sqrt(rng.random()), rng.random()
        return tuple((1-u)*a[k]+u*(1-v)*b[k]+u*v*c[k] for k in (0,1))
    return draw, area


def split(cell):
    if len(cell) < 2:
        return [cell]
    i, j = max(((i, j) for i in range(len(cell)) for j in range(i+1, len(cell))),
               key=lambda ij: distance(cell[ij[0]], cell[ij[1]]))
    mid = tuple((cell[i][k]+cell[j][k])/2 for k in (0, 1))
    a, b = list(cell), list(cell)
    a[i], b[j] = mid, mid
    return [tuple(a), tuple(b)]


def convex_hull(points):
    points = sorted(set(points))
    if len(points) <= 2:
        return points
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def half(seq):
        out = []
        for p in seq:
            while len(out) >= 2 and cross(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
        return out
    return half(points)[:-1]+half(reversed(points))[:-1]


def exclude_disks(poly, exclusions, resolution=40.0, max_cells=512):
    cells, info = _exclude_disks(tuple(tuple(p) for p in poly),
                                tuple((tuple(p), r) for p, r in exclusions),
                                resolution, max_cells)
    return cells, dict(info)


@lru_cache(maxsize=512)
def _exclude_disks(poly, exclusions, resolution, max_cells):
    pending, kept = triangulate(poly), []
    removed, refined = 0, 0
    while pending:
        cell = pending.pop()
        # Convexity: if every vertex is strictly inside one excluded disk,
        # every point of this cell is excluded. Use inward numeric margin.
        if any(all(distance(v, p) <= r-1e-7 for v in cell) for p, r in exclusions):
            removed += 1
            continue
        crosses = any(polygon_distance(list(cell), p) < r
                      for p, r in exclusions)
        span = max((distance(a, b) for a in cell for b in cell), default=0)
        if crosses and span > resolution and len(pending)+len(kept)+2 <= max_cells:
            pending.extend(split(cell))
            refined += 1
        else:
            kept.append(cell)
    return tuple(kept), dict(removed_cells=removed, refinements=refined)


@dataclass
class TriangleBelief(Belief):
    mesh_resolution: float = 40.0
    mesh_max_cells: int = 512
    cells: tuple = ()
    map_updates: int = 0
    map_info: dict = field(default_factory=dict)

    def __post_init__(self):
        self.cells = tuple(triangulate(self.polygon))

    def __deepcopy__(self, memo):
        # cells is recursively immutable: tuple of tuple of coordinate tuples.
        # All mutable observation lists, polygons and caches remain independent.
        result = type(self).__new__(type(self))
        memo[id(self)] = result
        for name, value in vars(self).items():
            setattr(result, name, value if name == 'cells' else deepcopy(value, memo))
        return result

    def rebuild(self):
        exclusions = [(p, 1000.0) for p in self.negatives]
        exclusions += [(p, 20.0) for p in self.failed_clears]
        exclusions += [(p, 5.0) for p, kind, _ in self.observations if kind == 'direction']
        cells, info = exclude_disks(self.polygon, exclusions, self.mesh_resolution,
                                    self.mesh_max_cells)
        if not cells:
            if self.state == 'found':
                raise ValueError('Empty triangle support for a detected source: inconsistent observations')
            self.state = 'absent'
            self.cells, self.polygon = (), []
            self.radius = 0.0
        else:
            self.cells = cells
            # Legacy geometry operates on a conservative hull; holes remain in
            # cells for clearance search. Rebuilding may fill holes in the hull,
            # but all exclusions are applied again, never discarded as evidence.
            self.polygon = convex_hull(v for cell in cells for v in cell)
            self.center, self.radius = enclosing_circle(self.polygon)
        self.map_updates += 1
        self.map_info = dict(info, cells=len(cells), outer_approximation=True)
        self.revision += 1
        self.sensing_cache = self.fallback_cache = None

    def observe(self, position, response, anchor_index=None):
        kind = super().observe(position, response, anchor_index)
        self.rebuild()
        return kind

    def clear_feedback(self, point, response, guaranteed=False):
        super().clear_feedback(point, response, guaranteed)
        if response['clear_result'] != 'success':
            self.rebuild()

    def certificate(self):
        return dict(super().certificate(), triangle_map=self.map_info,
                    triangle_map_updates=self.map_updates)
