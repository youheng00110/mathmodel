"""Pure numerical feedback rollouts: no HTTP, files, or official simulator.

The tail policy accepts ObservationState only.  Sampled positions are held by
RolloutWorld and may be used for generating feedback and optimistic bounds,
never for choosing the policy's next action.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import math

from .active_sensing import needs_fallback
from .geometry import clear_position, diameter, distance
from .planner import Job, coverage_next
from .posterior import PosteriorUnavailable, check_deadline
from .protocol import scan_channel_order
from .sensing import choose_local_action


@dataclass
class ObservationState:
    beliefs: dict
    anchors: list
    visited: set
    position: tuple
    receiver: int
    since_scan: int = 0

    def completed(self):
        return (sum(b.state == "cleared" for b in self.beliefs.values()) == 16
                or all(b.state in ("cleared", "absent") for b in self.beliefs.values()))


def measurement_points(belief, lateral_scale=.65):
    """Continuous geometric proposals, not a fixed global spatial grid."""
    points = [belief.center]
    length, a, b = diameter(belief.polygon)
    if length > 1e-7:
        normal = (-(b[1]-a[1])/length, (b[0]-a[0])/length)
        offset = max(25.0, min(500.0, lateral_scale*belief.radius))
        for sign in (-1, 1):
            points.append(tuple(belief.center[k]+sign*offset*normal[k] for k in (0, 1)))
    return [p for p in points
            if all(distance(p, old) > .1 for old, _, _ in belief.observations)]


def local_tail_job(belief, current, model=None):
    if belief.radius <= CLEAR_SAFE_RADIUS_M:
        point = clear_position(belief.polygon, current)
        if point is not None:
            return Job("clear", point, belief.channel, True)
    if needs_fallback(belief):
        kind, point, guaranteed, _ = choose_local_action(belief, current, 3)
        return Job(kind, point, belief.channel, guaranteed)
    points = measurement_points(belief, model.lateral_scale if model is not None else .65)
    if not points:
        kind, point, guaranteed, _ = choose_local_action(belief, current, 3)
        return Job(kind, point, belief.channel, guaranteed)
    # This deterministic rule is the fixed continuation policy.  Its ranking
    # is heuristic; SAA evaluates its complete feedback-dependent execution.
    point = min(points, key=lambda p: distance(current, p)+.2*distance(p, belief.center))
    return Job("measure", point, belief.channel)


def tail_job(state, coverage_gap=12, model=None):
    unknown = tuple(c for c, b in state.beliefs.items() if b.state == "unknown")
    scan = None
    if unknown:
        remaining = [i for i in range(len(state.anchors)) if i not in state.visited]
        if not remaining:
            raise PosteriorUnavailable("Unknown channels after complete coverage")
        index = 0 if not state.visited else coverage_next(remaining, state.anchors, state.position)
        scan = Job("scan", state.anchors[index], anchor=index, scan_channels=unknown)
        if not state.visited or state.since_scan >= coverage_gap:
            return scan
    jobs = [local_tail_job(b, state.position, model) for b in state.beliefs.values() if b.state == "found"]
    if scan is not None:
        jobs.append(scan)
    if not jobs:
        raise PosteriorUnavailable("No tail action for nonterminal state")

    def score(job):
        continuation = 0.0
        if job.kind == "measure":
            radius = state.beliefs[job.channel].radius
            weight = model.uncertainty_seconds if model is not None else 6
            continuation = weight*math.log2(max(1.0, radius/CLEAR_SAFE_RADIUS_M))
        if model is not None and model.route_weight:
            from .decision_model import future_route_distance
            continuation += model.route_weight*future_route_distance(state,job)/5
        return distance(state.position, job.point)/5+job.service(state.receiver)[0]+continuation
    return min(jobs, key=score)


class RolloutLimit(RuntimeError):
    pass


class RolloutWorld:
    def __init__(self, observation_state, scenario, max_actions=600,
                 virtual_limit=360000.0, deadline=None):
        self.state = deepcopy(observation_state)
        self._sources = {s.channel: s for s in scenario.sources}
        self._cleared = set()
        self._noise_seed = scenario.noise_seed
        self._error_model = scenario.error_model
        self._historic_readings = {}
        for c, belief in observation_state.beliefs.items():
            if belief.state == "found":
                for point, kind, angle in belief.observations:
                    self._historic_readings[c, tuple(point)] = (kind, angle)
        self.elapsed = 0.0
        self.actions = 0
        self.max_actions, self.virtual_limit, self.deadline = max_actions, virtual_limit, deadline

    def _error(self, channel, point):
        if self._error_model=='smooth':
            from .smooth_error import smooth_error
            phase = self._sources[channel].phase
            if phase is None:
                raise PosteriorUnavailable('Smooth sample has no conditional phase')
            return smooth_error(point,phase)
        point = tuple(0.0 if value == 0 else float(value) for value in point)
        key = (str(self._noise_seed)+":"+str(channel)+":"
               +float(point[0]).hex()+":"+float(point[1]).hex()).encode("ascii")
        value = int.from_bytes(hashlib.blake2b(key, digest_size=8).digest(), "big")
        return 2*(value+.5)/(2**64)-1

    def _response(self, kind, channel, point):
        source = self._sources.get(channel)
        live = source is not None and channel not in self._cleared
        d = distance(point, source.point) if live else math.inf
        if kind == "clear":
            success = live and d <= 20
            if success:
                self._cleared.add(channel)
            return {"clear_result": "success" if success else "no_target_in_range"}
        if not live or d > source.radius:
            return {"measure_result": "no_signal"}
        if d <= 5:
            return {"measure_result": "near"}
        historic = self._historic_readings.get((channel, tuple(point)))
        if historic is not None:
            kind, angle = historic
            if kind != "direction":
                raise PosteriorUnavailable("Sample inconsistent with historic visibility")
            if self._error_model=='smooth':
                predicted=round((math.degrees(math.atan2(source.point[1]-point[1],
                                                         source.point[0]-point[0]))
                                 +self._error(channel,point))%360,2)%360
                if abs((predicted-angle+180)%360-180)>1e-8:
                    raise PosteriorUnavailable('Smooth phase inconsistent with historic bearing')
        else:
            angle = round((math.degrees(math.atan2(source.point[1]-point[1],
                                                  source.point[0]-point[0]))
                           +self._error(channel, point)) % 360, 2) % 360
        return {"measure_result": "direction", "svd_deg": angle}

    def act(self, kind, point, channel, anchor=None, guaranteed=False):
        check_deadline(self.deadline)
        if self.actions >= self.max_actions:
            raise RolloutLimit("rollout_action_budget")
        point = tuple(point)
        move = distance(self.state.position, point)/5
        switch = int(kind == "measure" and channel != self.state.receiver)
        # Reserve the larger possible service cost before executing.
        if self.elapsed+move+5+switch > self.virtual_limit:
            raise RolloutLimit("rollout_virtual_budget")
        response = self._response(kind, channel, point)
        self.actions += 1
        self.state.position = point
        belief = self.state.beliefs[channel]
        if kind == "measure":
            self.elapsed += move+5+switch
            self.state.receiver = channel
            result = belief.observe(point, response, anchor)
            if result == "near":
                self.act("clear", point, channel, guaranteed=True)
            elif belief.state == "unknown" and len(belief.covered) == len(self.state.anchors):
                belief.state = "absent"
        else:
            self.elapsed += move+(5 if response["clear_result"] == "success" else 3)
            belief.clear_feedback(point, response, guaranteed)

    def execute(self, job):
        before = self.actions
        if job.kind == "scan":
            unknown = [c for c, b in self.state.beliefs.items() if b.state == "unknown"]
            for c in scan_channel_order(unknown, self.state.receiver):
                if self.state.completed():
                    break
                self.act("measure", job.point, c, job.anchor)
            self.state.visited.add(job.anchor)
            self.state.since_scan = 0
        elif job.kind == "clear_search":
            for point in job.search_points:
                if self.state.beliefs[job.channel].state == 'cleared':
                    break
                self.act('clear', point, job.channel, guaranteed=False)
            self.state.since_scan += self.actions-before
            if job.cover_certified and self.state.beliefs[job.channel].state != 'cleared':
                raise ValueError('Certified clearance cover exhausted without success')
        elif job.kind == "batch":
            for c in scan_channel_order(job.scan_channels, self.state.receiver):
                if self.state.completed():
                    break
                belief = self.state.beliefs[c]
                if belief.state in ("found","unknown") and all(distance(job.point, p) > .1
                                                    for p, _, _ in belief.observations):
                    self.act("measure", job.point, c)
            self.state.since_scan += self.actions-before
        else:
            self.act(job.kind, job.point, job.channel, guaranteed=job.guaranteed)
            self.state.since_scan += self.actions-before

    def physical_remaining_lower_bound(self):
        """Oracle relaxation: root/clearance-disk MST plus 5 s per live source.

        This method is used only for pruning numeric evaluations.  The tail
        action selector never gets the sampled true positions.
        """
        points = [s.point for c, s in self._sources.items() if c not in self._cleared]
        best = [max(0.0, distance(self.state.position, p)-20) for p in points]
        used, length = set(), 0.0
        for _ in points:
            i = min((j for j in range(len(points)) if j not in used), key=lambda j: best[j])
            used.add(i)
            length += best[i]
            for j in range(len(points)):
                if j not in used:
                    best[j] = min(best[j], max(0.0, distance(points[i], points[j])-40))
        return length/5+5*len(points)

    def finish(self, coverage_gap=12, continuation=None):
        continuation = continuation or tail_job
        while not self.state.completed():
            check_deadline(self.deadline)
            before = self.actions
            self.execute(continuation(self.state, coverage_gap))
            if self.actions == before:
                raise RolloutLimit("nonprogressing_tail")
        if len(self._cleared) != len(self._sources):
            raise PosteriorUnavailable("Sample tail declared completion with a live target")
        return self.elapsed
