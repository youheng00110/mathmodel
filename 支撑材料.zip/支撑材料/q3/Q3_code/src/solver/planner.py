"""Exact subset-DP routing for a bounded, frozen candidate task set."""

from dataclasses import dataclass

from .geometry import distance
from .protocol import scan_channel_order


@dataclass
class Job:
    kind: str
    point: tuple
    channel: int = 0
    guaranteed: bool = False
    anchor: int | None = None
    scan_channels: tuple = ()
    future_cost: float = 0.0

    def service(self, current_channel):
        if self.kind == "measure":
            return 5 + int(self.channel != current_channel), self.channel
        if self.kind == "clear":
            return (5 if self.guaranteed else 3), current_channel
        order = scan_channel_order(self.scan_channels, current_channel)
        if not order:
            return 0, current_channel
        return 5*len(order) + len(order)-1 + int(order[0] != current_channel), order[-1]


def exact_order(jobs, current, channel, terminal_cost=None):
    """Optimize all selected jobs, open path; state includes current receiver channel.

    Model: frozen action positions, frozen scan lists, expected unsuccessful
    exploratory clears. Only its first job will be executed before replanning.
    """
    n = len(jobs)
    if n == 0:
        return [], 0.0
    states = {(0, -1, channel): (0.0, ())}
    for _ in range(n):
        nxt = {}
        for (mask, last, receiver), (cost, route) in states.items():
            position = current if last == -1 else jobs[last].point
            for j, job in enumerate(jobs):
                if mask & (1 << j):
                    continue
                service, updated = job.service(receiver)
                new_cost = cost + distance(position, job.point)/5 + service
                key = mask | (1 << j), j, updated
                if key not in nxt or new_cost < nxt[key][0]:
                    nxt[key] = new_cost, route+(j,)
        states = nxt
    def objective(row):
        cost, indices = row
        return cost + (terminal_cost(jobs[indices[-1]].point) if terminal_cost else 0.0)
    cost, indices = min(states.values(), key=objective)
    cost = objective((cost, indices))
    return [jobs[i] for i in indices], cost


def nearest_order(jobs, current, channel):
    todo, route, total = list(jobs), [], 0.0
    while todo:
        job = min(todo, key=lambda j: distance(current, j.point)/5+j.service(channel)[0])
        service, channel = job.service(channel)
        total += distance(current, job.point)/5+service
        current = job.point
        route.append(job)
        todo.remove(job)
    return route, total


def frozen_route_lower_bound(jobs, current):
    """Strict lower bound for a frozen open route through every job.

    It drops receiver-channel transition costs and uses an MST plus the
    cheapest connection from the current position.  It is intentionally only
    a bound for this frozen task set; it says nothing about omitted adaptive
    tasks or future observations.
    """
    if not jobs:
        return 0.0
    points = [job.point for job in jobs]
    n = len(points)
    best = [float("inf")]*n
    used = [False]*n
    tree = 0.0
    for _ in range(n):
        j = min((i for i in range(n) if not used[i]), key=lambda i: best[i])
        used[j] = True
        tree += 0.0 if best[j] == float("inf") else best[j]
        for i in range(n):
            if not used[i]:
                best[i] = min(best[i], distance(points[j], points[i]))
    connect = min(distance(current, p) for p in points)
    # Service is optimistic: clear may succeed (5 s) or fail (3 s), and a
    # batch's channels can be ordered most favorably.  Omitting switch costs
    # keeps this a valid lower bound.
    service = sum(5 if job.kind == "measure" else
                  (3 if job.kind == "clear" and not job.guaranteed else
                   5 if job.kind == "clear" else
                   5*len(job.scan_channels)) for job in jobs)
    return (connect + tree)/5 + service


def coverage_next(indices, anchors, current, improve=True):
    """Open nearest-neighbor tour, optionally improved by segment reversals."""
    todo, route, position = list(indices), [], current
    while todo:
        i = min(todo, key=lambda i: distance(position, anchors[i]))
        route.append(i)
        todo.remove(i)
        position = anchors[i]
    if improve:
        for _ in range(20):
            changed = False
            for i in range(len(route)-1):
                before = current if i == 0 else anchors[route[i-1]]
                for j in range(i+1, len(route)):
                    a, b = anchors[route[i]], anchors[route[j]]
                    old, new = distance(before, a), distance(before, b)
                    if j+1 < len(route):
                        after = anchors[route[j+1]]
                        old += distance(b, after)
                        new += distance(a, after)
                    if new < old-1e-7:
                        route[i:j+1] = reversed(route[i:j+1])
                        changed = True
                        break
                if changed:
                    break
            if not changed:
                break
    return route[0]


def select_job(jobs, current, channel, horizon=6, policy="optimized"):
    if not jobs:
        raise ValueError("No available task")
    scans = [job for job in jobs if job.kind == "scan"]
    local = [job for job in jobs if job.kind != "scan"]
    local.sort(key=lambda j: distance(current, j.point)/5+j.service(channel)[0]+.25*j.future_cost)
    chosen = local[:max(0, horizon-len(scans))] + scans
    if not chosen:
        chosen = local[:horizon]
    route, cost = (exact_order if policy == "optimized" else nearest_order)(chosen, current, channel)
    greedy_cost = nearest_order(chosen, current, channel)[1]
    return route[0], {"horizon_jobs": len(chosen), "selected_route_cost_s": cost,
                      "greedy_same_jobs_cost_s": greedy_cost,
                      "subproblem_exact": policy == "optimized"}
