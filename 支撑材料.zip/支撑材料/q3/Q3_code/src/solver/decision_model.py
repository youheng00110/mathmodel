"""Tunable decision/continuation model. Physical rules are never parameters."""
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
from .geometry import distance


@dataclass(frozen=True)
class DecisionParameters:
    uncertainty_seconds: float = 6.0
    route_weight: float = 0.0
    lateral_scale: float = 0.65
    clear_probability_min: float = 0.0

    def __post_init__(self):
        for name,lo,hi in [('uncertainty_seconds',0,60),('route_weight',0,2),
                           ('lateral_scale',.1,1.5),('clear_probability_min',0,1)]:
            value=getattr(self,name)
            if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:
                raise ValueError(f'Invalid decision parameter {name}: expected {lo}..{hi}')

    def as_dict(self):return asdict(self)


def load_parameters(path):
    data=json.loads(Path(path).read_text())
    if type(data) is not dict or set(data)-set(DecisionParameters.__dataclass_fields__):
        raise ValueError('Decision model file must contain only declared model parameters')
    return DecisionParameters(**data).as_dict()


def clear_probability(cloud, point):
    total=sum(p.weight for p in cloud.particles)
    if total<=0:return 0.
    return sum(p.weight for p in cloud.particles if distance(point,p.point)<=20)/total


def future_route_distance(state, job):
    """One-hop distance to a DIFFERENT unfinished task, using observations only.

    Used for heuristic continuation ranking, never as a certified bound.
    """
    targets=[b.center for c,b in state.beliefs.items() if b.state=='found' and c!=job.channel]
    if any(b.state=='unknown' for b in state.beliefs.values()):
        targets += [p for i,p in enumerate(state.anchors) if i not in state.visited and i!=job.anchor]
    return min((distance(job.point,p) for p in targets),default=0.)


class ParameterizedTail:
    def __init__(self,parameters):self.parameters=parameters
    def __call__(self,state,coverage_gap=12):
        from .saa_rollout import tail_job
        return tail_job(state,coverage_gap,self.parameters)
