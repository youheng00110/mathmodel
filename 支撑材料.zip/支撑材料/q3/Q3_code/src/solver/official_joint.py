"""Joint practice-generator posterior and official predictive rollouts.

One 256-bit seed determines the ENTIRE scene. Rejection conditions on physical
history, including cleared channels, without factorizing channels or replacing
past readings. The posterior kernel is exact relative to independent uniform
seed draws and the ported generator; its finite empirical representation is NOT
an exact belief or global-optimality certificate. Long histories can exhaust
the bounded rejection budget: return no scenario set, never invented particles.
"""
from dataclasses import dataclass
from functools import lru_cache
import math
import random

from . import official_physics as physics
from .posterior import (Scenario, SampledSource, Particle, Cloud,
                        PosteriorUnavailable, PlanningTimeout, check_deadline)
from .practice_generator import generate_practice
from .saa_rollout import RolloutWorld, RolloutLimit


@dataclass(frozen=True)
class OfficialScenario(Scenario):
    generator_seed_hex: str = ''
    full_sources: tuple = ()


@lru_cache(maxsize=512)
def scene_from_seed(seed_bytes):
    raw = generate_practice(seed_bytes)
    sources = tuple(SampledSource(j['channel'], (j['x_um']/1e6,j['y_um']/1e6),
                                  j['max_receive_um']/1e6) for j in raw['jammers'])
    return OfficialScenario(sources, len(sources), int(raw['noise_seed']), 'official',
                            seed_bytes.hex(), sources)


def physical_response(source, cleared, noise_seed, kind, point):
    live = source is not None and not cleared
    d = physics.distance(point, source.point) if live else math.inf
    if kind == 'clear':
        return ('success' if live and d <= 20 else 'no_target_in_range'), None
    if kind != 'measure':
        raise ValueError('Unknown physical event')
    if not live or d > source.radius:
        return 'no_signal', None
    if d <= 5:
        return 'near', None
    return 'direction', physics.bearing(noise_seed, source.channel, source.point, point)


def validate_history_records(beliefs):
    """Reject partial/restored snapshots, instead of silently dropping evidence."""
    for b in beliefs.values():
        records = getattr(b, 'physical_history', ())
        measures = [(p, result, angle) for kind,p,result,angle in records if kind=='measure']
        failures = [p for kind,p,result,_ in records if kind=='clear' and result!='success']
        successes = sum(kind=='clear' and result=='success' for kind,_,result,_ in records)
        if measures != b.observations or failures != b.failed_clears:
            raise PosteriorUnavailable('Official posterior requires complete physical history')
        if (b.state == 'cleared') != (successes == 1) or successes > 1:
            raise PosteriorUnavailable('Missing/inconsistent successful-clear history')


def history_matches(scene, beliefs):
    """Per-channel chronology suffices: sources are static and channel-unique.

    Shared seed remains joint; every cleared channel is checked before a sample
    can be admitted. Geometric zero-particle counts never mark absence.
    """
    sources = {s.channel:s for s in scene.full_sources}
    for c,b in beliefs.items():
        source, cleared = sources.get(c), False
        for kind,point,result,angle in b.physical_history:
            predicted = physical_response(source, cleared, scene.noise_seed, kind, point)
            if predicted != (result, angle):
                return False
            if kind=='clear' and result=='success':
                cleared = True
        if b.state=='found' and (source is None or cleared):
            return False
        if b.state=='cleared' and not cleared:
            return False
        if b.state=='absent' and source is not None and not cleared:
            return False
    return True


class OfficialJointPosterior:
    error_model = 'official'

    def __init__(self, particles=256, seed=20260911):
        self.particles, self.seed = particles, seed
        self.max_draws = max(64, particles*16)
        self.last_info = {}

    def scenarios(self, beliefs, count, iteration, deadline=None):
        self.last_info = dict(model='practice-gen-v1_joint_256bit_seed',
            requested=count, proposals=0, accepted=0,
            channel_factorization=False, history_overridden=False,
            predictive_error_model='official', finite_particle_error_bound=None,
            global_optimality_certified=False,
            seed_sampler='reproducible_PRNG_uniform_bit_model',
            fallback_model='geometry_only_no_substitute_posterior')
        validate_history_records(beliefs)
        if count < 1:
            raise ValueError('Positive scenario count required')
        # Independent of the environment seed; never takes simulator truth.
        rng = random.Random(f'official-joint:{self.seed}:{iteration}')
        samples = []
        try:
            for _ in range(self.max_draws):
                check_deadline(deadline)
                raw = scene_from_seed(rng.getrandbits(256).to_bytes(32,'big'))
                self.last_info['proposals'] += 1
                if not history_matches(raw,beliefs):
                    continue
                live = tuple(s for s in raw.full_sources if beliefs[s.channel].state!='cleared')
                samples.append(OfficialScenario(live, raw.total_count, raw.noise_seed,
                               'official',raw.generator_seed_hex,raw.full_sources))
                self.last_info['accepted'] = len(samples)
                if len(samples) == count:
                    break
        except PlanningTimeout:
            self.last_info['status'] = 'rejection_timeout'
            raise
        if len(samples) != count:
            self.last_info['status'] = 'rejection_exhausted'
            raise PosteriorUnavailable(f'Official rejection accepted {len(samples)}/{count}'
                                       f' in {self.last_info["proposals"]} proposals')
        clouds = {}
        for c,b in beliefs.items():
            if b.state in ('cleared','absent'):
                continue
            pts = [Particle(s.point,s.radius,s.radius,1.)
                   for sample in samples for s in sample.sources if s.channel==c]
            clouds[c] = Cloud(pts,len(pts)/count,self.last_info['proposals'],
                              'joint_seed_rejection_empirical_marginal')
        self.last_info['status'] = 'complete_conditional_sample'
        return samples, clouds, dict(self.last_info)


class OfficialRolloutWorld(RolloutWorld):
    def __init__(self,state,scenario,*args,**kwargs):
        if not isinstance(scenario,OfficialScenario) or scenario.error_model!='official':
            raise PosteriorUnavailable('Official rollout requires joint generated scenarios')
        try:
            raw = scene_from_seed(bytes.fromhex(scenario.generator_seed_hex))
        except (ValueError,TypeError) as exc:
            raise PosteriorUnavailable('Invalid generator seed') from exc
        if (scenario.full_sources != raw.full_sources or scenario.noise_seed != raw.noise_seed
                or scenario.total_count != raw.total_count):
            raise PosteriorUnavailable('Scenario does not match its joint generator seed')
        validate_history_records(state.beliefs)
        expected_live = tuple(s for s in raw.full_sources if state.beliefs[s.channel].state!='cleared')
        if scenario.sources != expected_live or not history_matches(raw,state.beliefs):
            raise PosteriorUnavailable('Scenario does not match complete physical history')
        super().__init__(state,scenario,*args,**kwargs)
        self.virtual_us = 0

    def _error(self,channel,point):
        return physics.error_degrees(self._noise_seed,channel,point)

    def _response(self,kind,channel,point):
        result,angle = physical_response(self._sources.get(channel), channel in self._cleared,
                                         self._noise_seed,kind,point)
        if kind=='clear':
            if result=='success':
                self._cleared.add(channel)
            return {'clear_result':result}
        answer={'measure_result':result}
        if result=='direction':
            answer['svd_deg']=angle
        return answer

    def act(self,kind,point,channel,anchor=None,guaranteed=False):
        check_deadline(self.deadline)
        if self.actions >= self.max_actions:
            raise RolloutLimit('rollout_action_budget')
        point=tuple(point)
        if kind not in ('measure','clear') or not 1 <= channel <= 20 or any(
                not math.isfinite(x) or abs(x)>2000000 for x in point):
            raise ValueError('Illegal official prediction action')
        move_us=physics.movement_us(self.state.position,point)
        switch=int(kind=='measure' and channel!=self.state.receiver)
        # Same conservative virtual reserve as the live client; not a new rule.
        if self.virtual_us+move_us+(5+switch)*1000000 > self.virtual_limit*1000000:
            raise RolloutLimit('rollout_virtual_budget')
        observed=self._response(kind,channel,point)
        service=5+switch if kind=='measure' else (5 if observed['clear_result']=='success' else 3)
        self.virtual_us+=move_us+service*1000000
        self.elapsed=self.virtual_us/1000000
        self.actions+=1
        self.state.position=point
        b=self.state.beliefs[channel]
        if kind=='measure':
            self.state.receiver=channel
            result=b.observe(point,observed,anchor)
            if result=='near':
                self.act('clear',point,channel,guaranteed=True)
            elif b.state=='unknown' and len(b.covered)==len(self.state.anchors):
                b.state='absent'
        else:
            b.clear_feedback(point,observed,guaranteed)
