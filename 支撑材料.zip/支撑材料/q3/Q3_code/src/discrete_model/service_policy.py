"""Task-service-aware global routing; original joint policy remains unchanged.

Complete frozen routes are scored with local sensing/clearance costs, not only
distances between estimated target centres. Adjacent local profiles still use
representative endpoints. This is a surrogate, not an exact global belief DP.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M
import math

from solver.geometry import distance, fallback_grid
from solver.official_physics import movement_us
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from .joint_policy import JointController,JointCover
from .numerical import snap


class RecordedCover(JointCover):
    def plan(self,*args,**kwargs):
        result=super().plan(*args,**kwargs)
        self.latest=result[0]
        return result


def reliable_visit(b,start,end):
    """Optimize entry plus exit distance over the existing certified 5 m grid."""
    if b.radius>20:return None
    center=snap(b.center)
    candidates=[snap(start)]+[(center[0]+5*i,center[1]+5*j) for i in range(-4,5) for j in range(-4,5)]
    good=[p for p in candidates if math.hypot(*p)<=1820
          and all(distance(p,v)<=CLEAR_SAFE_RADIUS_M for v in b.polygon)]
    return min(good,key=lambda p:distance(start,p)+(distance(p,end) if end is not None else 0)) if good else None


class ServiceController(JointController):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.config.policy='service_grid'
        self.joint=RecordedCover(self.coverage,self.anchors)
        self.service_stats=dict(decisions=0,orders_evaluated=0,profiles_evaluated=0,
            profile_cache_hits=0,changed_actions=0,changed_first_tasks=0,predicted_savings_s=0.)
        self.profile_cache={}

    def profile(self,c,start,end,receiver,clouds,cache):
        b=self.beliefs[c]
        key=(c,tuple(b.observations),tuple(b.failed_clears),tuple(b.polygon),b.radius,b.local_measurements,
             tuple(start),tuple(end) if end is not None else None,receiver)
        if key in cache:
            self.service_stats['profile_cache_hits']+=1
            return cache[key]
        reliable=reliable_visit(b,start,end)
        if reliable is not None:
            value=movement_us(start,reliable)/1e6+5
            if end is not None:value+=movement_us(reliable,end)/1e6
            job=Job('clear',reliable,c,True)
        elif c not in clouds or len(b.failed_clears)>=8 or b.local_measurements>=10:
            points=[p for p in fallback_grid(b.polygon,25) if math.hypot(*p)<=1820
                    and all(distance(p,q)>.1 for q in b.failed_clears)]
            if not points:raise ValueError('Exhaustive clearance fallback is empty')
            first=min(points,key=lambda p:distance(start,p))
            points=[first]+sorted((p for p in points if p!=first),key=lambda p:(p[0],p[1] if round(p[0]/25)%2==0 else -p[1]))
            value=0.;previous=start
            for p in points:value+=movement_us(previous,p)/1e6+5.000002;previous=p
            if end is not None:value+=max(distance(p,end)/5 for p in points)
            job=Job('clear',first,c,False)
        else:
            value,kind,p=self.bellman.choose(b,clouds[c],start,receiver,end)
            job=Job(kind,p,c,False)
        self.service_stats['profiles_evaluated']+=1
        if len(cache)>=4096:cache.pop(next(iter(cache)))
        cache[key]=(value,job)
        return value,job

    def evaluate(self,path,tasks,unknown,clouds,cache):
        """Route length + service corrections: every centre edge counted once."""
        points=[tasks[i][2] for i in path]
        current=self.client.position;receiver=self.client.channel
        length=distance(current,points[0])+sum(distance(a,b) for a,b in zip(points,points[1:]))
        total=length/5;first_job=None
        for k,index in enumerate(path):
            kind,c,point=tasks[index]
            before=current if k==0 else points[k-1]
            after=points[k+1] if k+1<len(points) else None
            if kind=='scan':
                total+=max(0,6*unknown-1)
                job=Job('scan',point,anchor=self.anchors.index(point) if point in self.anchors else None)
            else:
                cost,job=self.profile(c,before,after,receiver,clouds,cache)
                total+=cost-distance(before,point)/5-(distance(point,after)/5 if after is not None else 0)
                if job.kind=='measure':receiver=c
            if first_job is None:first_job=job
        self.service_stats['orders_evaluated']+=1
        return total,first_job

    def next_job(self):
        prior=self.joint_stats['plans']
        original=super().next_job()
        # Leave initial scan, nearby certified clears, the locked certificate
        # and the bounded-progress scan guard under the original controller.
        if self.joint_stats['plans']==prior or self.locked is not None:return original
        plan=self.joint.latest;unknown=sum(b.state=='unknown' for b in self.beliefs.values())
        if unknown and self.since_scan>=18:return original
        clouds={};tasks=[]
        for c,b in self.beliefs.items():
            if b.state!='found':continue
            try:clouds[c]=self.posterior.cloud(b);point=snap(clouds[c].mean)
            except PosteriorUnavailable:point=snap(b.center)
            tasks.append(('target',c,point))
        tasks.extend(('scan',None,p) for p in sorted(plan['scans']))
        if len(tasks)<2:return original
        # Preserve distinct channels even when their representative points coincide.
        reference=sorted(range(len(tasks)),key=lambda i:(plan['path'].index(tasks[i][2]),tasks[i][0]!='scan'))
        orders=[reference]
        # Full remaining routes, with alternative early task choices. This is
        # bounded deterministic search; no hidden scene or execution seed used.
        for first in reference[:4]:
            rest=[i for i in reference if i!=first]
            ordered,_=self.joint.ordered([tasks[i][2] for i in rest],tasks[first][2])
            rank={p:j for j,p in enumerate(ordered)}
            orders.append([first]+sorted(rest,key=lambda i:rank[tasks[i][2]]))
        orders.append(list(reversed(reference)))
        orders=list(dict.fromkeys(tuple(p) for p in orders));cache=self.profile_cache
        values=[self.evaluate(order,tasks,unknown,clouds,cache) for order in orders]
        choice=min(range(len(values)),key=lambda i:values[i][0]);value,job=values[choice]
        # Retain the original route when its service score is within 1 s.
        if value>=values[0][0]-1:choice=0;value,job=values[0]
        self.joint_stats['scan_jobs']+=int(job.kind=='scan')-int(original.kind=='scan')
        self.service_stats['decisions']+=1
        self.service_stats['changed_actions']+=(job.kind,job.channel,job.point)!=(original.kind,original.channel,original.point)
        self.service_stats['changed_first_tasks']+=orders[choice][0]!=orders[0][0]
        self.service_stats['predicted_savings_s']+=max(0,values[0][0]-value)
        self.client.record('service_routing',tasks=tasks,orders=orders,values=[v[0] for v in values],
            chosen=choice,job=job.__dict__,baseline_job=original.__dict__,global_optimality_certified=False)
        return job

    def run(self):
        result=super().run();result['strategy_version']='service-grid-v1'
        result['service_routing']=dict(**self.service_stats,global_optimality_certified=False,
            approximation='local sensing/clearance service corrections on complete frozen routes; representative entry/exit points')
        self.client.record('service_summary',summary=result)
        return result
