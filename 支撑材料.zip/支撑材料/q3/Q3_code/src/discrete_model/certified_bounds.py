"""Distribution-free Q3 practice bounds and an executable geometric fallback.

Requires the audited 1800 m source disk, omnidirectional 1000..1500 m reception,
bounded bearings including rounding, and legal accepted actions. Bounds concern
virtual time, not network latency. No sampled scene is used here.
"""
from functools import lru_cache
import math
import numpy as np

from solver.geometry import distance,polygon_distance
from solver.official_physics import movement_us
from solver.planner import Job
from .numerical import snap


def counts(beliefs):
    k=sum(b.state=='cleared' for b in beliefs.values())
    d=sum(b.state=='found' for b in beliefs.values())
    u=sum(b.state=='unknown' for b in beliefs.values())
    return k,max(10,k+d),min(16,k+d+u)


def polygon_gap(a,b):
    """Euclidean distance of two convex polygons; overlap tested by SAT."""
    a=np.asarray(a,float);b=np.asarray(b,float)
    edges=np.concatenate((np.roll(a,-1,axis=0)-a,np.roll(b,-1,axis=0)-b))
    axes=np.column_stack((-edges[:,1],edges[:,0]));length=np.linalg.norm(axes,axis=1)
    axes=axes[length>1e-12]/length[length>1e-12,None]
    pa=a@axes.T;pb=b@axes.T
    if np.all(np.maximum(pa.min(axis=0)-pb.max(axis=0),pb.min(axis=0)-pa.max(axis=0))<=1e-8):return 0.
    def point_segments(p,poly):
        q=np.roll(poly,-1,axis=0);v=q-poly;den=np.sum(v*v,axis=1)
        t=np.clip(np.sum((p[:,None,:]-poly)*v,axis=2)/np.maximum(den,1e-30),0,1)
        return float(np.linalg.norm(p[:,None,:]-(poly+t[:,:,None]*v),axis=2).min())
    return max(0.,min(point_segments(a,b),point_segments(b,a))-1e-6)


def physical_lower(beliefs,start,elapsed=0.):
    remaining=[b for b in beliefs.values() if b.state=='found']
    k,nmin,nmax=counts(beliefs)
    if nmax<nmin:raise ValueError('Inconsistent source count')
    n=len(remaining)
    first=[max(0.,polygon_distance(b.polygon,start)-20-1e-6) for b in remaining]
    edges=[[max(0.,polygon_gap(a.polygon,b.polygon)-40) if i!=j else 0.
            for j,b in enumerate(remaining)] for i,a in enumerate(remaining)]
    @lru_cache(None)
    def dp(mask,last):
        if not mask:return 0.
        return min(edges[last][j]+dp(mask^(1<<j),j) for j in range(n) if mask>>j&1)
    length=min((first[i]+dp(((1<<n)-1)^(1<<i),i) for i in range(n)),default=0.)
    # A non-success action's >=3 s service absorbs its movement rounding error.
    # Only <=16 successful actions need a separate microsecond allowance.
    move=max(0.,length/5-.001)
    return dict(remaining_time_lower_s=move+5*(nmin-k),
        conditional_total_per_target_lower=min((elapsed+move+5*(n-k))/n for n in range(nmin,nmax+1)),
        route_distance_lower_m=length,total_count_min=nmin,total_count_max=nmax,
        bound_scope='true geometry relaxation; no posterior weights; conservative numerical allowance')


def sector_cover(belief):
    """At most 380 snapped points cover every possible live source.

    A positive bearing implies local x in [0,1500], |y|<27. The 20 m rotated
    lattice has covering radius sqrt(200); 5 m snapping adds sqrt(12.5), so
    total <17.68<20. A needed point has norm <=1800+17.68<1820.
    """
    near=next((p for p,kind,_ in belief.observations if kind=='near'),None)
    if near is not None:return [snap(near)]
    obs=next(((p,angle) for p,kind,angle in belief.observations if kind=='direction'),None)
    if obs is None:raise ValueError('Fallback clearance requires a positive observation')
    origin,angle=obs;t=math.radians(angle);e=(math.cos(t),math.sin(t));normal=(-e[1],e[0])
    points=[]
    for row,y in enumerate((-40,-20,0,20,40)):
        for x in (range(0,1501,20) if row%2==0 else range(1500,-1,-20)):
            p=snap((origin[0]+x*e[0]+y*normal[0],origin[1]+x*e[1]+y*normal[1]))
            if math.hypot(*p)<=1820 and p not in points:points.append(p)
    if not points:raise ValueError('Empty sector fallback')
    return points


def fallback_upper(beliefs,anchors,visited,start):
    """Fixed anchor order, then sector covers in channel order.

    Per target: incoming distance <=5120 m; full snapped serpentine <=
    7580+379*sqrt(50) m; at most 380 clears costing <=5 s each. Total <5000 s.
    Skipping outside-disk points or stopping on success only shortens the path.
    """
    k,_,nmax=counts(beliefs);unknown=sum(b.state=='unknown' for b in beliefs.values())
    pending=[p for i,p in enumerate(anchors) if i not in visited] if unknown else []
    travel=0.;p=start
    for q in pending:travel+=movement_us(p,q)/1e6+.000002;p=q
    return dict(remaining_upper_s=travel+6*unknown*len(pending)+5000*(nmax-k),
        actions_upper=unknown*len(pending)+380*(nmax-k),
        scope='executable fixed-anchor then complete-sector policy; virtual time only')


class GeometricFallback:
    def __init__(self):self.sequences={}

    def job(self,beliefs,anchors,visited):
        unknown=tuple(c for c,b in beliefs.items() if b.state=='unknown')
        if unknown:
            i=next((i for i in range(len(anchors)) if i not in visited),None)
            if i is None:raise ValueError('Unknown after complete anchor cover')
            return Job('scan',anchors[i],anchor=i,scan_channels=unknown)
        for c,b in sorted(beliefs.items()):
            if b.state!='found':continue
            if c not in self.sequences:self.sequences[c]=sector_cover(b)
            while self.sequences[c] and any(distance(self.sequences[c][0],q)<.1 for q in b.failed_clears):
                self.sequences[c].pop(0)
            if not self.sequences[c]:raise ValueError('Certified sector exhausted')
            return Job('clear',self.sequences[c].pop(0),c,False)
        raise ValueError('Fallback requested after completion')
