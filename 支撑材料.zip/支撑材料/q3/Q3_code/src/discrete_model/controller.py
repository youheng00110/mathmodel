"""Grid SSP numerical policy; uses the existing audited transport only."""
from solver.parameters import CLEAR_SAFE_RADIUS_M, COVERAGE_RADIUS_M
import math
import random
import numpy as np

from solver.belief import Belief
from solver.controller import Controller, Config
from solver.geometry import disk_polygon, distance, fallback_grid
from solver.planner import Job
from solver.posterior import PosteriorUnavailable, count_distribution, observation_kernel
from solver.protocol import BudgetExpired, scan_channel_order
from .model import Model, Action
from .numerical import Posterior, LocalBellman, snap, route
from .coverage import Coverage


class GridController(Controller):
    def __init__(self, client, progress=None, *, quadrature=128, bin_deg=.5,
                 route_trials=3, radius=COVERAGE_RADIUS_M, adaptive_coverage=False):
        super().__init__(client, Config(problem=3, policy='grid_bellman'), progress)
        # Snapping displaces a point by at most 5/sqrt(2). Include this in
        # the analytic disk-cover proof before using coverage as a certificate.
        worst = max(radius/math.sqrt(3), math.sqrt(1800**2+radius**2-1800*math.sqrt(3)*radius))
        if worst+5/math.sqrt(2) >= 1000:
            raise ValueError('Snapped coverage ring lacks a coverage certificate')
        self.anchors = [(0.,0.)]+[snap((radius*math.cos(k*math.pi/3),radius*math.sin(k*math.pi/3)))
                                  for k in range(6)]
        self.beliefs = {c: Belief(c, polygon=disk_polygon(radius=1800), radius=1800) for c in range(1,21)}
        self.grid = Model()
        self.posterior = Posterior(quadrature)
        self.bellman = LocalBellman(bin_deg)
        self.route_trials = route_trials
        self.adaptive_coverage = adaptive_coverage
        self.coverage = Coverage(self.anchors)
        self.coverage_bound = worst+5/math.sqrt(2)
        self.numerical_stats = {'numerical_decisions':0, 'geometric_fallbacks':0,
                                'conditional_measurement_evaluations':0}
        self.last_count = None

    def validate(self, kind, channel, p):
        if tuple(p) != snap(p):
            raise ValueError('Numerical policy attempted an off-grid action')
        self.grid.validate_action(Action(kind,int(p[0]/5),int(p[1]/5),channel))
        # Client additionally reserves exit time and checks server budget.
        from solver.official_physics import movement_us
        cost = movement_us(self.client.position,p)/1e6+5+int(kind=='measure' and channel!=self.client.channel)
        if self.client.virtual_s+cost > self.client.max_virtual_s:
            raise BudgetExpired('grid_action_virtual_budget')

    def measure(self, channel, position, anchor=None):
        self.validate('measure',channel,position)
        if self.actions >= self.config.max_actions:
            raise BudgetExpired('action_cap')
        response = self.client.act('/measure',position,channel)
        self.actions += 1
        b = self.beliefs[channel]
        b.observe(position,response,anchor)
        # Near remains an observation. The next decision is free to clear it.
        if b.state=='unknown' and len(b.covered)==len(self.anchors):
            b.state='absent'
        return response

    def clear(self, channel, position, guaranteed=False):
        self.validate('clear',channel,position)
        return super().clear(channel,position,guaranteed)

    def scan(self, job):
        for c in scan_channel_order([c for c,b in self.beliefs.items() if b.state=='unknown'],self.client.channel):
            if self.completed():
                break
            self.measure(c,job.point,job.anchor)
        if job.anchor is not None:
            self.visited.add(job.anchor)
        self.coverage.observe_scan(job.point)
        if self.coverage.remaining == 0:
            for b in self.beliefs.values():
                if b.state=='unknown': b.state='absent'
        self.since_scan=0

    def reliable_clear(self, b, current):
        if b.radius > 20:
            return None
        center = snap(b.center)
        points = [snap(current)]+[(center[0]+5*i,center[1]+5*j) for i in range(-4,5) for j in range(-4,5)]
        good = [p for p in points if math.hypot(*p)<=1820
                and all(distance(p,v)<=CLEAR_SAFE_RADIUS_M for v in b.polygon)]
        return min(good,key=lambda p:distance(current,p)) if good else None

    def fallback(self, b):
        self.numerical_stats['geometric_fallbacks'] += 1
        if b.fallback_cache is None:
            b.fallback_cache = [p for p in fallback_grid(b.polygon,25)
                                if math.hypot(*p)<=1820]
        todo = [p for p in b.fallback_cache
                if all(distance(p,q)>.1 for q in b.failed_clears)]
        if not todo:
            raise ValueError('Geometric grid cover exhausted without a successful clearance')
        return Job('clear',min(todo,key=lambda p:distance(p,self.client.position)),b.channel,False)

    def inverse_count(self):
        known=sum(b.state in ('found','cleared') for b in self.beliefs.values())
        unknown=[b for b in self.beliefs.values() if b.state=='unknown']
        # This count approximation is used only to scale the surrogate value.
        # It must never certify that an unknown channel is absent.
        rng=random.Random(911)
        points=[]
        for _ in range(512):
            r=1800*math.sqrt(rng.random()); angle=rng.random()*2*math.pi
            points.append((r*math.cos(angle),r*math.sin(angle)))
        weights=[sum(observation_kernel(b,p)[0] for p in points)/len(points) for b in unknown]
        try:
            counts,_=count_distribution(known,weights)
        except PosteriorUnavailable:
            counts={n:1 for n in range(max(10,known),min(16,known+len(unknown))+1)}
            if not counts:
                raise ValueError('Observed count incompatible with practice model')
            counts={n:p/sum(counts.values()) for n,p in counts.items()}
        self.last_count=counts
        return sum(p/n for n,p in counts.items())

    def next_job(self):
        self.planning_calls+=1
        current=self.client.position
        unknown=tuple(c for c,b in self.beliefs.items() if b.state=='unknown')
        if not self.visited and unknown:
            return Job('scan',self.anchors[0],anchor=0,scan_channels=unknown)
        found=[b for b in self.beliefs.values() if b.state=='found']
        needed=[i for i in range(7) if i not in self.visited]
        if unknown and self.adaptive_coverage:
            alternatives=self.coverage.subsets(needed)
            # Scan here only when it removes at least one necessary anchor
            # from this conservative finite cover model. This is a policy
            # restriction, not a proof of globally optimal search placement.
            gain_mask=self.coverage.remaining & self.coverage.mask(current)
            after=self.coverage.remaining & ~gain_mask
            best_anchor_gain=max((self.coverage.remaining & self.coverage.anchor_masks[i]).bit_count()
                                 for i in needed)
            substantial=(gain_mask.bit_count()>=.55*best_anchor_gain
                         and gain_mask.bit_count()>0
                         and all(distance(current,p)>=250 for p in self.coverage.scanned))
            if (tuple(current) not in self.coverage.scanned
                    and (substantial or len(self.coverage.subsets(needed,after)[0])<len(alternatives[0]))):
                return Job('scan',current,anchor=None,scan_channels=unknown)
            reference=[b.center for b in found]
            needed=list(min(alternatives,key=lambda sub:route(reference+[self.anchors[i] for i in sub],current)[1]))
        for b in found:
            reliable=self.reliable_clear(b,current)
            if reliable is not None and distance(reliable,current)<25:
                return Job('clear',reliable,b.channel,True)
        tasks=[]; clouds={}
        for b in found:
            try:
                clouds[b.channel]=self.posterior.cloud(b)
                center=snap(clouds[b.channel].mean)
            except PosteriorUnavailable:
                center=snap(b.center)
            tasks.append(('target',b.channel,center))
        if unknown:
            tasks.extend(('scan',i,self.anchors[i]) for i in needed)
        if not tasks:
            raise ValueError('No task for a nonterminal grid state')
        points=[t[2] for t in tasks]
        order,_=route(points,current)
        choices=order[:max(1,self.route_trials)]
        # Bounded progress restriction for completion; explicitly not claimed
        # to be an optimality-preserving pruning of the original SSP.
        if unknown and self.since_scan>=18:
            choices=[next(i for i in order if tasks[i][0]=='scan')]
        best=None
        for i in choices:
            kind,index,point=tasks[i]
            remaining=[j for j in range(len(tasks)) if j!=i]
            tail,tail_length=route([points[j] for j in remaining],point)
            end=points[remaining[tail[0]]] if tail else None
            if end is not None:
                tail_length-=distance(point,end)
            if kind=='scan':
                # Unknown-source future work is part of the approximate
                # terminal value, not a clairvoyant path through hidden truth.
                value=distance(current,point)/5+6*len(unknown)-1
                if end is not None: value+=distance(point,end)/5
                job=Job('scan',point,anchor=index,scan_channels=unknown)
            else:
                b=self.beliefs[index]
                reliable=self.reliable_clear(b,current)
                if reliable is not None:
                    value=distance(current,reliable)/5+5+(distance(reliable,end)/5 if end else 0)
                    job=Job('clear',reliable,index,True)
                elif index not in clouds or len(b.failed_clears)>=8 or b.local_measurements>=10:
                    job=self.fallback(b)
                    value=distance(current,job.point)/5+5+(distance(job.point,end)/5 if end else 0)
                else:
                    value,action,p=self.bellman.choose(b,clouds[index],current,self.client.channel,end)
                    job=Job(action,p,index,False)
            value+=tail_length/5
            if best is None or value<best[0]:
                best=value,job
        inverse=self.inverse_count()
        self.numerical_stats['numerical_decisions']+=1
        self.numerical_stats['conditional_measurement_evaluations']=self.bellman.evaluations
        self.client.record('grid_planning',job=best[1].__dict__,surrogate_s_per_target=best[0]*inverse,
                           count_posterior=self.last_count,global_optimality_certified=False)
        return best[1]

    def run(self):
        result=super().run()
        result.update(strategy_version='grid-bellman-v2',
            numerical_model=dict(grid_m=5,objective='E[T/N]',
                approximation='geometric quadrature; Gaussian official-field covariance; coarsened observations; route/clear-cover terminal value',
                exact_seed_posterior=False,global_optimality_certified=False,
                full_grid_search=False,coverage_bound_m=self.coverage_bound,
                quadrature=self.posterior.size,observation_bin_deg=self.bellman.bin_deg,
                route_trials=self.route_trials,**self.numerical_stats,
                adaptive_coverage=self.adaptive_coverage,
                coverage_triangles=len(self.coverage.vertices),
                coverage_triangles_remaining=self.coverage.remaining.bit_count(),
                scan_locations=len(self.coverage.scanned),
                posterior_depletions=self.posterior.depletions))
        return result
