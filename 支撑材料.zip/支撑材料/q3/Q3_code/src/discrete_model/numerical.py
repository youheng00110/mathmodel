"""Executable approximation of the grid SSP, never an exact seed posterior.

History is compressed to conservative geometry and spatial quadrature. The
official 150 m interpolation covariance is retained, with a Gaussian closure
for its bounded latent vertex values. Branches use coarsened angle bins. The
terminal value is an adaptive replanned route/clear-cover surrogate, NOT a
certified bound on the complete problem. Actual costs and safe geometry remain
separate from these numerical approximations.
"""
from dataclasses import dataclass
import math
import random
import numpy as np

from solver.geometry import distance, polygon_distance
from solver.posterior import polygon_sampler, observation_kernel, PosteriorUnavailable
from solver.official_physics import movement_us
from .model import Model, Action


def snap(p):
    return tuple(5 * round(float(x) / 5) for x in p)


def field_weights(p):
    x, y = p[0]/150, p[1]/150
    ix, iy = math.floor(x), math.floor(y)
    u, v = x-ix, y-iy
    u, v = u*u*(3-2*u), v*v*(3-2*v)
    return {(ix, iy): (1-u)*(1-v), (ix+1, iy): u*(1-v),
            (ix, iy+1): (1-u)*v, (ix+1, iy+1): u*v}


def field_covariance(a, b):
    return sum(v*b.get(k, 0) for k, v in a.items())/3


@dataclass
class Quadrature:
    points: np.ndarray
    weights: np.ndarray
    low: np.ndarray
    high: np.ndarray
    history_weights: list
    inverse: np.ndarray
    residuals: np.ndarray

    @property
    def mean(self):
        return tuple(self.weights @ self.points)

    def prediction(self, p):
        fw = field_weights(p)
        k = np.array([field_covariance(fw, w) for w in self.history_weights])
        coefficients = k @ self.inverse
        mean = self.residuals @ coefficients
        var = max(1e-5, field_covariance(fw, fw)-coefficients @ k)
        return mean, math.sqrt(var)


class Posterior:
    def __init__(self, size=128):
        self.size = size
        self.cache = {}
        self.depletions = 0

    def cloud(self, b):
        key = (tuple(b.observations), tuple(b.failed_clears))
        if b.channel in self.cache and self.cache[b.channel][0] == key:
            return self.cache[b.channel][1]
        directions = list(dict.fromkeys((p, angle) for p, kind, angle in b.observations
                                       if kind == 'direction'))
        hweights = [field_weights(p) for p, _ in directions]
        covariance = np.array([[field_covariance(a, c) for c in hweights] for a in hweights])
        covariance += np.eye(len(directions)) * (.01**2/12 + 1e-8)
        inverse = np.linalg.pinv(covariance)
        draw = polygon_sampler(b.polygon)
        rng = random.Random(f'grid-ssp:{b.channel}:{key}')
        points, lows, highs, logs, residuals = [], [], [], [], []
        for _ in range(max(1024, 8*self.size)):
            p = draw(rng)
            if math.hypot(*p) > 1800:
                continue
            weight, lo, hi = observation_kernel(b, p, include_angle_weight=False)
            if weight <= 0:
                continue
            residual = np.array([(angle-math.degrees(math.atan2(p[1]-q[1], p[0]-q[0]))+180)%360-180
                                 for q, angle in directions])
            log = math.log(weight)-.5*float(residual @ inverse @ residual)
            points.append(p); lows.append(lo); highs.append(hi)
            logs.append(log); residuals.append(residual)
        if not points:
            self.depletions += 1
            raise PosteriorUnavailable('Grid quadrature empty; use geometric coverage')
        weights = np.exp(np.array(logs)-max(logs))
        weights /= weights.sum()
        # Fixed stratified quadrature; it is not the full seed information set.
        indices = np.searchsorted(np.cumsum(weights), (np.arange(self.size)+.5)/self.size)
        indices, counts = np.unique(indices, return_counts=True)
        cloud = Quadrature(np.asarray(points)[indices], counts/self.size,
                           np.asarray(lows)[indices], np.asarray(highs)[indices],
                           hweights, inverse, np.asarray(residuals)[indices])
        self.cache[b.channel] = key, cloud
        return cloud


def route(points, start):
    """Multistart open route and 2-opt. This is a value approximation."""
    if not points:
        return [], 0.0
    matrix = np.linalg.norm(np.asarray(points)[:, None, :]-np.asarray(points)[None, :, :], axis=2)
    first = np.linalg.norm(np.asarray(points)-start, axis=1)
    best = None
    for root in np.argsort(first)[:min(4, len(points))]:
        path = [int(root)]; todo = set(range(len(points)))-{int(root)}
        while todo:
            j = min(todo, key=lambda j: matrix[path[-1], j])
            path.append(j); todo.remove(j)
        for _ in range(12):
            changed = False
            for i in range(len(path)-1):
                for j in range(i+1, len(path)):
                    old = first[path[i]] if i == 0 else matrix[path[i-1], path[i]]
                    new = first[path[j]] if i == 0 else matrix[path[i-1], path[j]]
                    if j+1 < len(path):
                        old += matrix[path[j], path[j+1]]
                        new += matrix[path[i], path[j+1]]
                    if new < old-1e-7:
                        path[i:j+1] = reversed(path[i:j+1]); changed = True
            if not changed:
                break
        length = first[path[0]]+sum(matrix[a,b] for a,b in zip(path,path[1:]))
        if best is None or length < best[1]:
            best = path, float(length)
    return best


class LocalBellman:
    """One measurement lookahead, feedback-dependent finite clearance covers.

    All branches choose their own continuation from observable bins. They do
    not choose a route knowing the individual sampled true target. Values are
    approximate total seconds; normalization is handled by the controller.
    """
    def __init__(self, bin_deg=.5):
        self.bin_deg = bin_deg
        self.model = Model()
        self.evaluations = 0

    @staticmethod
    def cover(points, weights, start, end=None):
        mass = float(weights.sum())
        if mass <= 1e-12:
            return 0.0, None
        candidates = np.unique(np.round(points/5)*5, axis=0)
        inside = np.linalg.norm(candidates[:,None,:]-points[None,:,:], axis=2) <= 20
        live = weights.copy()
        cost = 0.0; position = np.array(start); first = None
        for _ in range(len(points)):
            remaining = float(live.sum())
            if remaining < 1e-12:
                break
            covered = inside @ live
            moves = np.linalg.norm(candidates-position, axis=1)/5
            rank = covered/(moves+3)
            i = int(np.argmax(rank))
            if covered[i] <= 0:
                raise ValueError('Finite cover did not cover quadrature')
            if first is None:
                first = tuple(candidates[i])
            # All surviving scenarios pay movement and failure service; a
            # success costs another 2 s and then leaves toward the next task.
            cost += remaining*(movement_us(tuple(position), tuple(candidates[i]))/1e6+3)+2*covered[i]
            if end is not None:
                cost += covered[i]*movement_us(tuple(candidates[i]), end)/1e6
            live[inside[i]] = 0
            position = candidates[i]
        return cost/mass, first

    def measurement(self, cloud, p, start, receiver, channel, end):
        d = np.linalg.norm(cloud.points-p, axis=1)
        visible = np.clip((cloud.high-d)/np.maximum(1e-9, cloud.high-cloud.low), 0, 1)
        angle = np.degrees(np.arctan2(cloud.points[:,1]-p[1], cloud.points[:,0]-p[0]))
        mean, sigma = cloud.prediction(p)
        branches = {}
        for offset, weight in ((-math.sqrt(3), 1/6), (0, 2/3), (math.sqrt(3), 1/6)):
            error = np.clip(mean+offset*sigma, -1, 1)
            # Quantization is modelled before observation aggregation.
            observed = np.round((angle+error)*100)/100 % 360
            bins = np.floor(observed/self.bin_deg).astype(int)
            bins[d <= 5] = -2
            for bucket in np.unique(bins):
                branch = branches.setdefault(int(bucket), np.zeros(len(d)))
                branch += cloud.weights*visible*weight*(bins == bucket)
        branches[-1] = cloud.weights*(1-visible)
        value = movement_us(start, p)/1e6+5+int(channel != receiver)
        for weights in branches.values():
            selected = weights > 1e-12
            if np.any(selected):
                cost, _ = self.cover(cloud.points[selected], weights[selected], p, end)
                value += float(weights.sum())*cost
        return value

    def choose(self, b, cloud, start, receiver, end=None, measure_enabled=True):
        direct, first = self.cover(cloud.points, cloud.weights, start, end)
        best = (direct, 'clear', first)
        if not measure_enabled:
            return best
        center = np.array(cloud.mean)
        values, vectors = np.linalg.eigh(np.cov(cloud.points.T, aweights=cloud.weights)
                                          if len(cloud.points)>1 else np.eye(2))
        lateral = vectors[:,0]
        candidates = [snap(center), snap(start)]
        for scale in (.2, .45, .8):
            offset = max(25, min(400, b.radius*scale))
            candidates += [snap(center+sign*offset*lateral) for sign in (-1,1)]
        candidates += [snap(np.array(start)+t*(center-start)) for t in (.5,.8)]
        if end is not None:
            candidates += [snap(center+.2*(np.array(end)-center))]
        for p in dict.fromkeys(candidates):
            if any(distance(p, q)<.1 for q,_,_ in b.observations):
                continue
            self.model.validate_action(Action('measure', int(p[0]/5), int(p[1]/5), b.channel))
            value = self.measurement(cloud, p, start, receiver, b.channel, end)
            self.evaluations += 1
            if value < best[0]:
                best = value, 'measure', p
        return best
