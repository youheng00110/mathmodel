"""Joint cover/target routing with conservative geometric budget certificates.

The objective proxy includes ALL remaining coverage sites. Its route optimizer
retains the fixed-ring incumbent, so its frozen proxy cannot get worse. That
is not a guarantee of improved expected online completion time. An actual
200 s/source certificate is issued only for a locked, exhaustive clearance
policy after all channels' existence has been resolved.
"""
from solver.parameters import COVERAGE_RADIUS_M
import math
import numpy as np

from solver.geometry import distance, fallback_grid
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from solver.official_physics import movement_us
from .controller import GridController
from .numerical import snap, route
from .coverage import Coverage


class JointCover:
    def __init__(self, coverage, anchors):
        self.coverage=coverage
        self.anchors=anchors
        self.cache={tuple(p):mask for p,mask in zip(anchors,coverage.anchor_masks)}
        self.lattice=[snap((r*math.cos(k*math.pi/12),r*math.sin(k*math.pi/12)))
                      for r in (COVERAGE_RADIUS_M,1250,1400) for k in range(24)]

    def mask(self,p):
        p=tuple(p)
        if p not in self.cache:self.cache[p]=self.coverage.mask(p)
        return self.cache[p]

    @staticmethod
    def insertion(path,point,current):
        best=None
        for i in range(len(path)+1):
            before=current if i==0 else path[i-1]
            cost=distance(before,point)
            if i<len(path):cost+=distance(point,path[i])-distance(before,path[i])
            if best is None or cost<best[0]:best=(cost,i)
        return best

    @staticmethod
    def ordered(points,current):
        points=list(dict.fromkeys(points))
        order,length=route(points,current)
        return [points[i] for i in order],length

    def plan(self,current,targets,unknown,visited,pending=None):
        mandatory=list(dict.fromkeys(tuple(p) for p in targets))
        required=self.coverage.remaining if unknown else 0
        service=max(0,6*unknown-1)

        def evaluate(scans):
            scans=set(scans)
            path,length=self.ordered(mandatory+list(sorted(scans)),current)
            return dict(path=path,scans=scans,value=length/5+service*len(scans),length=length)

        anchors=[tuple(p) for i,p in enumerate(self.anchors) if i not in visited]
        incumbent=evaluate((anchors if pending is None else pending) if required else [])
        original=incumbent['value']
        if not required:return incumbent,original
        candidates=list(dict.fromkeys([tuple(current),*mandatory,*anchors,*self.lattice]))
        masks={p:self.mask(p)&required for p in candidates}
        candidates=[p for p in candidates if masks[p]]
        for power in ((1.,.7) if pending is None else ()):
            remaining=required; scans=[];path,_=self.ordered(mandatory,current)
            while remaining:
                best=None
                for p in candidates:
                    gain=(remaining&masks[p]).bit_count()
                    if not gain:continue
                    insertion,index=self.insertion(path,p,current) if p not in path else (0,path.index(p))
                    ratio=(service+insertion/5)/(gain**power)
                    if best is None or ratio<best[0]:best=(ratio,p,index)
                if best is None:raise ValueError('Finite cover candidates lost the fallback cover')
                _,point,index=best
                scans.append(point)
                if point not in path:path.insert(index,point)
                remaining &= ~masks[point]
            # Remove scans whose triangles are also covered by the other scans.
            for p in list(reversed(scans)):
                union=0
                for q in scans:
                    if q!=p:union |= masks[q]
                if not required & ~union:scans.remove(p)
            candidate=evaluate(scans)
            if candidate['value']<incumbent['value']:incumbent=candidate
        union=0
        for p in incumbent['scans']:union|=self.mask(p)
        if required&~union:raise ValueError('Invalid joint coverage certificate')
        # For each scan point, the triangles uniquely assigned to it impose
        # an intersection of 1000 m disks centred at their vertices. Search
        # that convex feasible region on the actual 5 m action lattice.
        scans=set(incumbent['scans'])
        path=list(incumbent['path'])
        for original_point in list(path):
            if original_point not in scans or original_point in mandatory:continue
            other=0
            for q in scans:
                if q!=original_point:other|=self.mask(q)
            exclusive=required&~other
            raw=exclusive.to_bytes((len(self.coverage.vertices)+7)//8,'little')
            selected=np.unpackbits(np.frombuffer(raw,dtype=np.uint8),bitorder='little')[:len(self.coverage.vertices)].astype(bool)
            vertices=self.coverage.vertices[selected].reshape((-1,2))
            if not len(vertices):continue
            i=path.index(original_point)
            before=current if i==0 else path[i-1]
            after=path[i+1] if i+1<len(path) else None
            def length(p):return distance(before,p)+(distance(p,after) if after is not None else 0)
            point=original_point
            for step in (200,100,50,25,10,5):
                options=[tuple(current),*mandatory]+[(point[0]+step*dx,point[1]+step*dy)
                         for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))]
                for q in sorted(options,key=length):
                    if math.hypot(*q)>3300 or length(q)>=length(point)-1e-7:continue
                    if np.max(np.sum((vertices-q)**2,axis=1))<999.9999**2:
                        point=q;break
            scans.remove(original_point);scans.add(point);path[i]=point
        refined=evaluate(scans)
        if refined['value']<incumbent['value']:incumbent=refined
        union=0
        for p in incumbent['scans']:union|=self.mask(p)
        if required&~union:raise ValueError('Coordinate refinement lost coverage')
        return incumbent,original


def clearance_certificate(controller,target=200):
    """Explicit safe continuation; no hidden-position sample is used.

    Once existence is resolved, cover each remaining convex outer region by
    25 m grid clear-disks. On success skip that channel's remaining points.
    Triangle inequality plus a microsecond margin bounds all such shortcuts.
    This certificate is only claimed if the controller locks and executes it.
    """
    beliefs=controller.beliefs
    if any(b.state=='unknown' for b in beliefs.values()):
        return dict(certified=False,reason='existence_unresolved',jobs=None)
    n=sum(b.state in ('found','cleared') for b in beliefs.values())
    remaining=[b for b in beliefs.values() if b.state=='found']
    start=controller.client.position
    jobs=[]
    order,_=route([b.center for b in remaining],start)
    for i in order:
        b=remaining[i]
        point=controller.reliable_clear(b,start)
        if point is not None:
            sequence=[point]
        else:
            sequence=[p for p in fallback_grid(b.polygon,25) if math.hypot(*p)<=1820
                      and all(distance(p,q)>.1 for q in b.failed_clears)]
            # Exhaustive finite cover, ordered in a serpentine pattern. Keep
            # this bounded computation independent of any measured target.
            xs=sorted({p[0] for p in sequence})
            sequence=[p for j,x in enumerate(xs) for p in
                      sorted((p for p in sequence if p[0]==x),key=lambda p:p[1],reverse=bool(j%2))]
            if sequence and distance(start,sequence[-1])<distance(start,sequence[0]):sequence.reverse()
        if not sequence:return dict(certified=False,reason='empty_geometric_cover',jobs=None)
        jobs.extend(Job('clear',p,b.channel,point is not None) for p in sequence)
        start=sequence[-1]
    start=controller.client.position
    upper_us=0
    for job in jobs:
        upper_us+=movement_us(start,job.point)+5000000+2
        start=job.point
    virtual_limit=controller.client.max_virtual_s
    threshold=min(target*n,virtual_limit)
    total=controller.client.virtual_s+upper_us/1e6
    remaining_actions=controller.config.max_actions-controller.actions
    return dict(certified=bool(n>=10 and total<=threshold and len(jobs)<=remaining_actions),
                reason='explicit_clear_cover',jobs=jobs,remaining_upper_s=upper_us/1e6,
                total_upper_s=total,threshold_s=threshold,source_count=n,
                actions_upper=len(jobs),scope='virtual_time_only; valid official feedback and successful execution required')


class JointController(GridController):
    def __init__(self,client,progress=None,*,target=200,**kwargs):
        super().__init__(client,progress,**kwargs)
        self.config.policy='joint_grid'
        radius=COVERAGE_RADIUS_M
        # This runner is for the audited practice generator (1800 m), not an
        # unverified formal generator filling the complete 1800 m task disk.
        outer=1800/math.cos(math.pi/64)
        self.coverage_bound=max(radius/math.sqrt(3),math.sqrt(outer**2+radius**2-math.sqrt(3)*outer*radius))+5/math.sqrt(2)
        if self.coverage_bound>=1000:raise ValueError('Practice cover not certified')
        self.anchors=[(0.,0.)]+[snap((radius*math.cos(k*math.pi/3),radius*math.sin(k*math.pi/3))) for k in range(6)]
        self.coverage=Coverage(self.anchors)
        self.joint=JointCover(self.coverage,self.anchors)
        self.target=target
        self.locked=None
        self.budget_certificate=None
        self.joint_stats=dict(plans=0,improved_frozen_plans=0,proxy_savings_s=0.,scan_jobs=0)
        self.count_excluded=[]
        self.pending_scans=None

    def scan(self,job):
        super().scan(job)
        if self.pending_scans is not None:self.pending_scans.discard(tuple(job.point))

    def next_job(self):
        self.planning_calls+=1
        if self.locked is not None:
            while self.locked and self.beliefs[self.locked[0].channel].state=='cleared':self.locked.pop(0)
            if not self.locked:raise ValueError('Certified clearance policy exhausted')
            return self.locked.pop(0)
        if sum(b.state in ('found','cleared') for b in self.beliefs.values())==16:
            for c,b in self.beliefs.items():
                if b.state=='unknown':b.state='absent';self.count_excluded.append(c)
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if unknown and not self.visited:
            return Job('scan',self.anchors[0],anchor=0,scan_channels=tuple(unknown))
        if not unknown:
            proof=clearance_certificate(self,self.target)
            if proof['certified']:
                self.locked=proof.pop('jobs')
                self.budget_certificate=proof
                self.client.record('target_certificate',**proof)
                return self.next_job()
        found=[b for b in self.beliefs.values() if b.state=='found']
        current=self.client.position
        for b in found:
            reliable=self.reliable_clear(b,current)
            if reliable is not None and distance(reliable,current)<25:
                return Job('clear',reliable,b.channel,True)
        clouds={};targets={}
        for b in found:
            try:
                clouds[b.channel]=self.posterior.cloud(b)
                targets[b.channel]=snap(clouds[b.channel].mean)
            except PosteriorUnavailable:targets[b.channel]=snap(b.center)
        plan,baseline=self.joint.plan(current,list(targets.values()),len(unknown),self.visited,self.pending_scans)
        self.pending_scans=set(plan['scans'])
        self.joint_stats['plans']+=1
        self.joint_stats['improved_frozen_plans']+=plan['value']<baseline-1e-7
        self.joint_stats['proxy_savings_s']+=max(0,baseline-plan['value'])
        path=plan['path']
        if not path:raise ValueError('No joint task in a nonterminal state')
        point=path[0]
        if unknown and self.since_scan>=18:
            point=next(p for p in path if p in plan['scans'])
        if point in plan['scans']:
            anchor=self.anchors.index(point) if point in self.anchors else None
            job=Job('scan',point,anchor=anchor,scan_channels=tuple(unknown))
            self.joint_stats['scan_jobs']+=1
        else:
            c=next(c for c,p in targets.items() if p==point);b=self.beliefs[c]
            end=path[1] if len(path)>1 else None
            reliable=self.reliable_clear(b,current)
            if reliable is not None:job=Job('clear',reliable,c,True)
            elif c not in clouds or len(b.failed_clears)>=8 or b.local_measurements>=10:job=self.fallback(b)
            else:
                _,kind,p=self.bellman.choose(b,clouds[c],current,self.client.channel,end)
                job=Job(kind,p,c,False)
        self.client.record('joint_planning',job=job.__dict__,complete_frozen_route=path,
                           scan_points=sorted(plan['scans']),proxy_total_s=plan['value'],
                           incumbent_proxy_s=baseline,actual_online_optimality_certified=False)
        return job

    def run(self):
        result=super().run()
        result['strategy_version']='joint-grid-v3'
        result['numerical_model'].update(
            numerical_decisions=self.joint_stats['plans'],
            conditional_measurement_evaluations=self.bellman.evaluations,
            adaptive_coverage=True,
            coverage_method='committed finite cover; joint target route; certified coordinate refinements',
            objective_approximation='frozen workload route proxy and conditional local lookahead; evaluated by E[T/N]')
        result['joint_planning']=dict(**self.joint_stats,target_s_per_source=self.target,
            budget_certificate=self.budget_certificate,
            budget_certificate_satisfied=(result['completion_certified'] and result['exit_confirmed']
                and result['error'] is None and result['virtual_time_s']<=self.budget_certificate['total_upper_s'])
                if self.budget_certificate else None,
            global_performance_guaranteed=False)
        result['joint_planning']['count_bound_absent_channels']=self.count_excluded
        result['joint_planning']['source_domain_radius_m']=1800
        self.client.record('joint_summary',summary=result)
        return result
