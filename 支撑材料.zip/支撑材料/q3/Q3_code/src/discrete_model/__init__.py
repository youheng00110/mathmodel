"""Finite grid information-state model with explicit optimality scope."""
