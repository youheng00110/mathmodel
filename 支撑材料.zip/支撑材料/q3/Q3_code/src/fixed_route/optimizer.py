"""Safe clear-position/order optimization with fixed entry and next action.

No truth coordinates or hypothetical observations are accepted as input.
Cost comparisons use the official integer-microsecond movement arithmetic.
All original positions remain feasible candidates. Claimed optimality is only
within the constructed finite candidate sets (order exact for <=6 tasks).
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M
from functools import lru_cache
import math
from solver.geometry import distance,enclosing_circle
from solver.official_physics import movement_us

RADIUS=CLEAR_SAFE_RADIUS_M

def reliable(poly,p):
    return bool(poly) and all(distance(p,v)<=RADIUS+1e-9 for v in poly)

def line_solution(poly,start,end):
    """Intersection of reliable disk constraints with entry-to-exit segment.

    Any feasible point on the segment attains its Euclidean shortest length;
    rounding is validated afterwards. None means only this segment is blocked.
    """
    if end is None:return None
    d=(end[0]-start[0],end[1]-start[1]);a=d[0]**2+d[1]**2
    if a==0:return start if reliable(poly,start) else None
    lo,hi=0.,1.
    for v in poly:
        x,y=start[0]-v[0],start[1]-v[1]
        b=2*(x*d[0]+y*d[1]);c=x*x+y*y-RADIUS**2
        disc=b*b-4*a*c
        if disc<0:return None
        root=math.sqrt(disc);lo=max(lo,(-b-root)/(2*a));hi=min(hi,(-b+root)/(2*a))
        if lo>hi:return None
    t=(lo+hi)/2;p=tuple(round(start[i]+t*d[i],6) for i in (0,1))
    return p if reliable(poly,p) else None

def candidates(poly,old,start,end,step=5):
    if not reliable(poly,old):raise ValueError('Original clearance lacks the declared geometric certificate')
    center,_=enclosing_circle(poly)
    # Every reliable point is within RADIUS of every polygon vertex. Restrict
    # the lattice to one such disk; no full-region completeness is asserted.
    v=poly[0]
    points=[tuple(old),tuple(center)]
    for x in range(math.ceil((v[0]-20)/step),math.floor((v[0]+20)/step)+1):
        for y in range(math.ceil((v[1]-20)/step),math.floor((v[1]+20)/step)+1):points.append((x*step,y*step))
    line=line_solution(poly,start,end)
    if line is not None:points.append(line)
    return list(dict.fromkeys(p for p in points if reliable(poly,p)))

def path_us(points,start,end=None):
    total=0;previous=start
    for p in points:total+=movement_us(previous,p);previous=p
    if end is not None:total+=movement_us(previous,end)
    return total

def optimize(tasks,start,end=None):
    """tasks: ordered dicts with channel, original point, conservative polygon."""
    if len({t['channel'] for t in tasks})!=len(tasks):raise ValueError('Clearance tasks must have distinct channels')
    options=[candidates(t['polygon'],t['point'],start,end) for t in tasks]
    n=len(tasks);old_us=path_us([t['point'] for t in tasks],start,end)
    if not n:return [],dict(old_us=old_us,new_us=old_us,saved_us=0)
    exact_order=n<=6
    @lru_cache(None)
    def dp(mask,last,option):
        current=start if last<0 else options[last][option]
        if mask==(1<<n)-1:return (movement_us(current,end) if end is not None else 0),()
        allowed=[i for i in range(n) if not mask>>i&1]
        if not exact_order:allowed=allowed[:1]
        best=(math.inf,())
        for i in allowed:
            for j,p in enumerate(options[i]):
                tail,path=dp(mask|(1<<i),i,j)
                value=movement_us(current,p)+tail
                if value<best[0]:best=(value,((i,j),)+path)
        return best
    new_us,selection=dp(0,-1,-1)
    result=[dict(channel=tasks[i]['channel'],point=options[i][j],original_index=i) for i,j in selection]
    assert new_us<=old_us
    assert path_us([t['point'] for t in result],start,end)==new_us
    assert all(reliable(tasks[t['original_index']]['polygon'],t['point']) for t in result)
    return result,dict(old_us=old_us,new_us=new_us,saved_us=old_us-new_us,
        exact_order_in_candidates=exact_order,fixed_order_only=not exact_order,candidate_counts=list(map(len,options)),
        states=dp.cache_info().currsize,scope='fixed clearance tasks, entry and endpoint; equal success service cost',
        clear_safe_radius_m=RADIUS,
        continuous_global_optimum=False)
