"""Online compiler preserving a reference policy's information and virtual clock.

Only logically certified successful clears are buffered in the internal planner.
Their symbolic outcomes reveal no unknown data. The next reference action is
obtained, then a fixed-endpoint clear block is optimized and physically executed.
Actual API responses remain in the authoritative Client log; reference-planner
records are explicitly prefixed. No gain in wall-clock runtime is guaranteed.
"""
from copy import deepcopy
import time
from solver.belief import Belief
from solver.protocol import ProtocolError
from solver.official_physics import movement_us
from solver.geometry import distance
from discrete_model.joint_action_policy import JointActionController
from .optimizer import reliable,optimize


class ReferenceClient:
    def __init__(self,actual):
        self.actual=actual;self.position=(0.,0.);self.channel=1;self.virtual_s=0.
        self.stats=deepcopy(actual.stats);self.regions={i:Belief(i) for i in range(1,21)}
        self.pending=[];self.saved_us=0;self.certificates=[];self.clear_times=[]

    def __getattr__(self,name):return getattr(self.actual,name)
    def record(self,event,**data):self.actual.record('reference_'+event,**data)

    def advance(self,path,p,c,response):
        switch=int(path=='/measure' and self.channel!=c)
        success=response.get('clear_result')=='success'
        cost=(5+switch) if path=='/measure' else (5 if success else 3)
        self.virtual_s=(round(self.virtual_s*1e6)+movement_us(self.position,p)+cost*1000000)/1e6
        self.stats['distance_m']+=distance(self.position,p);self.position=tuple(p)
        if path=='/measure':
            self.channel=c;self.stats['measurements']+=1;self.stats['switches']+=switch
            self.regions[c].observe(p,response)
        else:
            self.stats['clear_success' if success else 'clear_failure']+=1
            self.regions[c].clear_feedback(p,response,False)
        return dict(response,virtual_time_s=self.virtual_s)

    def optimize_block(self,tasks,start,end):
        return optimize(tasks,start,end)

    def flush(self,end):
        if not self.pending:return
        tasks=self.pending;self.pending=[];start=self.actual.position
        plan,proof=self.optimize_block(tasks,start,end)
        before=self.actual.virtual_s
        for task in plan:
            response=self.actual.act('/clear',task['point'],task['channel'])
            if response['clear_result']!='success':
                raise ProtocolError('Certified clear block failed; abort rather than trust symbolic planning')
            self.clear_times.append(self.actual.virtual_s)
        # The endpoint's incoming move is part of the certificate, but is
        # performed by the following actual action. No movement is counted twice.
        executed_us=round((self.actual.virtual_s-before)*1e6)-5*len(plan)*1000000
        projected=executed_us+(movement_us(self.actual.position,end) if end is not None else 0)
        if projected!=proof['new_us']:raise ProtocolError('Native clear-block movement differs from certificate')
        self.saved_us+=proof['saved_us']
        record=dict(start=start,end=end,tasks=tasks,plan=plan,**proof)
        self.certificates.append(record);self.actual.record('fixed_route_certificate',**record)

    def act(self,path,position=None,channel=None):
        if path=='/enter':return self.actual.enter()
        if path=='/exit':return self.exit()
        self.actual.record('reference_action',path=path,position=position,channel=channel)
        b=self.regions[channel]
        if path=='/clear' and b.state=='found' and reliable(b.polygon,position):
            self.pending.append(dict(channel=channel,point=tuple(position),polygon=deepcopy(b.polygon)))
            self.actual.record('symbolic_certified_clear',channel=channel,reference_point=position,
                               executed=False,reason='outcome implied by conservative geometry')
            return self.advance(path,position,channel,dict(accepted=True,clear_result='success',planning_only=True))
        self.flush(tuple(position))
        response=self.actual.act(path,position,channel)
        if path=='/clear' and response['clear_result']=='success':self.clear_times.append(self.actual.virtual_s)
        result=self.advance(path,position,channel,response)
        if round((self.virtual_s-self.actual.virtual_s)*1e6)!=self.saved_us:
            raise ProtocolError('Synchronized reference/actual time difference violates block certificate')
        return result

    def enter(self):return self.act('/enter')
    def exit(self):
        if self.actual.entered and not self.actual.exit_attempted:
            try:
                self.flush(None)
                if round((self.virtual_s-self.actual.virtual_s)*1e6)!=self.saved_us:
                    raise ProtocolError('Final time difference violates route certificate')
            finally:
                response=self.actual.exit()
            return response


class SafeRouteBaseline:
    """Joint-action baseline plus a nonanticipative safe execution compiler."""
    def __init__(self,client):
        self.actual=client;self.reference=ReferenceClient(client)
        self.controller=JointActionController(self.reference,progress=lambda message:None)

    def run(self):
        began=time.monotonic();result=self.controller.run()
        reference_summary=deepcopy(result)
        count=self.actual.stats['clear_success']
        complete=bool(result['completion_certified'] and not result['error'] and self.actual.exited
                      and count==self.reference.stats['clear_success'] and not self.reference.pending)
        result.update(self.actual.stats)
        result.update(policy='safe_route_baseline',strategy_version='joint-action-safe-route-v1',
            virtual_time_s=self.actual.virtual_s,average_clear_time_s=self.actual.virtual_s/count if count else None,
            program_elapsed_s=time.monotonic()-began,completion_certified=complete,exit_confirmed=self.actual.exited,
            clear_completion_times_s=self.reference.clear_times,
            mean_clear_completion_time_s=sum(self.reference.clear_times)/count if count else None)
        result['safe_route']=dict(reference_virtual_s=self.reference.virtual_s,saved_s=self.reference.saved_us/1e6,
            blocks=len(self.reference.certificates),improved_blocks=sum(p['saved_us']>0 for p in self.reference.certificates),
            time_nonincrease_verified=complete and self.actual.virtual_s<=self.reference.virtual_s+1e-6,
            scope='reference-policy information/action stream and virtual cost; static world and valid geometric certificates',
            wall_time_nonincrease_guaranteed=False,full_task_1800_completion_guaranteed=False,
            clear_geometry_prior_radius_m=1800)
        self.actual.record('reference_run_summary',summary=reference_summary)
        self.actual.record('summary',summary=result)
        return result
