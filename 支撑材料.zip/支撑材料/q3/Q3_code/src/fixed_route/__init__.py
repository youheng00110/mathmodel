"""Deterministic fixed-task route compression; independent of online policies."""
