"""Continuous convex block refinement with a fixed-order lower bound.

Reuse the disk-support dual oracle and convex line search already audited in
solver.convex_clearance. No optional solver dependency. Preserve the historical
finite optimizer's plan unless native integer-microsecond cost decreases.
The continuous certificate is for the selected order, never all permutations.
"""
import math
from fixed_route.optimizer import optimize as finite_optimize, reliable, path_us, RADIUS
from solver.convex_clearance import (clearance_region, path_length,
    smooth_value_gradient, line_search, dot, minus)


def fixed_order(tasks,start,end=None,iterations=160,tolerance_m=.002):
    regions=[clearance_region(tuple(map(tuple,t['polygon'])),RADIUS) for t in tasks]
    points=[tuple(t['point']) for t in tasks]
    if any(not r.feasible(p,1e-9) for r,p in zip(regions,points)):
        raise ValueError('Continuous incumbent is not reliable')
    if end is not None:points.append(tuple(end))
    best=list(points);upper=path_length(best,start);lower=0.;epsilon=1e-5;used=0
    for used in range(1,iterations+1):
        value,gradient=smooth_value_gradient(points,start,epsilon)
        bound=value-len(points)*epsilon
        directions=[(0.,0.) for _ in points]
        for i,region in enumerate(regions):
            proposal,support=region.linear_minimum(gradient[i])
            directions[i]=minus(proposal,points[i])
            bound+=support-dot(gradient[i],points[i])
        lower=max(lower,bound)
        if lower>upper+1e-5:raise ValueError('Inconsistent convex bounds')
        if upper-lower<=tolerance_m:break
        step=line_search(points,directions,start,epsilon)
        if step==0:break
        points=[tuple(p[k]+step*d[k] for k in (0,1)) for p,d in zip(points,directions)]
        for i,r in enumerate(regions):points[i]=r.repair(points[i])
        cost=path_length(points,start)
        if cost<upper:best=list(points);upper=cost
    # Quantize for the actual interface, then independently check all vertices.
    # A failed rounding check retains the corresponding original feasible point.
    quantized=[]
    for t,r,p in zip(tasks,regions,best):
        q=tuple(round(x,6) for x in p)
        if not reliable(t['polygon'],q):
            p=tuple((1-1e-7)*x+1e-7*c for x,c in zip(p,r.center))
            q=tuple(round(x,6) for x in p)
        if not reliable(t['polygon'],q):q=tuple(t['point'])
        quantized.append(q)
    length=path_length(quantized+([tuple(end)] if end is not None else []),start)
    info=dict(method='continuous_conditional_gradient_with_disk_support_dual',
        scope='fixed order, reliable regions, fixed entry and endpoint',
        lower_length_m=lower,feasible_quantized_length_m=length,
        gap_m=max(0.,length-lower),gap_target_m=tolerance_m,
        gap_target_met=length-lower<=tolerance_m,iterations=used,
        smoothing_error_bound_m=len(points)*epsilon,
        floating_point_guarded=True,interval_arithmetic_certified=False,
        global_online_optimality=False)
    return quantized,info


def optimize(tasks,start,end=None):
    finite,proof=finite_optimize(tasks,start,end)
    if not finite:return finite,proof
    ordered=[dict(tasks[t['original_index']],point=t['point']) for t in finite]
    points,info=fixed_order(ordered,start,end)
    proposed=[dict(t,point=p) for t,p in zip(finite,points)]
    proposed_us=path_us(points,start,end)
    finite_us=proof['new_us']
    selected=proposed if proposed_us<finite_us else finite
    selected_us=min(proposed_us,finite_us)
    edges=len(tasks)+int(end is not None)
    # At most 0.5 microsecond rounding per edge, with an extra numerical guard.
    lb_us=math.floor(info['lower_length_m']/5*1e6-edges*.5-1)
    assert selected_us<=finite_us<=proof['old_us']
    assert all(reliable(tasks[t['original_index']]['polygon'],t['point']) for t in selected)
    proof.update(new_us=selected_us,saved_us=proof['old_us']-selected_us,
        finite_incumbent_us=finite_us,continuous_saved_us=finite_us-selected_us,
        continuous_refinement=info,selected_order_lower_us=lb_us,
        selected_order_gap_us=max(0,selected_us-lb_us),
        exact_order_in_candidates=False,
        finite_incumbent_exact_order_in_candidates=proof['exact_order_in_candidates'],
        scope='same certified clear block and endpoints; finite incumbent retained')
    return selected,proof
