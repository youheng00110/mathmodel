from fixed_route.online import ReferenceClient
from .clearance import optimize
import json
import numpy as np

def plain(value):
    """Certificates cross a JSON boundary before any physical block executes."""
    if isinstance(value,np.generic):return value.item()
    if isinstance(value,dict):return {k:plain(v) for k,v in value.items()}
    if isinstance(value,tuple):return tuple(plain(v) for v in value)
    if isinstance(value,list):return [plain(v) for v in value]
    return value

class ContinuousReferenceClient(ReferenceClient):
    def optimize_block(self,tasks,start,end):
        plan,proof=optimize(tasks,start,end)
        plan,proof=plain(plan),plain(proof)
        json.dumps(dict(plan=plan,proof=proof),allow_nan=False)
        return plan,proof
