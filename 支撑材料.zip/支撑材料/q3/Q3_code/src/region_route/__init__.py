"""Isolated area-weighted coverage and certified continuous-clear variants."""
