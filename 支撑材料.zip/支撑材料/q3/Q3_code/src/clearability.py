"""Finite-scenario proposal generator. No probability or minimax certificate."""
import math
from solver.geometry import diameter, distance
from solver.parameters import CLEAR_SAFE_RADIUS_M
from discrete_model.numerical import snap

def gap_summary(prior_radius, posterior_radii, visibility):
    """Include a no-signal branch with the unchanged safe outer polygon.

    Weights are heuristic visibility scores, not a calibrated posterior.
    Worst is over retained scenarios only, never the continuous observation set.
    """
    prior=max(0.,prior_radius-CLEAR_SAFE_RADIUS_M)
    gaps=[max(0.,r-CLEAR_SAFE_RADIUS_M) for r in posterior_radii]
    if not gaps: return prior,prior
    worst=max(gaps+[prior] if any(v<1.-1e-12 for v in visibility) else gaps)
    mean=sum(v*g+(1-v)*prior for v,g in zip(visibility,gaps))/len(gaps)
    return worst,mean

def proposals(controller,belief,existing):
    if belief.clear_gap<=0:return []
    length,a,b=diameter(belief.polygon)
    if length<1e-8:return []
    u=((b[0]-a[0])/length,(b[1]-a[1])/length);v=(-u[1],u[0]);c=belief.center
    raw=[]
    for along,factor in ((0.,.3),(0.,.8),(-.35,.6),(.35,.6)):
        lateral=max(25.,min(600.,factor*belief.radius))
        for sign in (-1,1):raw.append(snap(tuple(c[k]+along*belief.radius*u[k]+sign*lateral*v[k] for k in (0,1))))
    scored=[];existing=set(map(tuple,existing))
    for p in dict.fromkeys(raw):
        if p in existing or math.hypot(*p)>3300:continue
        score=controller.active_evaluator.evaluate(belief,p)
        if score is None:continue
        worst=score['sampled_worst_clear_gap_m'];mean=score['sampled_mean_clear_gap_m']
        scored.append((worst,mean,distance(controller.client.position,p),p))
    selected=[r[3] for r in sorted(scored)[:2]]
    controller.client.record('clearability_proposals',channel=belief.channel,prior_gap_m=belief.clear_gap,
        selected=selected,candidates=[dict(point=r[3],sampled_worst_gap_m=r[0],visibility_weighted_gap_m=r[1]) for r in sorted(scored)],
        scope='finite geometric scenarios; no-signal retains prior outer polygon',minimax_certified=False,
        final_selection='existing conditional service and route time objective')
    return selected
