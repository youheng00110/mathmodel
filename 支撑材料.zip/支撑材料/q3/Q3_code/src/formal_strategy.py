from nested_joint.no_score.controller import CoupledController
from fixed_route.online import ReferenceClient,SafeRouteBaseline
from discrete_model.certified_bounds import GeometricFallback,fallback_upper
from solver.official_physics import movement_us

class FormalController(CoupledController):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.emergency=GeometricFallback();self.reserve_locked=False;self.reserve_checks=0
        self.initial_reserve=fallback_upper(self.beliefs,self.anchors,self.visited,self.client.position)
        if self.initial_reserve['remaining_upper_s']+1>self.client.max_virtual_s:
            raise ValueError('Insufficient initial virtual budget for complete geometric fallback')
        if self.initial_reserve['actions_upper']>self.config.max_actions:
            raise ValueError('Insufficient action budget for complete geometric fallback')

    def next_job(self):
        if self.reserve_locked:return self.emergency.job(self.beliefs,self.anchors,self.visited)
        job=super().next_job()
        unknown=sum(b.state=='unknown' for b in self.beliefs.values())
        actions=max(1,unknown) if job.kind=='scan' else 1
        operation=6*actions if job.kind=='scan' else 6 if job.kind=='measure' else 5
        step=movement_us(self.client.position,job.point)/1e6+operation
        tail=fallback_upper(self.beliefs,self.anchors,self.visited,job.point)
        self.reserve_checks+=1
        within_time=self.client.virtual_s+step+tail['remaining_upper_s']+1<=self.client.max_virtual_s
        within_actions=self.actions+actions+tail['actions_upper']<=self.config.max_actions
        if not (within_time and within_actions):
            current=fallback_upper(self.beliefs,self.anchors,self.visited,self.client.position)
            if self.client.virtual_s+current['remaining_upper_s']>self.client.max_virtual_s:
                raise ValueError('Virtual fallback reserve invariant violated')
            self.reserve_locked=True
            self.client.record('formal_reserve_commit',remaining_upper_s=current['remaining_upper_s'],reason='virtual_or_action_reserve')
            return self.emergency.job(self.beliefs,self.anchors,self.visited)
        return job

    def run(self):
        result=super().run()
        result['formal_safety']=dict(source_domain_m=1800,clear_domain_m=1820,measure_domain_m=3300,
            coverage_bound_m=self.coverage_bound,initial_fallback=self.initial_reserve,
            reserve_checks=self.reserve_checks,reserve_committed=self.reserve_locked,
            virtual_budget_reserve=True,wall_time_universal_guarantee=False)
        return result

class FormalStrategy(SafeRouteBaseline):
    def __init__(self,client):
        self.actual=client;self.reference=ReferenceClient(client)
        self.controller=FormalController(self.reference,progress=lambda message:None)
    def run(self):
        result=super().run()
        result.update(policy='coupled_task1800',strategy_version='coupled-service-route-task1800-v1')
        result['safe_route']['reference_policy']=result['strategy_version']
        result['safe_route']['full_task_1800_completion_guaranteed']=False
        result['safe_route']['full_task_1800_geometry_covered']=True
        self.actual.record('summary',summary=result)
        return result
