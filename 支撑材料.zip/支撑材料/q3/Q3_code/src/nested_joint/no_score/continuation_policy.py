"""Outcome-specific whole frozen-route continuation for local Bellman planning.

Other target beliefs and scan workload are frozen, and represented by points.
Future unknown discoveries and future measurements of other targets are not
expanded. Exact route tails (<=12 points) and clearance orders (<=8 centres)
are exact only for those finite subproblems, not the complete online problem.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M
from functools import lru_cache
import math
import numpy as np

from solver.geometry import distance
from solver.official_physics import movement_us
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from discrete_model.analytic_policy import AnalyticBellman
from .joint_policy import JointController
from discrete_model.service_policy import RecordedCover
from discrete_model.numerical import snap


class FrozenRoute:
    def __init__(self,points,reference=None,service=0.,exact_limit=12):
        self.points=list(dict.fromkeys(tuple(p) for p in points))
        self.service=service;self.cache={};self.exact=len(self.points)<=exact_limit
        n=len(self.points)
        if not n:self.tails=[];return
        self.matrix=np.array([[distance(a,b)/5 for b in self.points] for a in self.points])
        if self.exact:
            @lru_cache(None)
            def dp(mask,last):
                if not mask:return 0.
                return min(self.matrix[last,j]+dp(mask^(1<<j),j) for j in range(n) if mask>>j&1)
            self.tails=[dp(((1<<n)-1)^(1<<j),j) for j in range(n)]
        else:
            # Fixed complete routes: rotations and reversals of the incumbent.
            # They are independent of each queried exit point, avoiding a fresh
            # heuristic search whose quality can jump when the start moves.
            ordered=[tuple(p) for p in reference or [] if tuple(p) in self.points]
            ordered=list(dict.fromkeys(ordered+self.points))
            indices=[self.points.index(p) for p in ordered];self.tails=[math.inf]*n
            for order in (indices,list(reversed(indices))):
                for shift in range(n):
                    path=order[shift:]+order[:shift]
                    length=sum(self.matrix[a,b] for a,b in zip(path,path[1:]))
                    self.tails[path[0]]=min(self.tails[path[0]],float(length))

    def __call__(self,p):
        p=tuple(p)
        if p not in self.cache:
            self.cache[p]=self.service+(min(distance(p,q)/5+t for q,t in zip(self.points,self.tails)) if self.points else 0.)
        return self.cache[p]


def clearance_value(points,weights,start,terminal,stats,limit=8):
    mass=float(weights.sum())
    if mass<=1e-12:return 0.,None
    centres=np.unique(np.round(points/5)*5,axis=0)
    covers=np.linalg.norm(centres[:,None,:]-points[None,:,:],axis=2)<=20
    live=weights.copy();position=np.asarray(start);selected=[];incumbent=0.
    while float(live.sum())>=1e-12:
        hit=covers@live
        rank=hit/(np.linalg.norm(centres-position,axis=1)/5+3)
        i=int(np.argmax(rank))
        if hit[i]<=0:raise ValueError('Incomplete clearance cover')
        selected.append(i)
        incumbent+=float(live.sum())*(movement_us(tuple(position),tuple(centres[i]))/1e6+3)
        incumbent+=float(hit[i])*(2+terminal(tuple(centres[i])))
        live[covers[i]]=0;position=centres[i]
    if len(centres)>limit:
        if len(selected)>limit:
            stats['greedy_cover_calls']+=1
            return incumbent/mass,tuple(centres[selected[0]])
        centres=centres[selected];covers=covers[selected]
    stats['exact_cover_calls']+=1
    masks=[sum(1<<int(j) for j in np.flatnonzero(row)) for row in covers]
    moves=np.array([[movement_us(tuple(a),tuple(b))/1e6 for b in centres] for a in list(centres)+[start]])
    exits=[terminal(tuple(p)) for p in centres]
    @lru_cache(None)
    def weight(mask):return sum(float(w) for j,w in enumerate(weights) if mask>>j&1)
    @lru_cache(None)
    def dp(mask,last):
        if not mask:return 0.,None
        mass_left=weight(mask);best=(math.inf,None)
        for i,covered in enumerate(masks):
            hit=mask&covered
            if not hit:continue
            cost=mass_left*(moves[last,i]+3)+weight(hit)*(2+exits[i])+dp(mask&~covered,i)[0]
            if cost<best[0]:best=(cost,i)
        return best
    value,first=dp((1<<len(points))-1,len(centres))
    assert value<=incumbent+1e-7,'Complete greedy incumbent lost'
    stats['bellman_states']+=dp.cache_info().currsize
    stats['retained_cover_checks']+=1
    stats['retained_cover_improvements']+=int(value<incumbent-1e-7)
    return value/mass,tuple(centres[first])


class ContinuationBellman(AnalyticBellman):
    def __init__(self,controller):
        super().__init__(exact_tail=True);self.controller=controller;self.terminal=None

    def choose(self,b,cloud,start,receiver,end=None,measure_enabled=True):
        self.terminal=self.controller.continuation(b.channel)
        try:return super().choose(b,cloud,start,receiver,end,measure_enabled)
        finally:self.terminal=None

    def cover(self,points,weights,start,end=None):
        if self.terminal is None:return super().cover(points,weights,start,end)
        return clearance_value(points,weights,start,self.terminal,self.stats)


class ContinuationController(JointController):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.config.policy='continuation_grid'
        self.joint=RecordedCover(self.coverage,self.anchors)
        self.bellman=ContinuationBellman(self)
        self.route_stats=dict(contexts=0,exact_routes=0,candidate_routes=0,reliable_clear_changes=0)

    def continuation(self,channel):
        plan=self.joint.latest;points=[];targets=0
        for c,b in self.beliefs.items():
            if c==channel or b.state!='found':continue
            targets+=1
            try:points.append(snap(self.posterior.cloud(b).mean))
            except PosteriorUnavailable:points.append(snap(b.center))
        points.extend(sorted(plan['scans']))
        unknown=sum(b.state=='unknown' for b in self.beliefs.values())
        terminal=FrozenRoute(points,plan['path'],service=5*targets+max(0,6*unknown-1)*len(plan['scans']))
        self.route_stats['contexts']+=1
        self.route_stats['exact_routes' if terminal.exact else 'candidate_routes']+=1
        self.client.record('route_continuation',channel=channel,points=terminal.points,
            exact_point_route=terminal.exact,constant_service_s=terminal.service,
            scope='frozen representatives and scan workload; no future discoveries or other-target sensing')
        return terminal

    def next_job(self):
        plans=self.joint_stats['plans'];job=super().next_job()
        if self.joint_stats['plans']==plans or job.kind!='clear' or not job.guaranteed or self.locked is not None:return job
        b=self.beliefs[job.channel];center=snap(b.center);terminal=self.continuation(job.channel)
        candidates=[job.point]+[(center[0]+5*i,center[1]+5*j) for i in range(-4,5) for j in range(-4,5)]
        good=[p for p in candidates if math.hypot(*p)<=1820 and all(distance(p,v)<=CLEAR_SAFE_RADIUS_M for v in b.polygon)]
        chosen=min(good,key=lambda p:movement_us(self.client.position,p)/1e6+terminal(p))
        self.route_stats['reliable_clear_changes']+=chosen!=job.point
        replacement=Job('clear',chosen,job.channel,True)
        self.client.record('continuation_clear',baseline_job=job.__dict__,job=replacement.__dict__)
        return replacement

    def run(self):
        result=super().run();result['strategy_version']='continuation-grid-v1'
        result['continuation_planning']=dict(self.route_stats,**self.bellman.stats,
            global_optimality_certified=False,exact_route_limit=12,exact_clearance_limit=8)
        self.client.record('continuation_summary',summary=result)
        return result
