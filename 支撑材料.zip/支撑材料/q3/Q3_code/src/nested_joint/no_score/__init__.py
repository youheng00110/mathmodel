"""Isolated compatibility copy: legacy score-triggered lock disabled."""
