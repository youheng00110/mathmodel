"""Joint choice of target service or pending scan in a frozen-workload model.

All found targets retain a common local service estimate in every comparison.
The selected target uses outcome-dependent sensing/clearance evaluation instead
of its constant estimate. The original actual action is explicitly rescored and
retained. Bounds certify only this finite quadrature/action surrogate, never the
official full information-state SSP. Future discoveries remain unexpanded.
"""
from solver.parameters import CLEAR_SAFE_RADIUS_M
import math
import numpy as np

from solver.geometry import distance
from solver.official_physics import movement_us
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from discrete_model.analytic_policy import AnalyticBellman
from .continuation_policy import ContinuationController,FrozenRoute,clearance_value
from discrete_model.numerical import snap


def service_lower(cloud,start,terminal,extra_points=()):
    """Clairvoyant lower bound for the declared finite clearance candidates.

Each quadrature point may choose its own successful clear point. Dropping
measurements and failures relaxes the model. A 1 ms allowance covers movement
roundoff for these finite (<=129-action) local measurement/clearance tails.
"""
    centres=list(dict.fromkeys([*map(tuple,np.round(cloud.points/5)*5),*extra_points]))
    inside=np.linalg.norm(np.asarray(centres)[:,None,:]-cloud.points[None,:,:],axis=2)<=20
    values=np.array([distance(start,p)/5+5+terminal(p) for p in centres])
    per_point=np.min(np.where(inside,values[:,None],np.inf),axis=0)
    return float(cloud.weights@per_point)/float(cloud.weights.sum())-.001


class JointActionController(ContinuationController):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.config.policy='joint_action_grid'
        self.service_cache={};self.context=None
        self.action_stats=dict(decisions=0,changed_actions=0,changed_tasks=0,
            target_evaluations=0,scan_evaluations=0,surrogate_pruned=0,
            incumbent_checks=0,posterior_fallbacks=0)

    def setup_context(self):
        clouds={};positions={};costs={}
        for c,b in self.beliefs.items():
            if b.state!='found':continue
            if len(b.failed_clears)>=8 or b.local_measurements>=10:return False
            try:cloud=self.posterior.cloud(b)
            except PosteriorUnavailable:
                self.action_stats['posterior_fallbacks']+=1;return False
            clouds[c]=cloud;positions[c]=snap(cloud.mean)
            key=(tuple(b.observations),tuple(b.failed_clears))
            old=self.service_cache.get(c)
            if old is None or old[0]!=key:
                # Same local service approximation, evaluated from the target's
                # representative point, for every deferred target. This is not
                # its true future cost or a certified bound.
                estimate=AnalyticBellman(True).choose(b,cloud,positions[c],c,None)[0]
                self.service_cache[c]=(key,estimate)
            costs[c]=self.service_cache[c][1]
        self.context=dict(clouds=clouds,positions=positions,costs=costs,tails={})
        return True

    def continuation(self,channel):
        if self.context is None:return super().continuation(channel)
        cache=self.context['tails']
        if channel not in cache:
            plan=self.joint.latest
            points=[p for c,p in self.context['positions'].items() if c!=channel]+sorted(plan['scans'])
            unknown=sum(b.state=='unknown' for b in self.beliefs.values())
            service=sum(v for c,v in self.context['costs'].items() if c!=channel)
            service+=max(0,6*unknown-1)*len(plan['scans'])
            cache[channel]=FrozenRoute(points,plan['path'],service=service)
        return cache[channel]

    def reliable_options(self,b):
        if b.radius>20:return []
        centre=snap(b.center)
        pts=[snap(self.client.position)]+[(centre[0]+5*i,centre[1]+5*j) for i in range(-4,5) for j in range(-4,5)]
        return [p for p in dict.fromkeys(pts) if math.hypot(*p)<=1820 and all(distance(p,v)<=CLEAR_SAFE_RADIUS_M for v in b.polygon)]

    def scan_value(self,p):
        plan=self.joint.latest;unknown=sum(b.state=='unknown' for b in self.beliefs.values())
        scans=set(plan['scans'])-{tuple(p)}
        points=list(self.context['positions'].values())+sorted(scans)
        service=sum(self.context['costs'].values())+max(0,6*unknown-1)*len(scans)
        tail=FrozenRoute(points,plan['path'],service=service)
        self.action_stats['scan_evaluations']+=1
        first_is_current=self.beliefs[self.client.channel].state=='unknown'
        immediate=max(0,6*unknown-int(first_is_current))
        return movement_us(self.client.position,p)/1e6+immediate+tail(p)

    def score_job(self,job):
        if job.kind=='scan':return self.scan_value(job.point)
        cloud=self.context['clouds'][job.channel];terminal=self.continuation(job.channel)
        self.bellman.terminal=terminal
        try:
            if job.kind=='measure':
                return self.bellman.measurement(cloud,job.point,self.client.position,
                    self.client.channel,job.channel,None)
            hit=np.linalg.norm(cloud.points-job.point,axis=1)<=20
            prob=float(cloud.weights[hit].sum())/float(cloud.weights.sum())
            cost=movement_us(self.client.position,job.point)/1e6+5*prob+3*(1-prob)+prob*terminal(job.point)
            if not np.all(hit):
                value,_=clearance_value(cloud.points[~hit],cloud.weights[~hit],job.point,terminal,self.bellman.stats)
                cost+=(1-prob)*value
            return cost
        finally:self.bellman.terminal=None

    def next_job(self):
        self.context=None;plans=self.joint_stats['plans']
        original=super().next_job()
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        # Preserve initial scan, reliable nearby clear, mandatory progress and
        # locked exhaustive clearance guarantees from the existing controller.
        if self.joint_stats['plans']==plans or self.locked is not None or (unknown and self.since_scan>=18):return original
        if not self.setup_context():self.context=None;return original
        try:
            incumbent=self.score_job(original);best=incumbent;chosen=original
            evaluations=[dict(kind=original.kind,channel=original.channel,point=original.point,value=incumbent,original=True)]
            candidates=[]
            for c,cloud in self.context['clouds'].items():
                good=self.reliable_options(self.beliefs[c]);terminal=self.continuation(c)
                lower=service_lower(cloud,self.client.position,terminal,good)
                candidates.append((lower,c,good))
            for lower,c,good in sorted(candidates):
                if lower>=best-1e-7:
                    self.action_stats['surrogate_pruned']+=1
                    evaluations.append(dict(kind='target',channel=c,lower=lower,pruned=True));continue
                terminal=self.continuation(c)
                if good:
                    p=min(good,key=lambda p:movement_us(self.client.position,p)/1e6+terminal(p))
                    job=Job('clear',p,c,True);value=self.score_job(job)
                else:
                    path=self.joint.latest['path'];point=self.context['positions'][c]
                    i=path.index(point);end=path[i+1] if i+1<len(path) else None
                    value,kind,p=self.bellman.choose(self.beliefs[c],self.context['clouds'][c],
                        self.client.position,self.client.channel,end)
                    job=Job(kind,p,c,False)
                self.action_stats['target_evaluations']+=1
                evaluations.append(dict(kind=job.kind,channel=c,point=job.point,value=float(value),lower=lower))
                assert lower<=value+1e-5,'Surrogate bound exceeded evaluated target cost'
                if value<best-1e-7:best=float(value);chosen=job
            for p in sorted(self.joint.latest['scans']):
                value=self.scan_value(p)
                evaluations.append(dict(kind='scan',channel=0,point=p,value=value))
                if value<best-1e-7:
                    best=value;chosen=Job('scan',p,anchor=self.anchors.index(p) if p in self.anchors else None,scan_channels=tuple(unknown))
            assert best<=incumbent+1e-7
            self.action_stats['incumbent_checks']+=1;self.action_stats['decisions']+=1
            self.action_stats['changed_actions']+=(chosen.kind,chosen.channel,chosen.point)!=(original.kind,original.channel,original.point)
            self.action_stats['changed_tasks']+=(chosen.kind=='scan',chosen.channel)!=(original.kind=='scan',original.channel)
            self.joint_stats['scan_jobs']+=int(chosen.kind=='scan')-int(original.kind=='scan')
            self.client.record('joint_action_decision',original=original.__dict__,selected=chosen.__dict__,
                original_value=incumbent,selected_value=best,candidates=evaluations,
                bound_scope='frozen finite quadrature task model only',full_bellman_optimality=False)
            return chosen
        finally:self.context=None

    def run(self):
        result=super().run();result['strategy_version']='joint-action-grid-v1'
        result['joint_action_planning']=dict(self.action_stats,global_optimality_certified=False,
            future_discoveries_modelled=False,action_space='all found target candidates and pending scan tasks; progress guards retained')
        self.client.record('joint_action_summary',summary=result)
        return result
