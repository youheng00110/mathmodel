"""Receding-horizon target-service mode/coverage route controller.

Known-target modes use the existing approximate spatial quadrature. Unknown
sources are represented only by remaining certified scan obligations, not by
future discovery branches. Existing coverage, locked-clearance and fallback
rules remain authoritative. Surrogate improvement is not episode improvement.
"""
import math
import numpy as np
from solver.geometry import distance
from solver.planner import Job
from solver.posterior import PosteriorUnavailable
from discrete_model.analytic_policy import cautious_points
from .joint_action_policy import JointActionController
from discrete_model.numerical import snap
from fixed_route.online import ReferenceClient,SafeRouteBaseline
from coupled_route.model import Mode,target_mode
from coupled_route.routing import RouteProblem

class CoupledController(JointActionController):
    route_problem_class=RouteProblem
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.mode_cache={}
        self.coupled_stats=dict(decisions=0,changed_actions=0,exact_catalog_solves=0,beam_solves=0,expanded=0,modelled_savings_s=0.,cache_builds=0)

    def cached_mode(self,g,job,cloud):
        b=self.beliefs[job.channel];history=tuple(b.observations),tuple(b.failed_clears)
        if job.channel not in self.mode_cache or self.mode_cache[job.channel][0]!=history:
            self.mode_cache[job.channel]=history,{}
        cache=self.mode_cache[job.channel][1];key=job.kind,tuple(job.point)
        if key not in cache:
            cache[key]=target_mode(g,job,cloud);self.coupled_stats['cache_builds']+=1
        m=cache[key]
        return Mode(g,job,m.internal_s,m.exits,m.weights)

    def next_job(self):
        before=self.joint_stats['plans'];original=super().next_job()
        unknown=[c for c,b in self.beliefs.items() if b.state=='unknown']
        if self.joint_stats['plans']==before or self.locked is not None or (unknown and self.since_scan>=18):return original
        found=[b for b in self.beliefs.values() if b.state=='found']
        if any(len(b.failed_clears)>=8 or b.local_measurements>=10 for b in found):return original
        plan=self.joint.latest;scans=sorted(plan['scans'])
        if len(found)+len(scans)<2:return original
        try:clouds={b.channel:self.posterior.cloud(b) for b in found}
        except PosteriorUnavailable:return original
        centres={c:snap(cloud.mean) for c,cloud in clouds.items()}
        groups=[];representatives=[];first=None
        for b in found:
            c=b.channel;cloud=clouds[c];g=len(groups);jobs=[];current=self.client.position
            def add(kind,p,guaranteed=False):
                p=tuple(p)
                if math.hypot(*p)>(3300 if kind=='measure' else 1820):return
                if kind=='measure' and any(distance(p,q)<.1 for q,_,_ in b.observations):return
                if not any(j.kind==kind and j.point==p for j in jobs):jobs.append(Job(kind,p,c,guaranteed))
            if original.channel==c and original.kind in ('measure','clear'):jobs.append(original)
            add('clear',centres[c])
            good=self.reliable_options(b)
            if good:
                ends=[current,*sorted(scans,key=lambda p:distance(p,centres[c]))[:1]]
                for end in ends:add('clear',min(good,key=lambda p:distance(p,end)),True)
            proposals=[centres[c],snap(current),*map(snap,cautious_points(cloud))]
            # Shared arrival points permit scan -> localization with zero extra
            # travel. They are candidates, never assumed to produce a bearing.
            proposals+=sorted(scans,key=lambda p:distance(p,centres[c]))[:2]
            proposals+=sorted((p for other,p in centres.items() if other!=c),key=lambda p:distance(p,centres[c]))[:2]
            if getattr(self, "clearability_enabled", False):
                from clearability import proposals as gap_proposals
                proposals += gap_proposals(self,b,proposals)
            for p in proposals:add('measure',p)
            modes=[self.cached_mode(g,job,cloud) for job in jobs]
            if not modes:return original
            if original.channel==c:first=(g,0)
            groups.append(modes);representatives.append(centres[c])
        for p in scans:
            g=len(groups);job=Job('scan',p,anchor=self.anchors.index(p) if p in self.anchors else None,scan_channels=tuple(unknown))
            if original.kind=='scan' and tuple(original.point)==tuple(p):job=original;first=g,0
            groups.append([Mode(g,job,0.,np.array([p]),np.array([1.]))]);representatives.append(p)
        if first is None:return original
        problem=self.route_problem_class(groups,self.client.position,self.client.channel)
        refindex=problem.indices[first[0]][first[1]]
        remaining=[g for g in range(len(groups)) if g!=first[0]]
        remaining.sort(key=lambda g:plan['path'].index(representatives[g]) if representatives[g] in plan['path'] else len(plan['path']))
        indices,proof=problem.solve(refindex,[first[0],*remaining])
        selected=problem.modes[indices[0]].job
        changed=(selected.kind,selected.channel,selected.point)!=(original.kind,original.channel,original.point)
        self.coupled_stats['decisions']+=1;self.coupled_stats['changed_actions']+=changed
        self.coupled_stats['exact_catalog_solves' if proof['exact_catalog'] else 'beam_solves']+=1
        self.coupled_stats['expanded']+=proof['expanded'];self.coupled_stats['modelled_savings_s']+=proof['reference_s']-proof['selected_s']
        self.joint_stats['scan_jobs']+=int(selected.kind=='scan')-int(original.kind=='scan')
        self.client.record('coupled_route_decision',original=original.__dict__,selected=selected.__dict__,
            plan=[dict(job=problem.modes[i].job.__dict__,internal_s=problem.modes[i].internal_s,
                exits=problem.modes[i].exits.tolist(),weights=problem.modes[i].weights.tolist()) for i in indices],
            **proof,original_problem_optimality=False,episode_nonincrease_guaranteed=False)
        return selected

    def run(self):
        result=super().run();result['coupled_route']=dict(self.coupled_stats,
            observation_model='existing spatial quadrature, Gaussian field closure, 0.5 degree bins',
            future_unknown_discoveries_expanded=False,original_problem_optimality=False,
            mode_tail='fixed conditional greedy clear policy; full support of retained quadrature',
            target='minimize frozen expected total remaining time; evaluate actual E[T/N]')
        return result

class CoupledStrategy(SafeRouteBaseline):
    def __init__(self,client):
        self.actual=client;self.reference=ReferenceClient(client)
        self.controller=CoupledController(self.reference,progress=lambda message:None)
    def run(self):
        result=super().run()
        result.update(policy='coupled_no_score',strategy_version='coupled-service-route-no-score-v1')
        result['safe_route']['reference_policy']='coupled-service-route-no-score-v1'
        self.actual.record('summary',summary=result)
        return result
