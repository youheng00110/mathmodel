"""第三问提交程序的唯一运行入口。

预览（不连接模拟器）：
    python main.py --robot-id 队号 --mode practice --preview
执行一局（请先在模拟器页面选好题目与模式）：
    python main.py --robot-id 队号 --mode formal
本地安装与文件自检（不连接模拟器）：
    python main.py --check
"""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import sys
import uuid

# 与已验证入口一致，在导入 NumPy/SciPy 前设置线程数。
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--robot-id', help='模拟器当前登录队号')
    parser.add_argument('--mode', choices=('practice', 'formal'), help='页面模式声明，不自动切换模拟器')
    parser.add_argument('--base-url', default='http://127.0.0.1:2026', help='模拟器 API 地址')
    parser.add_argument('--output', type=Path, help='新建结果目录；省略则自动创建唯一目录')
    parser.add_argument('--preview', action='store_true', help='仅显示配置，不连接模拟器')
    parser.add_argument('--check', action='store_true', help='校验文件与依赖，不连接模拟器')
    args = parser.parse_args()
    if args.check:
        if args.preview or args.robot_id or args.mode or args.output:
            parser.error('--check 单独使用')
    elif not args.robot_id or not args.robot_id.strip() or not args.mode:
        parser.error('运行或预览必须同时提供 --robot-id 和 --mode')
    return args


def main():
    args = parse_args()
    if args.check:
        from verify import check
        return check()

    from solver.parameters import effective_parameters
    config = dict(
        problem=3, variant='V3', declared_mode=args.mode, robot_id=args.robot_id,
        base_url=args.base_url, parameters=effective_parameters(),
        entry='Q3_submission/main.py',
    )
    print(json.dumps(config, ensure_ascii=False, indent=2), flush=True)
    print('请在模拟器页面选择第三问及对应模式；--mode 仅作声明。', flush=True)
    if args.preview:
        print('仅预览，没有连接模拟器。')
        return 0

    from q3_strategy import Q3Strategy
    from solver.protocol import Client, HTTPTransport
    output = args.output or HERE / 'results' / (
        'q3_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
    )
    output.mkdir(parents=True, exist_ok=False)
    (output / 'config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    client = Client(HTTPTransport(args.base_url, 8), args.robot_id, output / 'actions.jsonl', 15, 360000)
    try:
        summary = Q3Strategy(client).run()
    finally:
        client.close()
    summary['declared_mode'] = args.mode
    (output / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    fields = ('completion_certified', 'exit_confirmed', 'average_clear_time_s', 'clear_success', 'clear_failure', 'error')
    print(json.dumps({key: summary.get(key) for key in fields}, ensure_ascii=False, indent=2))
    print('Results:', output.resolve())
    return 0 if summary['completion_certified'] and summary['exit_confirmed'] and not summary['error'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
