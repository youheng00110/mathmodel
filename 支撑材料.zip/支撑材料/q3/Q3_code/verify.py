"""提交包静态/依赖自检；无模拟器请求，不运行任何场景。"""
import ast
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))


def check():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest['files']:
        path = HERE / entry['path']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
            raise RuntimeError('文件缺失或与提交版本不一致：' + entry['path'])
        if path.suffix == '.py':
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    import numpy
    import scipy
    from q3_strategy import Q3Strategy
    from formal_strategy import FormalController
    from region_route.controller import ContinuousReferenceClient
    from solver.parameters import CLEAR_SAFE_RADIUS_M, COVERAGE_RADIUS_M
    assert COVERAGE_RADIUS_M == 1150.0 and CLEAR_SAFE_RADIUS_M == 19.7
    print(json.dumps(dict(
        check='passed', verified_files=len(manifest['files']),
        strategy='q3-consistent-1150-safe19.7-V3',
        python=sys.version.split()[0], numpy=numpy.__version__, scipy=scipy.__version__,
        imports=[Q3Strategy.__name__, FormalController.__name__, ContinuousReferenceClient.__name__],
        simulator_requests=0,
    ), ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(check())
