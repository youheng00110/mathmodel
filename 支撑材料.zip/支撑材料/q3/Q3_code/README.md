# 第三问提交代码

本目录是第三问源码。

## 环境与安装

- Python 3.11。
- 依赖 NumPy、SciPy及Python标准库。

在本目录打开 PowerShell：

```powershell
python -m pip install -r requirements.txt
python main.py --check
```

`--check` 核对提交文件哈希、语法、依赖导入与模型参数。

## 执行

预览：

```powershell
python main.py --robot-id "你的队号" --mode practice --preview
```

演练：

```powershell
python main.py --robot-id "你的队号" --mode practice
```

正式：

```powershell
python main.py --robot-id "你的队号" --mode formal
```

默认地址为http://127.0.0.1:2026。

## 输出

每局自动创建 `results/q3_时间_随机后缀/`：

| 文件 | 内容 |
|---|---|
| `config.json` | 队号、声明模式、接口地址与实际模型参数 |
| `actions.jsonl` | 实际请求/响应、规划信息及清除块证书 |
| `summary.json` | 完成状态、清除数、时间、距离和规划统计 |

完成检查：`completion_certified=true`、`exit_confirmed=true`、`error=null`。
`average_clear_time_s` 为退出时总虚拟时间除以清除数，
`program_elapsed_s` 为程序实际运行耗时。

## 算法对应

主线：集合型定位与频道排除 → 覆盖后备 → 搜索/测量/清除联合滚动规划 →
可靠清除区域内的连续路径优化。它不是先扫完所有站再一次性求TSP。

| 论文部分 | 源码 |
|---|---|
| V3策略组合 | `src/q3_strategy.py` |
| 模型参数唯一来源 | `src/solver/parameters.py` |
| 定位外包与几何计算 | `src/solver/belief.py`、`src/solver/geometry.py` |
| 覆盖排除与数值信息状态 | `src/discrete_model/coverage.py`、`src/discrete_model/model.py` |
| 多模式联合决策 | `src/nested_joint/no_score/controller.py` |
| 服务模式 | `src/coupled_route/model.py` |
| 有限服务任务DP／束搜索 | `src/coupled_route/routing.py` |
| 预算监督与后备触发 | `src/formal_strategy.py` |
| 有限蛇形后备及预算上界 | `src/discrete_model/certified_bounds.py` |
| 可靠清除块执行与参考时钟 | `src/fixed_route/online.py` |
| 连续服务区域优化与数值界 | `src/region_route/clearance.py`、`src/region_route/controller.py` |
| HTTP协议及物理计时 | `src/solver/protocol.py`、`src/solver/official_physics.py` |
